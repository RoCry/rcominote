
/tmp/comi-encrypt-static/EFUSEX~1.SO~:	file format elf64-x86-64

Disassembly of section .text:

000000000002d1f8 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8>:
   2d1f8: 55                           	pushq	%rbp
   2d1f9: 48 89 e5                     	movq	%rsp, %rbp
   2d1fc: 48 81 ec 00 01 00 00         	subq	$0x100, %rsp            # imm = 0x100
   2d203: 48 89 bd 18 ff ff ff         	movq	%rdi, -0xe8(%rbp)
   2d20a: 48 89 b5 10 ff ff ff         	movq	%rsi, -0xf0(%rbp)
   2d211: 48 89 95 08 ff ff ff         	movq	%rdx, -0xf8(%rbp)
   2d218: 48 c7 85 28 ff ff ff 00 00 00 00     	movq	$0x0, -0xd8(%rbp)
   2d223: 48 c7 85 30 ff ff ff 00 00 00 00     	movq	$0x0, -0xd0(%rbp)
   2d22e: 48 c7 85 38 ff ff ff 00 00 00 00     	movq	$0x0, -0xc8(%rbp)
   2d239: 48 c7 85 40 ff ff ff 00 00 00 00     	movq	$0x0, -0xc0(%rbp)
   2d244: 48 c7 85 48 ff ff ff 00 00 00 00     	movq	$0x0, -0xb8(%rbp)
   2d24f: 48 c7 85 50 ff ff ff 00 00 00 00     	movq	$0x0, -0xb0(%rbp)
   2d25a: 48 c7 85 58 ff ff ff 00 00 00 00     	movq	$0x0, -0xa8(%rbp)
   2d265: 48 c7 85 60 ff ff ff 00 00 00 00     	movq	$0x0, -0xa0(%rbp)
   2d270: 48 c7 85 68 ff ff ff 00 00 00 00     	movq	$0x0, -0x98(%rbp)
   2d27b: 48 c7 85 70 ff ff ff 00 00 00 00     	movq	$0x0, -0x90(%rbp)
   2d286: 48 c7 85 78 ff ff ff 00 00 00 00     	movq	$0x0, -0x88(%rbp)
   2d291: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2d299: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2d2a1: 48 8b 15 c0 4f 22 00         	movq	0x224fc0(%rip), %rdx    # 0x252268 <__pyx_int_2182120481>
   2d2a8: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   2d2af: 48 89 d6                     	movq	%rdx, %rsi
   2d2b2: 48 89 c7                     	movq	%rax, %rdi
   2d2b5: e8 0e 89 fd ff               	callq	0x5bc8 <PyNumber_And@plt>
   2d2ba: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2d2be: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2d2c3: 0f 94 c0                     	sete	%al
   2d2c6: 0f b6 c0                     	movzbl	%al, %eax
   2d2c9: 48 85 c0                     	testq	%rax, %rax
   2d2cc: 74 27                        	je	0x2d2f5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xfd>
   2d2ce: 48 8b 05 13 22 22 00         	movq	0x222213(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2d2d5: 48 89 05 6c 48 22 00         	movq	%rax, 0x22486c(%rip)    # 0x251b48 <__pyx_filename>
   2d2dc: c7 05 5a 48 22 00 31 01 00 00	movl	$0x131, 0x22485a(%rip)  # imm = 0x131
                                                                        # 0x251b40 <__pyx_lineno>
   2d2e6: c7 05 54 48 22 00 d4 24 00 00	movl	$0x24d4, 0x224854(%rip) # imm = 0x24D4
                                                                        # 0x251b44 <__pyx_clineno>
   2d2f0: e9 c0 24 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2d2f5: bf 01 00 00 00               	movl	$0x1, %edi
   2d2fa: e8 51 86 fd ff               	callq	0x5950 <PyTuple_New@plt>
   2d2ff: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2d303: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2d308: 0f 94 c0                     	sete	%al
   2d30b: 0f b6 c0                     	movzbl	%al, %eax
   2d30e: 48 85 c0                     	testq	%rax, %rax
   2d311: 74 27                        	je	0x2d33a <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x142>
   2d313: 48 8b 05 ce 21 22 00         	movq	0x2221ce(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2d31a: 48 89 05 27 48 22 00         	movq	%rax, 0x224827(%rip)    # 0x251b48 <__pyx_filename>
   2d321: c7 05 15 48 22 00 31 01 00 00	movl	$0x131, 0x224815(%rip)  # imm = 0x131
                                                                        # 0x251b40 <__pyx_lineno>
   2d32b: c7 05 0f 48 22 00 d6 24 00 00	movl	$0x24d6, 0x22480f(%rip) # imm = 0x24D6
                                                                        # 0x251b44 <__pyx_clineno>
   2d335: e9 7b 24 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2d33a: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d33e: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2d342: 48 89 50 18                  	movq	%rdx, 0x18(%rax)
   2d346: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2d34e: 48 8b 05 33 48 22 00         	movq	0x224833(%rip), %rax    # 0x251b88 <__pyx_builtin_bin>
   2d355: 48 8b 4d 88                  	movq	-0x78(%rbp), %rcx
   2d359: ba 00 00 00 00               	movl	$0x0, %edx
   2d35e: 48 89 ce                     	movq	%rcx, %rsi
   2d361: 48 89 c7                     	movq	%rax, %rdi
   2d364: e8 bd 91 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   2d369: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2d36d: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2d372: 0f 94 c0                     	sete	%al
   2d375: 0f b6 c0                     	movzbl	%al, %eax
   2d378: 48 85 c0                     	testq	%rax, %rax
   2d37b: 74 27                        	je	0x2d3a4 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1ac>
   2d37d: 48 8b 05 64 21 22 00         	movq	0x222164(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2d384: 48 89 05 bd 47 22 00         	movq	%rax, 0x2247bd(%rip)    # 0x251b48 <__pyx_filename>
   2d38b: c7 05 ab 47 22 00 31 01 00 00	movl	$0x131, 0x2247ab(%rip)  # imm = 0x131
                                                                        # 0x251b40 <__pyx_lineno>
   2d395: c7 05 a5 47 22 00 db 24 00 00	movl	$0x24db, 0x2247a5(%rip) # imm = 0x24DB
                                                                        # 0x251b44 <__pyx_clineno>
   2d39f: e9 11 24 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2d3a4: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d3a8: 48 8b 00                     	movq	(%rax), %rax
   2d3ab: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2d3af: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d3b3: 48 89 10                     	movq	%rdx, (%rax)
   2d3b6: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d3ba: 48 8b 00                     	movq	(%rax), %rax
   2d3bd: 48 85 c0                     	testq	%rax, %rax
   2d3c0: 75 15                        	jne	0x2d3d7 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1df>
   2d3c2: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d3c6: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2d3ca: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2d3ce: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2d3d2: 48 89 d7                     	movq	%rdx, %rdi
   2d3d5: ff d0                        	callq	*%rax
   2d3d7: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2d3df: 48 8b 15 ba 49 22 00         	movq	0x2249ba(%rip), %rdx    # 0x251da0 <__pyx_n_s_count>
   2d3e6: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2d3ea: 48 89 d6                     	movq	%rdx, %rsi
   2d3ed: 48 89 c7                     	movq	%rax, %rdi
   2d3f0: e8 d5 88 fd ff               	callq	0x5cca <__Pyx_PyObject_GetAttrStr>
   2d3f5: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2d3f9: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2d3fe: 0f 94 c0                     	sete	%al
   2d401: 0f b6 c0                     	movzbl	%al, %eax
   2d404: 48 85 c0                     	testq	%rax, %rax
   2d407: 74 27                        	je	0x2d430 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x238>
   2d409: 48 8b 05 d8 20 22 00         	movq	0x2220d8(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2d410: 48 89 05 31 47 22 00         	movq	%rax, 0x224731(%rip)    # 0x251b48 <__pyx_filename>
   2d417: c7 05 1f 47 22 00 31 01 00 00	movl	$0x131, 0x22471f(%rip)  # imm = 0x131
                                                                        # 0x251b40 <__pyx_lineno>
   2d421: c7 05 19 47 22 00 de 24 00 00	movl	$0x24de, 0x224719(%rip) # imm = 0x24DE
                                                                        # 0x251b44 <__pyx_clineno>
   2d42b: e9 85 23 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2d430: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2d434: 48 8b 00                     	movq	(%rax), %rax
   2d437: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2d43b: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2d43f: 48 89 10                     	movq	%rdx, (%rax)
   2d442: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2d446: 48 8b 00                     	movq	(%rax), %rax
   2d449: 48 85 c0                     	testq	%rax, %rax
   2d44c: 75 15                        	jne	0x2d463 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x26b>
   2d44e: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2d452: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2d456: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2d45a: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2d45e: 48 89 d7                     	movq	%rdx, %rdi
   2d461: ff d0                        	callq	*%rax
   2d463: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2d46b: 48 8b 0d 26 4f 22 00         	movq	0x224f26(%rip), %rcx    # 0x252398 <__pyx_tuple__34>
   2d472: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d476: ba 00 00 00 00               	movl	$0x0, %edx
   2d47b: 48 89 ce                     	movq	%rcx, %rsi
   2d47e: 48 89 c7                     	movq	%rax, %rdi
   2d481: e8 a0 90 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   2d486: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2d48a: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2d48f: 0f 94 c0                     	sete	%al
   2d492: 0f b6 c0                     	movzbl	%al, %eax
   2d495: 48 85 c0                     	testq	%rax, %rax
   2d498: 74 27                        	je	0x2d4c1 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2c9>
   2d49a: 48 8b 05 47 20 22 00         	movq	0x222047(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2d4a1: 48 89 05 a0 46 22 00         	movq	%rax, 0x2246a0(%rip)    # 0x251b48 <__pyx_filename>
   2d4a8: c7 05 8e 46 22 00 31 01 00 00	movl	$0x131, 0x22468e(%rip)  # imm = 0x131
                                                                        # 0x251b40 <__pyx_lineno>
   2d4b2: c7 05 88 46 22 00 e1 24 00 00	movl	$0x24e1, 0x224688(%rip) # imm = 0x24E1
                                                                        # 0x251b44 <__pyx_clineno>
   2d4bc: e9 f4 22 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2d4c1: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d4c5: 48 8b 00                     	movq	(%rax), %rax
   2d4c8: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2d4cc: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d4d0: 48 89 10                     	movq	%rdx, (%rax)
   2d4d3: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d4d7: 48 8b 00                     	movq	(%rax), %rax
   2d4da: 48 85 c0                     	testq	%rax, %rax
   2d4dd: 75 15                        	jne	0x2d4f4 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2fc>
   2d4df: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d4e3: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2d4e7: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2d4eb: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2d4ef: 48 89 d7                     	movq	%rdx, %rdi
   2d4f2: ff d0                        	callq	*%rax
   2d4f4: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2d4fc: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2d500: 48 89 85 28 ff ff ff         	movq	%rax, -0xd8(%rbp)
   2d507: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2d50f: 48 8b 35 32 4c 22 00         	movq	0x224c32(%rip), %rsi    # 0x252148 <__pyx_int_1>
   2d516: 48 8b 85 28 ff ff ff         	movq	-0xd8(%rbp), %rax
   2d51d: b9 00 00 00 00               	movl	$0x0, %ecx
   2d522: ba 01 00 00 00               	movl	$0x1, %edx
   2d527: 48 89 c7                     	movq	%rax, %rdi
   2d52a: e8 ab ad 01 00               	callq	0x482da <__Pyx_PyInt_AndObjC>
   2d52f: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2d533: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2d538: 0f 94 c0                     	sete	%al
   2d53b: 0f b6 c0                     	movzbl	%al, %eax
   2d53e: 48 85 c0                     	testq	%rax, %rax
   2d541: 74 27                        	je	0x2d56a <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x372>
   2d543: 48 8b 05 9e 1f 22 00         	movq	0x221f9e(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2d54a: 48 89 05 f7 45 22 00         	movq	%rax, 0x2245f7(%rip)    # 0x251b48 <__pyx_filename>
   2d551: c7 05 e5 45 22 00 33 01 00 00	movl	$0x133, 0x2245e5(%rip)  # imm = 0x133
                                                                        # 0x251b40 <__pyx_lineno>
   2d55b: c7 05 df 45 22 00 ee 24 00 00	movl	$0x24ee, 0x2245df(%rip) # imm = 0x24EE
                                                                        # 0x251b44 <__pyx_clineno>
   2d565: e9 4b 22 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2d56a: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2d56e: 48 89 85 30 ff ff ff         	movq	%rax, -0xd0(%rbp)
   2d575: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2d57d: 48 8b 85 30 ff ff ff         	movq	-0xd0(%rbp), %rax
   2d584: 48 8b 00                     	movq	(%rax), %rax
   2d587: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   2d58b: 48 8b 85 30 ff ff ff         	movq	-0xd0(%rbp), %rax
   2d592: 48 89 10                     	movq	%rdx, (%rax)
   2d595: 48 8b 85 30 ff ff ff         	movq	-0xd0(%rbp), %rax
   2d59c: 48 89 85 38 ff ff ff         	movq	%rax, -0xc8(%rbp)
   2d5a3: 48 8b 35 86 4c 22 00         	movq	0x224c86(%rip), %rsi    # 0x252230 <__pyx_int_138481731>
   2d5aa: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   2d5b1: b9 00 00 00 00               	movl	$0x0, %ecx
   2d5b6: ba 43 10 41 08               	movl	$0x8411043, %edx        # imm = 0x8411043
   2d5bb: 48 89 c7                     	movq	%rax, %rdi
   2d5be: e8 17 ad 01 00               	callq	0x482da <__Pyx_PyInt_AndObjC>
   2d5c3: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2d5c7: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2d5cc: 0f 94 c0                     	sete	%al
   2d5cf: 0f b6 c0                     	movzbl	%al, %eax
   2d5d2: 48 85 c0                     	testq	%rax, %rax
   2d5d5: 74 27                        	je	0x2d5fe <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x406>
   2d5d7: 48 8b 05 0a 1f 22 00         	movq	0x221f0a(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2d5de: 48 89 05 63 45 22 00         	movq	%rax, 0x224563(%rip)    # 0x251b48 <__pyx_filename>
   2d5e5: c7 05 51 45 22 00 38 01 00 00	movl	$0x138, 0x224551(%rip)  # imm = 0x138
                                                                        # 0x251b40 <__pyx_lineno>
   2d5ef: c7 05 4b 45 22 00 04 25 00 00	movl	$0x2504, 0x22454b(%rip) # imm = 0x2504
                                                                        # 0x251b44 <__pyx_clineno>
   2d5f9: e9 b7 21 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2d5fe: bf 01 00 00 00               	movl	$0x1, %edi
   2d603: e8 48 83 fd ff               	callq	0x5950 <PyTuple_New@plt>
   2d608: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2d60c: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2d611: 0f 94 c0                     	sete	%al
   2d614: 0f b6 c0                     	movzbl	%al, %eax
   2d617: 48 85 c0                     	testq	%rax, %rax
   2d61a: 74 27                        	je	0x2d643 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x44b>
   2d61c: 48 8b 05 c5 1e 22 00         	movq	0x221ec5(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2d623: 48 89 05 1e 45 22 00         	movq	%rax, 0x22451e(%rip)    # 0x251b48 <__pyx_filename>
   2d62a: c7 05 0c 45 22 00 38 01 00 00	movl	$0x138, 0x22450c(%rip)  # imm = 0x138
                                                                        # 0x251b40 <__pyx_lineno>
   2d634: c7 05 06 45 22 00 06 25 00 00	movl	$0x2506, 0x224506(%rip) # imm = 0x2506
                                                                        # 0x251b44 <__pyx_clineno>
   2d63e: e9 72 21 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2d643: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d647: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2d64b: 48 89 50 18                  	movq	%rdx, 0x18(%rax)
   2d64f: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2d657: 48 8b 05 2a 45 22 00         	movq	0x22452a(%rip), %rax    # 0x251b88 <__pyx_builtin_bin>
   2d65e: 48 8b 4d 88                  	movq	-0x78(%rbp), %rcx
   2d662: ba 00 00 00 00               	movl	$0x0, %edx
   2d667: 48 89 ce                     	movq	%rcx, %rsi
   2d66a: 48 89 c7                     	movq	%rax, %rdi
   2d66d: e8 b4 8e 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   2d672: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2d676: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2d67b: 0f 94 c0                     	sete	%al
   2d67e: 0f b6 c0                     	movzbl	%al, %eax
   2d681: 48 85 c0                     	testq	%rax, %rax
   2d684: 74 27                        	je	0x2d6ad <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x4b5>
   2d686: 48 8b 05 5b 1e 22 00         	movq	0x221e5b(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2d68d: 48 89 05 b4 44 22 00         	movq	%rax, 0x2244b4(%rip)    # 0x251b48 <__pyx_filename>
   2d694: c7 05 a2 44 22 00 38 01 00 00	movl	$0x138, 0x2244a2(%rip)  # imm = 0x138
                                                                        # 0x251b40 <__pyx_lineno>
   2d69e: c7 05 9c 44 22 00 0b 25 00 00	movl	$0x250b, 0x22449c(%rip) # imm = 0x250B
                                                                        # 0x251b44 <__pyx_clineno>
   2d6a8: e9 08 21 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2d6ad: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d6b1: 48 8b 00                     	movq	(%rax), %rax
   2d6b4: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2d6b8: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d6bc: 48 89 10                     	movq	%rdx, (%rax)
   2d6bf: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d6c3: 48 8b 00                     	movq	(%rax), %rax
   2d6c6: 48 85 c0                     	testq	%rax, %rax
   2d6c9: 75 15                        	jne	0x2d6e0 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x4e8>
   2d6cb: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d6cf: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2d6d3: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2d6d7: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2d6db: 48 89 d7                     	movq	%rdx, %rdi
   2d6de: ff d0                        	callq	*%rax
   2d6e0: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2d6e8: 48 8b 15 b1 46 22 00         	movq	0x2246b1(%rip), %rdx    # 0x251da0 <__pyx_n_s_count>
   2d6ef: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2d6f3: 48 89 d6                     	movq	%rdx, %rsi
   2d6f6: 48 89 c7                     	movq	%rax, %rdi
   2d6f9: e8 cc 85 fd ff               	callq	0x5cca <__Pyx_PyObject_GetAttrStr>
   2d6fe: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2d702: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2d707: 0f 94 c0                     	sete	%al
   2d70a: 0f b6 c0                     	movzbl	%al, %eax
   2d70d: 48 85 c0                     	testq	%rax, %rax
   2d710: 74 27                        	je	0x2d739 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x541>
   2d712: 48 8b 05 cf 1d 22 00         	movq	0x221dcf(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2d719: 48 89 05 28 44 22 00         	movq	%rax, 0x224428(%rip)    # 0x251b48 <__pyx_filename>
   2d720: c7 05 16 44 22 00 38 01 00 00	movl	$0x138, 0x224416(%rip)  # imm = 0x138
                                                                        # 0x251b40 <__pyx_lineno>
   2d72a: c7 05 10 44 22 00 0e 25 00 00	movl	$0x250e, 0x224410(%rip) # imm = 0x250E
                                                                        # 0x251b44 <__pyx_clineno>
   2d734: e9 7c 20 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2d739: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2d73d: 48 8b 00                     	movq	(%rax), %rax
   2d740: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2d744: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2d748: 48 89 10                     	movq	%rdx, (%rax)
   2d74b: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2d74f: 48 8b 00                     	movq	(%rax), %rax
   2d752: 48 85 c0                     	testq	%rax, %rax
   2d755: 75 15                        	jne	0x2d76c <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x574>
   2d757: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2d75b: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2d75f: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2d763: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2d767: 48 89 d7                     	movq	%rdx, %rdi
   2d76a: ff d0                        	callq	*%rax
   2d76c: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2d774: 48 8b 0d 25 4c 22 00         	movq	0x224c25(%rip), %rcx    # 0x2523a0 <__pyx_tuple__35>
   2d77b: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d77f: ba 00 00 00 00               	movl	$0x0, %edx
   2d784: 48 89 ce                     	movq	%rcx, %rsi
   2d787: 48 89 c7                     	movq	%rax, %rdi
   2d78a: e8 97 8d 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   2d78f: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2d793: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2d798: 0f 94 c0                     	sete	%al
   2d79b: 0f b6 c0                     	movzbl	%al, %eax
   2d79e: 48 85 c0                     	testq	%rax, %rax
   2d7a1: 74 27                        	je	0x2d7ca <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x5d2>
   2d7a3: 48 8b 05 3e 1d 22 00         	movq	0x221d3e(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2d7aa: 48 89 05 97 43 22 00         	movq	%rax, 0x224397(%rip)    # 0x251b48 <__pyx_filename>
   2d7b1: c7 05 85 43 22 00 38 01 00 00	movl	$0x138, 0x224385(%rip)  # imm = 0x138
                                                                        # 0x251b40 <__pyx_lineno>
   2d7bb: c7 05 7f 43 22 00 11 25 00 00	movl	$0x2511, 0x22437f(%rip) # imm = 0x2511
                                                                        # 0x251b44 <__pyx_clineno>
   2d7c5: e9 eb 1f 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2d7ca: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d7ce: 48 8b 00                     	movq	(%rax), %rax
   2d7d1: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2d7d5: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d7d9: 48 89 10                     	movq	%rdx, (%rax)
   2d7dc: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d7e0: 48 8b 00                     	movq	(%rax), %rax
   2d7e3: 48 85 c0                     	testq	%rax, %rax
   2d7e6: 75 15                        	jne	0x2d7fd <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x605>
   2d7e8: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d7ec: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2d7f0: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2d7f4: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2d7f8: 48 89 d7                     	movq	%rdx, %rdi
   2d7fb: ff d0                        	callq	*%rax
   2d7fd: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2d805: 48 8b 85 28 ff ff ff         	movq	-0xd8(%rbp), %rax
   2d80c: 48 89 45 90                  	movq	%rax, -0x70(%rbp)
   2d810: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2d814: 48 89 85 28 ff ff ff         	movq	%rax, -0xd8(%rbp)
   2d81b: 48 8b 45 90                  	movq	-0x70(%rbp), %rax
   2d81f: 48 8b 00                     	movq	(%rax), %rax
   2d822: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2d826: 48 8b 45 90                  	movq	-0x70(%rbp), %rax
   2d82a: 48 89 10                     	movq	%rdx, (%rax)
   2d82d: 48 8b 45 90                  	movq	-0x70(%rbp), %rax
   2d831: 48 8b 00                     	movq	(%rax), %rax
   2d834: 48 85 c0                     	testq	%rax, %rax
   2d837: 75 15                        	jne	0x2d84e <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x656>
   2d839: 48 8b 45 90                  	movq	-0x70(%rbp), %rax
   2d83d: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2d841: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2d845: 48 8b 55 90                  	movq	-0x70(%rbp), %rdx
   2d849: 48 89 d7                     	movq	%rdx, %rdi
   2d84c: ff d0                        	callq	*%rax
   2d84e: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2d856: 48 8b 35 eb 48 22 00         	movq	0x2248eb(%rip), %rsi    # 0x252148 <__pyx_int_1>
   2d85d: 48 8b 85 28 ff ff ff         	movq	-0xd8(%rbp), %rax
   2d864: b9 00 00 00 00               	movl	$0x0, %ecx
   2d869: ba 01 00 00 00               	movl	$0x1, %edx
   2d86e: 48 89 c7                     	movq	%rax, %rdi
   2d871: e8 64 aa 01 00               	callq	0x482da <__Pyx_PyInt_AndObjC>
   2d876: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2d87a: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2d87f: 0f 94 c0                     	sete	%al
   2d882: 0f b6 c0                     	movzbl	%al, %eax
   2d885: 48 85 c0                     	testq	%rax, %rax
   2d888: 74 27                        	je	0x2d8b1 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x6b9>
   2d88a: 48 8b 05 57 1c 22 00         	movq	0x221c57(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2d891: 48 89 05 b0 42 22 00         	movq	%rax, 0x2242b0(%rip)    # 0x251b48 <__pyx_filename>
   2d898: c7 05 9e 42 22 00 3a 01 00 00	movl	$0x13a, 0x22429e(%rip)  # imm = 0x13A
                                                                        # 0x251b40 <__pyx_lineno>
   2d8a2: c7 05 98 42 22 00 1e 25 00 00	movl	$0x251e, 0x224298(%rip) # imm = 0x251E
                                                                        # 0x251b44 <__pyx_clineno>
   2d8ac: e9 04 1f 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2d8b1: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2d8b5: 48 89 85 40 ff ff ff         	movq	%rax, -0xc0(%rbp)
   2d8bc: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2d8c4: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   2d8cb: 48 89 c7                     	movq	%rax, %rdi
   2d8ce: e8 64 e1 01 00               	callq	0x4ba37 <__Pyx_PyObject_IsTrue>
   2d8d3: 89 85 24 ff ff ff            	movl	%eax, -0xdc(%rbp)
   2d8d9: 8b 85 24 ff ff ff            	movl	-0xdc(%rbp), %eax
   2d8df: c1 e8 1f                     	shrl	$0x1f, %eax
   2d8e2: 0f b6 c0                     	movzbl	%al, %eax
   2d8e5: 48 85 c0                     	testq	%rax, %rax
   2d8e8: 74 27                        	je	0x2d911 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x719>
   2d8ea: 48 8b 05 f7 1b 22 00         	movq	0x221bf7(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2d8f1: 48 89 05 50 42 22 00         	movq	%rax, 0x224250(%rip)    # 0x251b48 <__pyx_filename>
   2d8f8: c7 05 3e 42 22 00 3b 01 00 00	movl	$0x13b, 0x22423e(%rip)  # imm = 0x13B
                                                                        # 0x251b40 <__pyx_lineno>
   2d902: c7 05 38 42 22 00 2a 25 00 00	movl	$0x252a, 0x224238(%rip) # imm = 0x252A
                                                                        # 0x251b44 <__pyx_clineno>
   2d90c: e9 a4 1e 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2d911: 83 bd 24 ff ff ff 00         	cmpl	$0x0, -0xdc(%rbp)
   2d918: 75 25                        	jne	0x2d93f <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x747>
   2d91a: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   2d921: 48 8b 00                     	movq	(%rax), %rax
   2d924: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   2d928: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   2d92f: 48 89 10                     	movq	%rdx, (%rax)
   2d932: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   2d939: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2d93d: eb 55                        	jmp	0x2d994 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x79c>
   2d93f: bf 02 00 00 00               	movl	$0x2, %edi
   2d944: e8 df da 01 00               	callq	0x4b428 <__Pyx_PyInt_From_long>
   2d949: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2d94d: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2d952: 0f 94 c0                     	sete	%al
   2d955: 0f b6 c0                     	movzbl	%al, %eax
   2d958: 48 85 c0                     	testq	%rax, %rax
   2d95b: 74 27                        	je	0x2d984 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x78c>
   2d95d: 48 8b 05 84 1b 22 00         	movq	0x221b84(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2d964: 48 89 05 dd 41 22 00         	movq	%rax, 0x2241dd(%rip)    # 0x251b48 <__pyx_filename>
   2d96b: c7 05 cb 41 22 00 3b 01 00 00	movl	$0x13b, 0x2241cb(%rip)  # imm = 0x13B
                                                                        # 0x251b40 <__pyx_lineno>
   2d975: c7 05 c5 41 22 00 31 25 00 00	movl	$0x2531, 0x2241c5(%rip) # imm = 0x2531
                                                                        # 0x251b44 <__pyx_clineno>
   2d97f: e9 31 1e 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2d984: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2d988: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2d98c: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2d994: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2d998: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2d99f: 48 89 d6                     	movq	%rdx, %rsi
   2d9a2: 48 89 c7                     	movq	%rax, %rdi
   2d9a5: e8 0e 82 fd ff               	callq	0x5bb8 <PyNumber_InPlaceAdd@plt>
   2d9aa: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2d9ae: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2d9b3: 0f 94 c0                     	sete	%al
   2d9b6: 0f b6 c0                     	movzbl	%al, %eax
   2d9b9: 48 85 c0                     	testq	%rax, %rax
   2d9bc: 74 27                        	je	0x2d9e5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x7ed>
   2d9be: 48 8b 05 23 1b 22 00         	movq	0x221b23(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2d9c5: 48 89 05 7c 41 22 00         	movq	%rax, 0x22417c(%rip)    # 0x251b48 <__pyx_filename>
   2d9cc: c7 05 6a 41 22 00 3b 01 00 00	movl	$0x13b, 0x22416a(%rip)  # imm = 0x13B
                                                                        # 0x251b40 <__pyx_lineno>
   2d9d6: c7 05 64 41 22 00 36 25 00 00	movl	$0x2536, 0x224164(%rip) # imm = 0x2536
                                                                        # 0x251b44 <__pyx_clineno>
   2d9e0: e9 d0 1d 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2d9e5: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2d9e9: 48 8b 00                     	movq	(%rax), %rax
   2d9ec: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2d9f0: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2d9f4: 48 89 10                     	movq	%rdx, (%rax)
   2d9f7: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2d9fb: 48 8b 00                     	movq	(%rax), %rax
   2d9fe: 48 85 c0                     	testq	%rax, %rax
   2da01: 75 15                        	jne	0x2da18 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x820>
   2da03: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2da07: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2da0b: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2da0f: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2da13: 48 89 d7                     	movq	%rdx, %rdi
   2da16: ff d0                        	callq	*%rax
   2da18: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2da20: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2da27: 48 89 45 98                  	movq	%rax, -0x68(%rbp)
   2da2b: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2da2f: 48 89 85 38 ff ff ff         	movq	%rax, -0xc8(%rbp)
   2da36: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   2da3a: 48 8b 00                     	movq	(%rax), %rax
   2da3d: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2da41: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   2da45: 48 89 10                     	movq	%rdx, (%rax)
   2da48: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   2da4c: 48 8b 00                     	movq	(%rax), %rax
   2da4f: 48 85 c0                     	testq	%rax, %rax
   2da52: 75 15                        	jne	0x2da69 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x871>
   2da54: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   2da58: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2da5c: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2da60: 48 8b 55 98                  	movq	-0x68(%rbp), %rdx
   2da64: 48 89 d7                     	movq	%rdx, %rdi
   2da67: ff d0                        	callq	*%rax
   2da69: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2da71: 48 8b 35 c8 47 22 00         	movq	0x2247c8(%rip), %rsi    # 0x252240 <__pyx_int_276832388>
   2da78: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   2da7f: b9 00 00 00 00               	movl	$0x0, %ecx
   2da84: ba 84 20 80 10               	movl	$0x10802084, %edx       # imm = 0x10802084
   2da89: 48 89 c7                     	movq	%rax, %rdi
   2da8c: e8 49 a8 01 00               	callq	0x482da <__Pyx_PyInt_AndObjC>
   2da91: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2da95: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2da9a: 0f 94 c0                     	sete	%al
   2da9d: 0f b6 c0                     	movzbl	%al, %eax
   2daa0: 48 85 c0                     	testq	%rax, %rax
   2daa3: 74 27                        	je	0x2dacc <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x8d4>
   2daa5: 48 8b 05 3c 1a 22 00         	movq	0x221a3c(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2daac: 48 89 05 95 40 22 00         	movq	%rax, 0x224095(%rip)    # 0x251b48 <__pyx_filename>
   2dab3: c7 05 83 40 22 00 3f 01 00 00	movl	$0x13f, 0x224083(%rip)  # imm = 0x13F
                                                                        # 0x251b40 <__pyx_lineno>
   2dabd: c7 05 7d 40 22 00 43 25 00 00	movl	$0x2543, 0x22407d(%rip) # imm = 0x2543
                                                                        # 0x251b44 <__pyx_clineno>
   2dac7: e9 e9 1c 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2dacc: bf 01 00 00 00               	movl	$0x1, %edi
   2dad1: e8 7a 7e fd ff               	callq	0x5950 <PyTuple_New@plt>
   2dad6: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2dada: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2dadf: 0f 94 c0                     	sete	%al
   2dae2: 0f b6 c0                     	movzbl	%al, %eax
   2dae5: 48 85 c0                     	testq	%rax, %rax
   2dae8: 74 27                        	je	0x2db11 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x919>
   2daea: 48 8b 05 f7 19 22 00         	movq	0x2219f7(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2daf1: 48 89 05 50 40 22 00         	movq	%rax, 0x224050(%rip)    # 0x251b48 <__pyx_filename>
   2daf8: c7 05 3e 40 22 00 3f 01 00 00	movl	$0x13f, 0x22403e(%rip)  # imm = 0x13F
                                                                        # 0x251b40 <__pyx_lineno>
   2db02: c7 05 38 40 22 00 45 25 00 00	movl	$0x2545, 0x224038(%rip) # imm = 0x2545
                                                                        # 0x251b44 <__pyx_clineno>
   2db0c: e9 a4 1c 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2db11: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2db15: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2db19: 48 89 50 18                  	movq	%rdx, 0x18(%rax)
   2db1d: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2db25: 48 8b 05 5c 40 22 00         	movq	0x22405c(%rip), %rax    # 0x251b88 <__pyx_builtin_bin>
   2db2c: 48 8b 4d 80                  	movq	-0x80(%rbp), %rcx
   2db30: ba 00 00 00 00               	movl	$0x0, %edx
   2db35: 48 89 ce                     	movq	%rcx, %rsi
   2db38: 48 89 c7                     	movq	%rax, %rdi
   2db3b: e8 e6 89 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   2db40: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2db44: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2db49: 0f 94 c0                     	sete	%al
   2db4c: 0f b6 c0                     	movzbl	%al, %eax
   2db4f: 48 85 c0                     	testq	%rax, %rax
   2db52: 74 27                        	je	0x2db7b <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x983>
   2db54: 48 8b 05 8d 19 22 00         	movq	0x22198d(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2db5b: 48 89 05 e6 3f 22 00         	movq	%rax, 0x223fe6(%rip)    # 0x251b48 <__pyx_filename>
   2db62: c7 05 d4 3f 22 00 3f 01 00 00	movl	$0x13f, 0x223fd4(%rip)  # imm = 0x13F
                                                                        # 0x251b40 <__pyx_lineno>
   2db6c: c7 05 ce 3f 22 00 4a 25 00 00	movl	$0x254a, 0x223fce(%rip) # imm = 0x254A
                                                                        # 0x251b44 <__pyx_clineno>
   2db76: e9 3a 1c 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2db7b: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2db7f: 48 8b 00                     	movq	(%rax), %rax
   2db82: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2db86: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2db8a: 48 89 10                     	movq	%rdx, (%rax)
   2db8d: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2db91: 48 8b 00                     	movq	(%rax), %rax
   2db94: 48 85 c0                     	testq	%rax, %rax
   2db97: 75 15                        	jne	0x2dbae <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x9b6>
   2db99: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2db9d: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2dba1: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2dba5: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2dba9: 48 89 d7                     	movq	%rdx, %rdi
   2dbac: ff d0                        	callq	*%rax
   2dbae: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2dbb6: 48 8b 15 e3 41 22 00         	movq	0x2241e3(%rip), %rdx    # 0x251da0 <__pyx_n_s_count>
   2dbbd: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2dbc1: 48 89 d6                     	movq	%rdx, %rsi
   2dbc4: 48 89 c7                     	movq	%rax, %rdi
   2dbc7: e8 fe 80 fd ff               	callq	0x5cca <__Pyx_PyObject_GetAttrStr>
   2dbcc: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2dbd0: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2dbd5: 0f 94 c0                     	sete	%al
   2dbd8: 0f b6 c0                     	movzbl	%al, %eax
   2dbdb: 48 85 c0                     	testq	%rax, %rax
   2dbde: 74 27                        	je	0x2dc07 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xa0f>
   2dbe0: 48 8b 05 01 19 22 00         	movq	0x221901(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2dbe7: 48 89 05 5a 3f 22 00         	movq	%rax, 0x223f5a(%rip)    # 0x251b48 <__pyx_filename>
   2dbee: c7 05 48 3f 22 00 3f 01 00 00	movl	$0x13f, 0x223f48(%rip)  # imm = 0x13F
                                                                        # 0x251b40 <__pyx_lineno>
   2dbf8: c7 05 42 3f 22 00 4d 25 00 00	movl	$0x254d, 0x223f42(%rip) # imm = 0x254D
                                                                        # 0x251b44 <__pyx_clineno>
   2dc02: e9 ae 1b 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2dc07: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2dc0b: 48 8b 00                     	movq	(%rax), %rax
   2dc0e: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2dc12: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2dc16: 48 89 10                     	movq	%rdx, (%rax)
   2dc19: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2dc1d: 48 8b 00                     	movq	(%rax), %rax
   2dc20: 48 85 c0                     	testq	%rax, %rax
   2dc23: 75 15                        	jne	0x2dc3a <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xa42>
   2dc25: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2dc29: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2dc2d: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2dc31: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2dc35: 48 89 d7                     	movq	%rdx, %rdi
   2dc38: ff d0                        	callq	*%rax
   2dc3a: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2dc42: 48 8b 0d 5f 47 22 00         	movq	0x22475f(%rip), %rcx    # 0x2523a8 <__pyx_tuple__36>
   2dc49: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2dc4d: ba 00 00 00 00               	movl	$0x0, %edx
   2dc52: 48 89 ce                     	movq	%rcx, %rsi
   2dc55: 48 89 c7                     	movq	%rax, %rdi
   2dc58: e8 c9 88 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   2dc5d: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2dc61: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2dc66: 0f 94 c0                     	sete	%al
   2dc69: 0f b6 c0                     	movzbl	%al, %eax
   2dc6c: 48 85 c0                     	testq	%rax, %rax
   2dc6f: 74 27                        	je	0x2dc98 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xaa0>
   2dc71: 48 8b 05 70 18 22 00         	movq	0x221870(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2dc78: 48 89 05 c9 3e 22 00         	movq	%rax, 0x223ec9(%rip)    # 0x251b48 <__pyx_filename>
   2dc7f: c7 05 b7 3e 22 00 3f 01 00 00	movl	$0x13f, 0x223eb7(%rip)  # imm = 0x13F
                                                                        # 0x251b40 <__pyx_lineno>
   2dc89: c7 05 b1 3e 22 00 50 25 00 00	movl	$0x2550, 0x223eb1(%rip) # imm = 0x2550
                                                                        # 0x251b44 <__pyx_clineno>
   2dc93: e9 1d 1b 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2dc98: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2dc9c: 48 8b 00                     	movq	(%rax), %rax
   2dc9f: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2dca3: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2dca7: 48 89 10                     	movq	%rdx, (%rax)
   2dcaa: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2dcae: 48 8b 00                     	movq	(%rax), %rax
   2dcb1: 48 85 c0                     	testq	%rax, %rax
   2dcb4: 75 15                        	jne	0x2dccb <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xad3>
   2dcb6: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2dcba: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2dcbe: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2dcc2: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2dcc6: 48 89 d7                     	movq	%rdx, %rdi
   2dcc9: ff d0                        	callq	*%rax
   2dccb: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2dcd3: 48 8b 85 28 ff ff ff         	movq	-0xd8(%rbp), %rax
   2dcda: 48 89 45 a0                  	movq	%rax, -0x60(%rbp)
   2dcde: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2dce2: 48 89 85 28 ff ff ff         	movq	%rax, -0xd8(%rbp)
   2dce9: 48 8b 45 a0                  	movq	-0x60(%rbp), %rax
   2dced: 48 8b 00                     	movq	(%rax), %rax
   2dcf0: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2dcf4: 48 8b 45 a0                  	movq	-0x60(%rbp), %rax
   2dcf8: 48 89 10                     	movq	%rdx, (%rax)
   2dcfb: 48 8b 45 a0                  	movq	-0x60(%rbp), %rax
   2dcff: 48 8b 00                     	movq	(%rax), %rax
   2dd02: 48 85 c0                     	testq	%rax, %rax
   2dd05: 75 15                        	jne	0x2dd1c <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xb24>
   2dd07: 48 8b 45 a0                  	movq	-0x60(%rbp), %rax
   2dd0b: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2dd0f: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2dd13: 48 8b 55 a0                  	movq	-0x60(%rbp), %rdx
   2dd17: 48 89 d7                     	movq	%rdx, %rdi
   2dd1a: ff d0                        	callq	*%rax
   2dd1c: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2dd24: 48 8b 35 1d 44 22 00         	movq	0x22441d(%rip), %rsi    # 0x252148 <__pyx_int_1>
   2dd2b: 48 8b 85 28 ff ff ff         	movq	-0xd8(%rbp), %rax
   2dd32: b9 00 00 00 00               	movl	$0x0, %ecx
   2dd37: ba 01 00 00 00               	movl	$0x1, %edx
   2dd3c: 48 89 c7                     	movq	%rax, %rdi
   2dd3f: e8 96 a5 01 00               	callq	0x482da <__Pyx_PyInt_AndObjC>
   2dd44: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2dd48: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2dd4d: 0f 94 c0                     	sete	%al
   2dd50: 0f b6 c0                     	movzbl	%al, %eax
   2dd53: 48 85 c0                     	testq	%rax, %rax
   2dd56: 74 27                        	je	0x2dd7f <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xb87>
   2dd58: 48 8b 05 89 17 22 00         	movq	0x221789(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2dd5f: 48 89 05 e2 3d 22 00         	movq	%rax, 0x223de2(%rip)    # 0x251b48 <__pyx_filename>
   2dd66: c7 05 d0 3d 22 00 41 01 00 00	movl	$0x141, 0x223dd0(%rip)  # imm = 0x141
                                                                        # 0x251b40 <__pyx_lineno>
   2dd70: c7 05 ca 3d 22 00 5d 25 00 00	movl	$0x255d, 0x223dca(%rip) # imm = 0x255D
                                                                        # 0x251b44 <__pyx_clineno>
   2dd7a: e9 36 1a 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2dd7f: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2dd83: 48 89 85 48 ff ff ff         	movq	%rax, -0xb8(%rbp)
   2dd8a: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2dd92: 48 8b 85 48 ff ff ff         	movq	-0xb8(%rbp), %rax
   2dd99: 48 89 c7                     	movq	%rax, %rdi
   2dd9c: e8 96 dc 01 00               	callq	0x4ba37 <__Pyx_PyObject_IsTrue>
   2dda1: 89 85 24 ff ff ff            	movl	%eax, -0xdc(%rbp)
   2dda7: 8b 85 24 ff ff ff            	movl	-0xdc(%rbp), %eax
   2ddad: c1 e8 1f                     	shrl	$0x1f, %eax
   2ddb0: 0f b6 c0                     	movzbl	%al, %eax
   2ddb3: 48 85 c0                     	testq	%rax, %rax
   2ddb6: 74 27                        	je	0x2dddf <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xbe7>
   2ddb8: 48 8b 05 29 17 22 00         	movq	0x221729(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2ddbf: 48 89 05 82 3d 22 00         	movq	%rax, 0x223d82(%rip)    # 0x251b48 <__pyx_filename>
   2ddc6: c7 05 70 3d 22 00 42 01 00 00	movl	$0x142, 0x223d70(%rip)  # imm = 0x142
                                                                        # 0x251b40 <__pyx_lineno>
   2ddd0: c7 05 6a 3d 22 00 69 25 00 00	movl	$0x2569, 0x223d6a(%rip) # imm = 0x2569
                                                                        # 0x251b44 <__pyx_clineno>
   2ddda: e9 d6 19 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2dddf: 83 bd 24 ff ff ff 00         	cmpl	$0x0, -0xdc(%rbp)
   2dde6: 75 25                        	jne	0x2de0d <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xc15>
   2dde8: 48 8b 85 48 ff ff ff         	movq	-0xb8(%rbp), %rax
   2ddef: 48 8b 00                     	movq	(%rax), %rax
   2ddf2: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   2ddf6: 48 8b 85 48 ff ff ff         	movq	-0xb8(%rbp), %rax
   2ddfd: 48 89 10                     	movq	%rdx, (%rax)
   2de00: 48 8b 85 48 ff ff ff         	movq	-0xb8(%rbp), %rax
   2de07: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2de0b: eb 55                        	jmp	0x2de62 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xc6a>
   2de0d: bf 04 00 00 00               	movl	$0x4, %edi
   2de12: e8 11 d6 01 00               	callq	0x4b428 <__Pyx_PyInt_From_long>
   2de17: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2de1b: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2de20: 0f 94 c0                     	sete	%al
   2de23: 0f b6 c0                     	movzbl	%al, %eax
   2de26: 48 85 c0                     	testq	%rax, %rax
   2de29: 74 27                        	je	0x2de52 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xc5a>
   2de2b: 48 8b 05 b6 16 22 00         	movq	0x2216b6(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2de32: 48 89 05 0f 3d 22 00         	movq	%rax, 0x223d0f(%rip)    # 0x251b48 <__pyx_filename>
   2de39: c7 05 fd 3c 22 00 42 01 00 00	movl	$0x142, 0x223cfd(%rip)  # imm = 0x142
                                                                        # 0x251b40 <__pyx_lineno>
   2de43: c7 05 f7 3c 22 00 70 25 00 00	movl	$0x2570, 0x223cf7(%rip) # imm = 0x2570
                                                                        # 0x251b44 <__pyx_clineno>
   2de4d: e9 63 19 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2de52: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2de56: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2de5a: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2de62: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2de66: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2de6d: 48 89 d6                     	movq	%rdx, %rsi
   2de70: 48 89 c7                     	movq	%rax, %rdi
   2de73: e8 40 7d fd ff               	callq	0x5bb8 <PyNumber_InPlaceAdd@plt>
   2de78: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2de7c: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2de81: 0f 94 c0                     	sete	%al
   2de84: 0f b6 c0                     	movzbl	%al, %eax
   2de87: 48 85 c0                     	testq	%rax, %rax
   2de8a: 74 27                        	je	0x2deb3 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xcbb>
   2de8c: 48 8b 05 55 16 22 00         	movq	0x221655(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2de93: 48 89 05 ae 3c 22 00         	movq	%rax, 0x223cae(%rip)    # 0x251b48 <__pyx_filename>
   2de9a: c7 05 9c 3c 22 00 42 01 00 00	movl	$0x142, 0x223c9c(%rip)  # imm = 0x142
                                                                        # 0x251b40 <__pyx_lineno>
   2dea4: c7 05 96 3c 22 00 75 25 00 00	movl	$0x2575, 0x223c96(%rip) # imm = 0x2575
                                                                        # 0x251b44 <__pyx_clineno>
   2deae: e9 02 19 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2deb3: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2deb7: 48 8b 00                     	movq	(%rax), %rax
   2deba: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2debe: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2dec2: 48 89 10                     	movq	%rdx, (%rax)
   2dec5: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2dec9: 48 8b 00                     	movq	(%rax), %rax
   2decc: 48 85 c0                     	testq	%rax, %rax
   2decf: 75 15                        	jne	0x2dee6 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xcee>
   2ded1: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2ded5: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2ded9: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2dedd: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2dee1: 48 89 d7                     	movq	%rdx, %rdi
   2dee4: ff d0                        	callq	*%rax
   2dee6: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2deee: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2def5: 48 89 45 a8                  	movq	%rax, -0x58(%rbp)
   2def9: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2defd: 48 89 85 38 ff ff ff         	movq	%rax, -0xc8(%rbp)
   2df04: 48 8b 45 a8                  	movq	-0x58(%rbp), %rax
   2df08: 48 8b 00                     	movq	(%rax), %rax
   2df0b: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2df0f: 48 8b 45 a8                  	movq	-0x58(%rbp), %rax
   2df13: 48 89 10                     	movq	%rdx, (%rax)
   2df16: 48 8b 45 a8                  	movq	-0x58(%rbp), %rax
   2df1a: 48 8b 00                     	movq	(%rax), %rax
   2df1d: 48 85 c0                     	testq	%rax, %rax
   2df20: 75 15                        	jne	0x2df37 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xd3f>
   2df22: 48 8b 45 a8                  	movq	-0x58(%rbp), %rax
   2df26: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2df2a: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2df2e: 48 8b 55 a8                  	movq	-0x58(%rbp), %rdx
   2df32: 48 89 d7                     	movq	%rdx, %rdi
   2df35: ff d0                        	callq	*%rax
   2df37: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2df3f: 48 8b 35 12 43 22 00         	movq	0x224312(%rip), %rsi    # 0x252258 <__pyx_int_553664776>
   2df46: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   2df4d: b9 00 00 00 00               	movl	$0x0, %ecx
   2df52: ba 08 41 00 21               	movl	$0x21004108, %edx       # imm = 0x21004108
   2df57: 48 89 c7                     	movq	%rax, %rdi
   2df5a: e8 7b a3 01 00               	callq	0x482da <__Pyx_PyInt_AndObjC>
   2df5f: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2df63: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2df68: 0f 94 c0                     	sete	%al
   2df6b: 0f b6 c0                     	movzbl	%al, %eax
   2df6e: 48 85 c0                     	testq	%rax, %rax
   2df71: 74 27                        	je	0x2df9a <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xda2>
   2df73: 48 8b 05 6e 15 22 00         	movq	0x22156e(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2df7a: 48 89 05 c7 3b 22 00         	movq	%rax, 0x223bc7(%rip)    # 0x251b48 <__pyx_filename>
   2df81: c7 05 b5 3b 22 00 46 01 00 00	movl	$0x146, 0x223bb5(%rip)  # imm = 0x146
                                                                        # 0x251b40 <__pyx_lineno>
   2df8b: c7 05 af 3b 22 00 82 25 00 00	movl	$0x2582, 0x223baf(%rip) # imm = 0x2582
                                                                        # 0x251b44 <__pyx_clineno>
   2df95: e9 1b 18 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2df9a: bf 01 00 00 00               	movl	$0x1, %edi
   2df9f: e8 ac 79 fd ff               	callq	0x5950 <PyTuple_New@plt>
   2dfa4: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2dfa8: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2dfad: 0f 94 c0                     	sete	%al
   2dfb0: 0f b6 c0                     	movzbl	%al, %eax
   2dfb3: 48 85 c0                     	testq	%rax, %rax
   2dfb6: 74 27                        	je	0x2dfdf <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xde7>
   2dfb8: 48 8b 05 29 15 22 00         	movq	0x221529(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2dfbf: 48 89 05 82 3b 22 00         	movq	%rax, 0x223b82(%rip)    # 0x251b48 <__pyx_filename>
   2dfc6: c7 05 70 3b 22 00 46 01 00 00	movl	$0x146, 0x223b70(%rip)  # imm = 0x146
                                                                        # 0x251b40 <__pyx_lineno>
   2dfd0: c7 05 6a 3b 22 00 84 25 00 00	movl	$0x2584, 0x223b6a(%rip) # imm = 0x2584
                                                                        # 0x251b44 <__pyx_clineno>
   2dfda: e9 d6 17 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2dfdf: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2dfe3: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2dfe7: 48 89 50 18                  	movq	%rdx, 0x18(%rax)
   2dfeb: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2dff3: 48 8b 05 8e 3b 22 00         	movq	0x223b8e(%rip), %rax    # 0x251b88 <__pyx_builtin_bin>
   2dffa: 48 8b 4d 88                  	movq	-0x78(%rbp), %rcx
   2dffe: ba 00 00 00 00               	movl	$0x0, %edx
   2e003: 48 89 ce                     	movq	%rcx, %rsi
   2e006: 48 89 c7                     	movq	%rax, %rdi
   2e009: e8 18 85 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   2e00e: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2e012: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2e017: 0f 94 c0                     	sete	%al
   2e01a: 0f b6 c0                     	movzbl	%al, %eax
   2e01d: 48 85 c0                     	testq	%rax, %rax
   2e020: 74 27                        	je	0x2e049 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xe51>
   2e022: 48 8b 05 bf 14 22 00         	movq	0x2214bf(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2e029: 48 89 05 18 3b 22 00         	movq	%rax, 0x223b18(%rip)    # 0x251b48 <__pyx_filename>
   2e030: c7 05 06 3b 22 00 46 01 00 00	movl	$0x146, 0x223b06(%rip)  # imm = 0x146
                                                                        # 0x251b40 <__pyx_lineno>
   2e03a: c7 05 00 3b 22 00 89 25 00 00	movl	$0x2589, 0x223b00(%rip) # imm = 0x2589
                                                                        # 0x251b44 <__pyx_clineno>
   2e044: e9 6c 17 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2e049: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e04d: 48 8b 00                     	movq	(%rax), %rax
   2e050: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2e054: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e058: 48 89 10                     	movq	%rdx, (%rax)
   2e05b: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e05f: 48 8b 00                     	movq	(%rax), %rax
   2e062: 48 85 c0                     	testq	%rax, %rax
   2e065: 75 15                        	jne	0x2e07c <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xe84>
   2e067: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e06b: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2e06f: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2e073: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2e077: 48 89 d7                     	movq	%rdx, %rdi
   2e07a: ff d0                        	callq	*%rax
   2e07c: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2e084: 48 8b 15 15 3d 22 00         	movq	0x223d15(%rip), %rdx    # 0x251da0 <__pyx_n_s_count>
   2e08b: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e08f: 48 89 d6                     	movq	%rdx, %rsi
   2e092: 48 89 c7                     	movq	%rax, %rdi
   2e095: e8 30 7c fd ff               	callq	0x5cca <__Pyx_PyObject_GetAttrStr>
   2e09a: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2e09e: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2e0a3: 0f 94 c0                     	sete	%al
   2e0a6: 0f b6 c0                     	movzbl	%al, %eax
   2e0a9: 48 85 c0                     	testq	%rax, %rax
   2e0ac: 74 27                        	je	0x2e0d5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xedd>
   2e0ae: 48 8b 05 33 14 22 00         	movq	0x221433(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2e0b5: 48 89 05 8c 3a 22 00         	movq	%rax, 0x223a8c(%rip)    # 0x251b48 <__pyx_filename>
   2e0bc: c7 05 7a 3a 22 00 46 01 00 00	movl	$0x146, 0x223a7a(%rip)  # imm = 0x146
                                                                        # 0x251b40 <__pyx_lineno>
   2e0c6: c7 05 74 3a 22 00 8c 25 00 00	movl	$0x258c, 0x223a74(%rip) # imm = 0x258C
                                                                        # 0x251b44 <__pyx_clineno>
   2e0d0: e9 e0 16 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2e0d5: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e0d9: 48 8b 00                     	movq	(%rax), %rax
   2e0dc: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2e0e0: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e0e4: 48 89 10                     	movq	%rdx, (%rax)
   2e0e7: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e0eb: 48 8b 00                     	movq	(%rax), %rax
   2e0ee: 48 85 c0                     	testq	%rax, %rax
   2e0f1: 75 15                        	jne	0x2e108 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xf10>
   2e0f3: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e0f7: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2e0fb: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2e0ff: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2e103: 48 89 d7                     	movq	%rdx, %rdi
   2e106: ff d0                        	callq	*%rax
   2e108: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2e110: 48 8b 0d 99 42 22 00         	movq	0x224299(%rip), %rcx    # 0x2523b0 <__pyx_tuple__37>
   2e117: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e11b: ba 00 00 00 00               	movl	$0x0, %edx
   2e120: 48 89 ce                     	movq	%rcx, %rsi
   2e123: 48 89 c7                     	movq	%rax, %rdi
   2e126: e8 fb 83 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   2e12b: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2e12f: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2e134: 0f 94 c0                     	sete	%al
   2e137: 0f b6 c0                     	movzbl	%al, %eax
   2e13a: 48 85 c0                     	testq	%rax, %rax
   2e13d: 74 27                        	je	0x2e166 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xf6e>
   2e13f: 48 8b 05 a2 13 22 00         	movq	0x2213a2(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2e146: 48 89 05 fb 39 22 00         	movq	%rax, 0x2239fb(%rip)    # 0x251b48 <__pyx_filename>
   2e14d: c7 05 e9 39 22 00 46 01 00 00	movl	$0x146, 0x2239e9(%rip)  # imm = 0x146
                                                                        # 0x251b40 <__pyx_lineno>
   2e157: c7 05 e3 39 22 00 8f 25 00 00	movl	$0x258f, 0x2239e3(%rip) # imm = 0x258F
                                                                        # 0x251b44 <__pyx_clineno>
   2e161: e9 4f 16 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2e166: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e16a: 48 8b 00                     	movq	(%rax), %rax
   2e16d: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2e171: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e175: 48 89 10                     	movq	%rdx, (%rax)
   2e178: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e17c: 48 8b 00                     	movq	(%rax), %rax
   2e17f: 48 85 c0                     	testq	%rax, %rax
   2e182: 75 15                        	jne	0x2e199 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xfa1>
   2e184: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e188: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2e18c: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2e190: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2e194: 48 89 d7                     	movq	%rdx, %rdi
   2e197: ff d0                        	callq	*%rax
   2e199: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2e1a1: 48 8b 85 28 ff ff ff         	movq	-0xd8(%rbp), %rax
   2e1a8: 48 89 45 b0                  	movq	%rax, -0x50(%rbp)
   2e1ac: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e1b0: 48 89 85 28 ff ff ff         	movq	%rax, -0xd8(%rbp)
   2e1b7: 48 8b 45 b0                  	movq	-0x50(%rbp), %rax
   2e1bb: 48 8b 00                     	movq	(%rax), %rax
   2e1be: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2e1c2: 48 8b 45 b0                  	movq	-0x50(%rbp), %rax
   2e1c6: 48 89 10                     	movq	%rdx, (%rax)
   2e1c9: 48 8b 45 b0                  	movq	-0x50(%rbp), %rax
   2e1cd: 48 8b 00                     	movq	(%rax), %rax
   2e1d0: 48 85 c0                     	testq	%rax, %rax
   2e1d3: 75 15                        	jne	0x2e1ea <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0xff2>
   2e1d5: 48 8b 45 b0                  	movq	-0x50(%rbp), %rax
   2e1d9: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2e1dd: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2e1e1: 48 8b 55 b0                  	movq	-0x50(%rbp), %rdx
   2e1e5: 48 89 d7                     	movq	%rdx, %rdi
   2e1e8: ff d0                        	callq	*%rax
   2e1ea: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2e1f2: 48 8b 35 4f 3f 22 00         	movq	0x223f4f(%rip), %rsi    # 0x252148 <__pyx_int_1>
   2e1f9: 48 8b 85 28 ff ff ff         	movq	-0xd8(%rbp), %rax
   2e200: b9 00 00 00 00               	movl	$0x0, %ecx
   2e205: ba 01 00 00 00               	movl	$0x1, %edx
   2e20a: 48 89 c7                     	movq	%rax, %rdi
   2e20d: e8 c8 a0 01 00               	callq	0x482da <__Pyx_PyInt_AndObjC>
   2e212: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2e216: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2e21b: 0f 94 c0                     	sete	%al
   2e21e: 0f b6 c0                     	movzbl	%al, %eax
   2e221: 48 85 c0                     	testq	%rax, %rax
   2e224: 74 27                        	je	0x2e24d <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1055>
   2e226: 48 8b 05 bb 12 22 00         	movq	0x2212bb(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2e22d: 48 89 05 14 39 22 00         	movq	%rax, 0x223914(%rip)    # 0x251b48 <__pyx_filename>
   2e234: c7 05 02 39 22 00 48 01 00 00	movl	$0x148, 0x223902(%rip)  # imm = 0x148
                                                                        # 0x251b40 <__pyx_lineno>
   2e23e: c7 05 fc 38 22 00 9c 25 00 00	movl	$0x259c, 0x2238fc(%rip) # imm = 0x259C
                                                                        # 0x251b44 <__pyx_clineno>
   2e248: e9 68 15 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2e24d: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e251: 48 89 85 50 ff ff ff         	movq	%rax, -0xb0(%rbp)
   2e258: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2e260: 48 8b 85 50 ff ff ff         	movq	-0xb0(%rbp), %rax
   2e267: 48 89 c7                     	movq	%rax, %rdi
   2e26a: e8 c8 d7 01 00               	callq	0x4ba37 <__Pyx_PyObject_IsTrue>
   2e26f: 89 85 24 ff ff ff            	movl	%eax, -0xdc(%rbp)
   2e275: 8b 85 24 ff ff ff            	movl	-0xdc(%rbp), %eax
   2e27b: c1 e8 1f                     	shrl	$0x1f, %eax
   2e27e: 0f b6 c0                     	movzbl	%al, %eax
   2e281: 48 85 c0                     	testq	%rax, %rax
   2e284: 74 27                        	je	0x2e2ad <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x10b5>
   2e286: 48 8b 05 5b 12 22 00         	movq	0x22125b(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2e28d: 48 89 05 b4 38 22 00         	movq	%rax, 0x2238b4(%rip)    # 0x251b48 <__pyx_filename>
   2e294: c7 05 a2 38 22 00 49 01 00 00	movl	$0x149, 0x2238a2(%rip)  # imm = 0x149
                                                                        # 0x251b40 <__pyx_lineno>
   2e29e: c7 05 9c 38 22 00 a8 25 00 00	movl	$0x25a8, 0x22389c(%rip) # imm = 0x25A8
                                                                        # 0x251b44 <__pyx_clineno>
   2e2a8: e9 08 15 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2e2ad: 83 bd 24 ff ff ff 00         	cmpl	$0x0, -0xdc(%rbp)
   2e2b4: 75 25                        	jne	0x2e2db <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x10e3>
   2e2b6: 48 8b 85 50 ff ff ff         	movq	-0xb0(%rbp), %rax
   2e2bd: 48 8b 00                     	movq	(%rax), %rax
   2e2c0: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   2e2c4: 48 8b 85 50 ff ff ff         	movq	-0xb0(%rbp), %rax
   2e2cb: 48 89 10                     	movq	%rdx, (%rax)
   2e2ce: 48 8b 85 50 ff ff ff         	movq	-0xb0(%rbp), %rax
   2e2d5: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2e2d9: eb 55                        	jmp	0x2e330 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1138>
   2e2db: bf 08 00 00 00               	movl	$0x8, %edi
   2e2e0: e8 43 d1 01 00               	callq	0x4b428 <__Pyx_PyInt_From_long>
   2e2e5: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2e2e9: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2e2ee: 0f 94 c0                     	sete	%al
   2e2f1: 0f b6 c0                     	movzbl	%al, %eax
   2e2f4: 48 85 c0                     	testq	%rax, %rax
   2e2f7: 74 27                        	je	0x2e320 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1128>
   2e2f9: 48 8b 05 e8 11 22 00         	movq	0x2211e8(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2e300: 48 89 05 41 38 22 00         	movq	%rax, 0x223841(%rip)    # 0x251b48 <__pyx_filename>
   2e307: c7 05 2f 38 22 00 49 01 00 00	movl	$0x149, 0x22382f(%rip)  # imm = 0x149
                                                                        # 0x251b40 <__pyx_lineno>
   2e311: c7 05 29 38 22 00 af 25 00 00	movl	$0x25af, 0x223829(%rip) # imm = 0x25AF
                                                                        # 0x251b44 <__pyx_clineno>
   2e31b: e9 95 14 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2e320: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e324: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2e328: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2e330: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2e334: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2e33b: 48 89 d6                     	movq	%rdx, %rsi
   2e33e: 48 89 c7                     	movq	%rax, %rdi
   2e341: e8 72 78 fd ff               	callq	0x5bb8 <PyNumber_InPlaceAdd@plt>
   2e346: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2e34a: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2e34f: 0f 94 c0                     	sete	%al
   2e352: 0f b6 c0                     	movzbl	%al, %eax
   2e355: 48 85 c0                     	testq	%rax, %rax
   2e358: 74 27                        	je	0x2e381 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1189>
   2e35a: 48 8b 05 87 11 22 00         	movq	0x221187(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2e361: 48 89 05 e0 37 22 00         	movq	%rax, 0x2237e0(%rip)    # 0x251b48 <__pyx_filename>
   2e368: c7 05 ce 37 22 00 49 01 00 00	movl	$0x149, 0x2237ce(%rip)  # imm = 0x149
                                                                        # 0x251b40 <__pyx_lineno>
   2e372: c7 05 c8 37 22 00 b4 25 00 00	movl	$0x25b4, 0x2237c8(%rip) # imm = 0x25B4
                                                                        # 0x251b44 <__pyx_clineno>
   2e37c: e9 34 14 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2e381: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e385: 48 8b 00                     	movq	(%rax), %rax
   2e388: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2e38c: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e390: 48 89 10                     	movq	%rdx, (%rax)
   2e393: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e397: 48 8b 00                     	movq	(%rax), %rax
   2e39a: 48 85 c0                     	testq	%rax, %rax
   2e39d: 75 15                        	jne	0x2e3b4 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x11bc>
   2e39f: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e3a3: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2e3a7: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2e3ab: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2e3af: 48 89 d7                     	movq	%rdx, %rdi
   2e3b2: ff d0                        	callq	*%rax
   2e3b4: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2e3bc: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2e3c3: 48 89 45 b8                  	movq	%rax, -0x48(%rbp)
   2e3c7: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e3cb: 48 89 85 38 ff ff ff         	movq	%rax, -0xc8(%rbp)
   2e3d2: 48 8b 45 b8                  	movq	-0x48(%rbp), %rax
   2e3d6: 48 8b 00                     	movq	(%rax), %rax
   2e3d9: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2e3dd: 48 8b 45 b8                  	movq	-0x48(%rbp), %rax
   2e3e1: 48 89 10                     	movq	%rdx, (%rax)
   2e3e4: 48 8b 45 b8                  	movq	-0x48(%rbp), %rax
   2e3e8: 48 8b 00                     	movq	(%rax), %rax
   2e3eb: 48 85 c0                     	testq	%rax, %rax
   2e3ee: 75 15                        	jne	0x2e405 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x120d>
   2e3f0: 48 8b 45 b8                  	movq	-0x48(%rbp), %rax
   2e3f4: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2e3f8: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2e3fc: 48 8b 55 b8                  	movq	-0x48(%rbp), %rdx
   2e400: 48 89 d7                     	movq	%rdx, %rdi
   2e403: ff d0                        	callq	*%rax
   2e405: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2e40d: 48 8b 15 4c 3e 22 00         	movq	0x223e4c(%rip), %rdx    # 0x252260 <__pyx_int_2181071376>
   2e414: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   2e41b: 48 89 d6                     	movq	%rdx, %rsi
   2e41e: 48 89 c7                     	movq	%rax, %rdi
   2e421: e8 a2 77 fd ff               	callq	0x5bc8 <PyNumber_And@plt>
   2e426: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2e42a: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2e42f: 0f 94 c0                     	sete	%al
   2e432: 0f b6 c0                     	movzbl	%al, %eax
   2e435: 48 85 c0                     	testq	%rax, %rax
   2e438: 74 27                        	je	0x2e461 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1269>
   2e43a: 48 8b 05 a7 10 22 00         	movq	0x2210a7(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2e441: 48 89 05 00 37 22 00         	movq	%rax, 0x223700(%rip)    # 0x251b48 <__pyx_filename>
   2e448: c7 05 ee 36 22 00 4d 01 00 00	movl	$0x14d, 0x2236ee(%rip)  # imm = 0x14D
                                                                        # 0x251b40 <__pyx_lineno>
   2e452: c7 05 e8 36 22 00 c1 25 00 00	movl	$0x25c1, 0x2236e8(%rip) # imm = 0x25C1
                                                                        # 0x251b44 <__pyx_clineno>
   2e45c: e9 54 13 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2e461: bf 01 00 00 00               	movl	$0x1, %edi
   2e466: e8 e5 74 fd ff               	callq	0x5950 <PyTuple_New@plt>
   2e46b: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2e46f: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2e474: 0f 94 c0                     	sete	%al
   2e477: 0f b6 c0                     	movzbl	%al, %eax
   2e47a: 48 85 c0                     	testq	%rax, %rax
   2e47d: 74 27                        	je	0x2e4a6 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x12ae>
   2e47f: 48 8b 05 62 10 22 00         	movq	0x221062(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2e486: 48 89 05 bb 36 22 00         	movq	%rax, 0x2236bb(%rip)    # 0x251b48 <__pyx_filename>
   2e48d: c7 05 a9 36 22 00 4d 01 00 00	movl	$0x14d, 0x2236a9(%rip)  # imm = 0x14D
                                                                        # 0x251b40 <__pyx_lineno>
   2e497: c7 05 a3 36 22 00 c3 25 00 00	movl	$0x25c3, 0x2236a3(%rip) # imm = 0x25C3
                                                                        # 0x251b44 <__pyx_clineno>
   2e4a1: e9 0f 13 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2e4a6: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e4aa: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2e4ae: 48 89 50 18                  	movq	%rdx, 0x18(%rax)
   2e4b2: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2e4ba: 48 8b 05 c7 36 22 00         	movq	0x2236c7(%rip), %rax    # 0x251b88 <__pyx_builtin_bin>
   2e4c1: 48 8b 4d 80                  	movq	-0x80(%rbp), %rcx
   2e4c5: ba 00 00 00 00               	movl	$0x0, %edx
   2e4ca: 48 89 ce                     	movq	%rcx, %rsi
   2e4cd: 48 89 c7                     	movq	%rax, %rdi
   2e4d0: e8 51 80 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   2e4d5: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2e4d9: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2e4de: 0f 94 c0                     	sete	%al
   2e4e1: 0f b6 c0                     	movzbl	%al, %eax
   2e4e4: 48 85 c0                     	testq	%rax, %rax
   2e4e7: 74 27                        	je	0x2e510 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1318>
   2e4e9: 48 8b 05 f8 0f 22 00         	movq	0x220ff8(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2e4f0: 48 89 05 51 36 22 00         	movq	%rax, 0x223651(%rip)    # 0x251b48 <__pyx_filename>
   2e4f7: c7 05 3f 36 22 00 4d 01 00 00	movl	$0x14d, 0x22363f(%rip)  # imm = 0x14D
                                                                        # 0x251b40 <__pyx_lineno>
   2e501: c7 05 39 36 22 00 c8 25 00 00	movl	$0x25c8, 0x223639(%rip) # imm = 0x25C8
                                                                        # 0x251b44 <__pyx_clineno>
   2e50b: e9 a5 12 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2e510: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e514: 48 8b 00                     	movq	(%rax), %rax
   2e517: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2e51b: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e51f: 48 89 10                     	movq	%rdx, (%rax)
   2e522: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e526: 48 8b 00                     	movq	(%rax), %rax
   2e529: 48 85 c0                     	testq	%rax, %rax
   2e52c: 75 15                        	jne	0x2e543 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x134b>
   2e52e: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e532: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2e536: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2e53a: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2e53e: 48 89 d7                     	movq	%rdx, %rdi
   2e541: ff d0                        	callq	*%rax
   2e543: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2e54b: 48 8b 15 4e 38 22 00         	movq	0x22384e(%rip), %rdx    # 0x251da0 <__pyx_n_s_count>
   2e552: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e556: 48 89 d6                     	movq	%rdx, %rsi
   2e559: 48 89 c7                     	movq	%rax, %rdi
   2e55c: e8 69 77 fd ff               	callq	0x5cca <__Pyx_PyObject_GetAttrStr>
   2e561: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2e565: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2e56a: 0f 94 c0                     	sete	%al
   2e56d: 0f b6 c0                     	movzbl	%al, %eax
   2e570: 48 85 c0                     	testq	%rax, %rax
   2e573: 74 27                        	je	0x2e59c <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x13a4>
   2e575: 48 8b 05 6c 0f 22 00         	movq	0x220f6c(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2e57c: 48 89 05 c5 35 22 00         	movq	%rax, 0x2235c5(%rip)    # 0x251b48 <__pyx_filename>
   2e583: c7 05 b3 35 22 00 4d 01 00 00	movl	$0x14d, 0x2235b3(%rip)  # imm = 0x14D
                                                                        # 0x251b40 <__pyx_lineno>
   2e58d: c7 05 ad 35 22 00 cb 25 00 00	movl	$0x25cb, 0x2235ad(%rip) # imm = 0x25CB
                                                                        # 0x251b44 <__pyx_clineno>
   2e597: e9 19 12 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2e59c: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e5a0: 48 8b 00                     	movq	(%rax), %rax
   2e5a3: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2e5a7: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e5ab: 48 89 10                     	movq	%rdx, (%rax)
   2e5ae: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e5b2: 48 8b 00                     	movq	(%rax), %rax
   2e5b5: 48 85 c0                     	testq	%rax, %rax
   2e5b8: 75 15                        	jne	0x2e5cf <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x13d7>
   2e5ba: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e5be: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2e5c2: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2e5c6: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2e5ca: 48 89 d7                     	movq	%rdx, %rdi
   2e5cd: ff d0                        	callq	*%rax
   2e5cf: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2e5d7: 48 8b 0d da 3d 22 00         	movq	0x223dda(%rip), %rcx    # 0x2523b8 <__pyx_tuple__38>
   2e5de: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e5e2: ba 00 00 00 00               	movl	$0x0, %edx
   2e5e7: 48 89 ce                     	movq	%rcx, %rsi
   2e5ea: 48 89 c7                     	movq	%rax, %rdi
   2e5ed: e8 34 7f 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   2e5f2: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2e5f6: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2e5fb: 0f 94 c0                     	sete	%al
   2e5fe: 0f b6 c0                     	movzbl	%al, %eax
   2e601: 48 85 c0                     	testq	%rax, %rax
   2e604: 74 27                        	je	0x2e62d <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1435>
   2e606: 48 8b 05 db 0e 22 00         	movq	0x220edb(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2e60d: 48 89 05 34 35 22 00         	movq	%rax, 0x223534(%rip)    # 0x251b48 <__pyx_filename>
   2e614: c7 05 22 35 22 00 4d 01 00 00	movl	$0x14d, 0x223522(%rip)  # imm = 0x14D
                                                                        # 0x251b40 <__pyx_lineno>
   2e61e: c7 05 1c 35 22 00 ce 25 00 00	movl	$0x25ce, 0x22351c(%rip) # imm = 0x25CE
                                                                        # 0x251b44 <__pyx_clineno>
   2e628: e9 88 11 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2e62d: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e631: 48 8b 00                     	movq	(%rax), %rax
   2e634: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2e638: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e63c: 48 89 10                     	movq	%rdx, (%rax)
   2e63f: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e643: 48 8b 00                     	movq	(%rax), %rax
   2e646: 48 85 c0                     	testq	%rax, %rax
   2e649: 75 15                        	jne	0x2e660 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1468>
   2e64b: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e64f: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2e653: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2e657: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2e65b: 48 89 d7                     	movq	%rdx, %rdi
   2e65e: ff d0                        	callq	*%rax
   2e660: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2e668: 48 8b 85 28 ff ff ff         	movq	-0xd8(%rbp), %rax
   2e66f: 48 89 45 c0                  	movq	%rax, -0x40(%rbp)
   2e673: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e677: 48 89 85 28 ff ff ff         	movq	%rax, -0xd8(%rbp)
   2e67e: 48 8b 45 c0                  	movq	-0x40(%rbp), %rax
   2e682: 48 8b 00                     	movq	(%rax), %rax
   2e685: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2e689: 48 8b 45 c0                  	movq	-0x40(%rbp), %rax
   2e68d: 48 89 10                     	movq	%rdx, (%rax)
   2e690: 48 8b 45 c0                  	movq	-0x40(%rbp), %rax
   2e694: 48 8b 00                     	movq	(%rax), %rax
   2e697: 48 85 c0                     	testq	%rax, %rax
   2e69a: 75 15                        	jne	0x2e6b1 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x14b9>
   2e69c: 48 8b 45 c0                  	movq	-0x40(%rbp), %rax
   2e6a0: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2e6a4: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2e6a8: 48 8b 55 c0                  	movq	-0x40(%rbp), %rdx
   2e6ac: 48 89 d7                     	movq	%rdx, %rdi
   2e6af: ff d0                        	callq	*%rax
   2e6b1: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2e6b9: 48 8b 35 88 3a 22 00         	movq	0x223a88(%rip), %rsi    # 0x252148 <__pyx_int_1>
   2e6c0: 48 8b 85 28 ff ff ff         	movq	-0xd8(%rbp), %rax
   2e6c7: b9 00 00 00 00               	movl	$0x0, %ecx
   2e6cc: ba 01 00 00 00               	movl	$0x1, %edx
   2e6d1: 48 89 c7                     	movq	%rax, %rdi
   2e6d4: e8 01 9c 01 00               	callq	0x482da <__Pyx_PyInt_AndObjC>
   2e6d9: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2e6dd: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2e6e2: 0f 94 c0                     	sete	%al
   2e6e5: 0f b6 c0                     	movzbl	%al, %eax
   2e6e8: 48 85 c0                     	testq	%rax, %rax
   2e6eb: 74 27                        	je	0x2e714 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x151c>
   2e6ed: 48 8b 05 f4 0d 22 00         	movq	0x220df4(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2e6f4: 48 89 05 4d 34 22 00         	movq	%rax, 0x22344d(%rip)    # 0x251b48 <__pyx_filename>
   2e6fb: c7 05 3b 34 22 00 4f 01 00 00	movl	$0x14f, 0x22343b(%rip)  # imm = 0x14F
                                                                        # 0x251b40 <__pyx_lineno>
   2e705: c7 05 35 34 22 00 db 25 00 00	movl	$0x25db, 0x223435(%rip) # imm = 0x25DB
                                                                        # 0x251b44 <__pyx_clineno>
   2e70f: e9 a1 10 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2e714: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e718: 48 89 85 58 ff ff ff         	movq	%rax, -0xa8(%rbp)
   2e71f: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2e727: 48 8b 85 58 ff ff ff         	movq	-0xa8(%rbp), %rax
   2e72e: 48 89 c7                     	movq	%rax, %rdi
   2e731: e8 01 d3 01 00               	callq	0x4ba37 <__Pyx_PyObject_IsTrue>
   2e736: 89 85 24 ff ff ff            	movl	%eax, -0xdc(%rbp)
   2e73c: 8b 85 24 ff ff ff            	movl	-0xdc(%rbp), %eax
   2e742: c1 e8 1f                     	shrl	$0x1f, %eax
   2e745: 0f b6 c0                     	movzbl	%al, %eax
   2e748: 48 85 c0                     	testq	%rax, %rax
   2e74b: 74 27                        	je	0x2e774 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x157c>
   2e74d: 48 8b 05 94 0d 22 00         	movq	0x220d94(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2e754: 48 89 05 ed 33 22 00         	movq	%rax, 0x2233ed(%rip)    # 0x251b48 <__pyx_filename>
   2e75b: c7 05 db 33 22 00 50 01 00 00	movl	$0x150, 0x2233db(%rip)  # imm = 0x150
                                                                        # 0x251b40 <__pyx_lineno>
   2e765: c7 05 d5 33 22 00 e7 25 00 00	movl	$0x25e7, 0x2233d5(%rip) # imm = 0x25E7
                                                                        # 0x251b44 <__pyx_clineno>
   2e76f: e9 41 10 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2e774: 83 bd 24 ff ff ff 00         	cmpl	$0x0, -0xdc(%rbp)
   2e77b: 75 25                        	jne	0x2e7a2 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x15aa>
   2e77d: 48 8b 85 58 ff ff ff         	movq	-0xa8(%rbp), %rax
   2e784: 48 8b 00                     	movq	(%rax), %rax
   2e787: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   2e78b: 48 8b 85 58 ff ff ff         	movq	-0xa8(%rbp), %rax
   2e792: 48 89 10                     	movq	%rdx, (%rax)
   2e795: 48 8b 85 58 ff ff ff         	movq	-0xa8(%rbp), %rax
   2e79c: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2e7a0: eb 55                        	jmp	0x2e7f7 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x15ff>
   2e7a2: bf 10 00 00 00               	movl	$0x10, %edi
   2e7a7: e8 7c cc 01 00               	callq	0x4b428 <__Pyx_PyInt_From_long>
   2e7ac: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2e7b0: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2e7b5: 0f 94 c0                     	sete	%al
   2e7b8: 0f b6 c0                     	movzbl	%al, %eax
   2e7bb: 48 85 c0                     	testq	%rax, %rax
   2e7be: 74 27                        	je	0x2e7e7 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x15ef>
   2e7c0: 48 8b 05 21 0d 22 00         	movq	0x220d21(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2e7c7: 48 89 05 7a 33 22 00         	movq	%rax, 0x22337a(%rip)    # 0x251b48 <__pyx_filename>
   2e7ce: c7 05 68 33 22 00 50 01 00 00	movl	$0x150, 0x223368(%rip)  # imm = 0x150
                                                                        # 0x251b40 <__pyx_lineno>
   2e7d8: c7 05 62 33 22 00 ee 25 00 00	movl	$0x25ee, 0x223362(%rip) # imm = 0x25EE
                                                                        # 0x251b44 <__pyx_clineno>
   2e7e2: e9 ce 0f 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2e7e7: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e7eb: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2e7ef: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2e7f7: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2e7fb: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2e802: 48 89 d6                     	movq	%rdx, %rsi
   2e805: 48 89 c7                     	movq	%rax, %rdi
   2e808: e8 ab 73 fd ff               	callq	0x5bb8 <PyNumber_InPlaceAdd@plt>
   2e80d: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2e811: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2e816: 0f 94 c0                     	sete	%al
   2e819: 0f b6 c0                     	movzbl	%al, %eax
   2e81c: 48 85 c0                     	testq	%rax, %rax
   2e81f: 74 27                        	je	0x2e848 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1650>
   2e821: 48 8b 05 c0 0c 22 00         	movq	0x220cc0(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2e828: 48 89 05 19 33 22 00         	movq	%rax, 0x223319(%rip)    # 0x251b48 <__pyx_filename>
   2e82f: c7 05 07 33 22 00 50 01 00 00	movl	$0x150, 0x223307(%rip)  # imm = 0x150
                                                                        # 0x251b40 <__pyx_lineno>
   2e839: c7 05 01 33 22 00 f3 25 00 00	movl	$0x25f3, 0x223301(%rip) # imm = 0x25F3
                                                                        # 0x251b44 <__pyx_clineno>
   2e843: e9 6d 0f 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2e848: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e84c: 48 8b 00                     	movq	(%rax), %rax
   2e84f: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2e853: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e857: 48 89 10                     	movq	%rdx, (%rax)
   2e85a: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e85e: 48 8b 00                     	movq	(%rax), %rax
   2e861: 48 85 c0                     	testq	%rax, %rax
   2e864: 75 15                        	jne	0x2e87b <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1683>
   2e866: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e86a: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2e86e: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2e872: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2e876: 48 89 d7                     	movq	%rdx, %rdi
   2e879: ff d0                        	callq	*%rax
   2e87b: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2e883: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2e88a: 48 89 45 c8                  	movq	%rax, -0x38(%rbp)
   2e88e: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2e892: 48 89 85 38 ff ff ff         	movq	%rax, -0xc8(%rbp)
   2e899: 48 8b 45 c8                  	movq	-0x38(%rbp), %rax
   2e89d: 48 8b 00                     	movq	(%rax), %rax
   2e8a0: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2e8a4: 48 8b 45 c8                  	movq	-0x38(%rbp), %rax
   2e8a8: 48 89 10                     	movq	%rdx, (%rax)
   2e8ab: 48 8b 45 c8                  	movq	-0x38(%rbp), %rax
   2e8af: 48 8b 00                     	movq	(%rax), %rax
   2e8b2: 48 85 c0                     	testq	%rax, %rax
   2e8b5: 75 15                        	jne	0x2e8cc <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x16d4>
   2e8b7: 48 8b 45 c8                  	movq	-0x38(%rbp), %rax
   2e8bb: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2e8bf: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2e8c3: 48 8b 55 c8                  	movq	-0x38(%rbp), %rdx
   2e8c7: 48 89 d7                     	movq	%rdx, %rdi
   2e8ca: ff d0                        	callq	*%rax
   2e8cc: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2e8d4: 48 8b 35 4d 39 22 00         	movq	0x22394d(%rip), %rsi    # 0x252228 <__pyx_int_67109920>
   2e8db: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   2e8e2: b9 00 00 00 00               	movl	$0x0, %ecx
   2e8e7: ba 20 04 00 04               	movl	$0x4000420, %edx        # imm = 0x4000420
   2e8ec: 48 89 c7                     	movq	%rax, %rdi
   2e8ef: e8 e6 99 01 00               	callq	0x482da <__Pyx_PyInt_AndObjC>
   2e8f4: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2e8f8: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2e8fd: 0f 94 c0                     	sete	%al
   2e900: 0f b6 c0                     	movzbl	%al, %eax
   2e903: 48 85 c0                     	testq	%rax, %rax
   2e906: 74 27                        	je	0x2e92f <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1737>
   2e908: 48 8b 05 d9 0b 22 00         	movq	0x220bd9(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2e90f: 48 89 05 32 32 22 00         	movq	%rax, 0x223232(%rip)    # 0x251b48 <__pyx_filename>
   2e916: c7 05 20 32 22 00 54 01 00 00	movl	$0x154, 0x223220(%rip)  # imm = 0x154
                                                                        # 0x251b40 <__pyx_lineno>
   2e920: c7 05 1a 32 22 00 00 26 00 00	movl	$0x2600, 0x22321a(%rip) # imm = 0x2600
                                                                        # 0x251b44 <__pyx_clineno>
   2e92a: e9 86 0e 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2e92f: bf 01 00 00 00               	movl	$0x1, %edi
   2e934: e8 17 70 fd ff               	callq	0x5950 <PyTuple_New@plt>
   2e939: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2e93d: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2e942: 0f 94 c0                     	sete	%al
   2e945: 0f b6 c0                     	movzbl	%al, %eax
   2e948: 48 85 c0                     	testq	%rax, %rax
   2e94b: 74 27                        	je	0x2e974 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x177c>
   2e94d: 48 8b 05 94 0b 22 00         	movq	0x220b94(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2e954: 48 89 05 ed 31 22 00         	movq	%rax, 0x2231ed(%rip)    # 0x251b48 <__pyx_filename>
   2e95b: c7 05 db 31 22 00 54 01 00 00	movl	$0x154, 0x2231db(%rip)  # imm = 0x154
                                                                        # 0x251b40 <__pyx_lineno>
   2e965: c7 05 d5 31 22 00 02 26 00 00	movl	$0x2602, 0x2231d5(%rip) # imm = 0x2602
                                                                        # 0x251b44 <__pyx_clineno>
   2e96f: e9 41 0e 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2e974: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e978: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2e97c: 48 89 50 18                  	movq	%rdx, 0x18(%rax)
   2e980: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2e988: 48 8b 05 f9 31 22 00         	movq	0x2231f9(%rip), %rax    # 0x251b88 <__pyx_builtin_bin>
   2e98f: 48 8b 4d 88                  	movq	-0x78(%rbp), %rcx
   2e993: ba 00 00 00 00               	movl	$0x0, %edx
   2e998: 48 89 ce                     	movq	%rcx, %rsi
   2e99b: 48 89 c7                     	movq	%rax, %rdi
   2e99e: e8 83 7b 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   2e9a3: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2e9a7: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2e9ac: 0f 94 c0                     	sete	%al
   2e9af: 0f b6 c0                     	movzbl	%al, %eax
   2e9b2: 48 85 c0                     	testq	%rax, %rax
   2e9b5: 74 27                        	je	0x2e9de <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x17e6>
   2e9b7: 48 8b 05 2a 0b 22 00         	movq	0x220b2a(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2e9be: 48 89 05 83 31 22 00         	movq	%rax, 0x223183(%rip)    # 0x251b48 <__pyx_filename>
   2e9c5: c7 05 71 31 22 00 54 01 00 00	movl	$0x154, 0x223171(%rip)  # imm = 0x154
                                                                        # 0x251b40 <__pyx_lineno>
   2e9cf: c7 05 6b 31 22 00 07 26 00 00	movl	$0x2607, 0x22316b(%rip) # imm = 0x2607
                                                                        # 0x251b44 <__pyx_clineno>
   2e9d9: e9 d7 0d 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2e9de: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e9e2: 48 8b 00                     	movq	(%rax), %rax
   2e9e5: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2e9e9: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e9ed: 48 89 10                     	movq	%rdx, (%rax)
   2e9f0: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2e9f4: 48 8b 00                     	movq	(%rax), %rax
   2e9f7: 48 85 c0                     	testq	%rax, %rax
   2e9fa: 75 15                        	jne	0x2ea11 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1819>
   2e9fc: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2ea00: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2ea04: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2ea08: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2ea0c: 48 89 d7                     	movq	%rdx, %rdi
   2ea0f: ff d0                        	callq	*%rax
   2ea11: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2ea19: 48 8b 15 80 33 22 00         	movq	0x223380(%rip), %rdx    # 0x251da0 <__pyx_n_s_count>
   2ea20: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2ea24: 48 89 d6                     	movq	%rdx, %rsi
   2ea27: 48 89 c7                     	movq	%rax, %rdi
   2ea2a: e8 9b 72 fd ff               	callq	0x5cca <__Pyx_PyObject_GetAttrStr>
   2ea2f: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2ea33: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2ea38: 0f 94 c0                     	sete	%al
   2ea3b: 0f b6 c0                     	movzbl	%al, %eax
   2ea3e: 48 85 c0                     	testq	%rax, %rax
   2ea41: 74 27                        	je	0x2ea6a <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1872>
   2ea43: 48 8b 05 9e 0a 22 00         	movq	0x220a9e(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2ea4a: 48 89 05 f7 30 22 00         	movq	%rax, 0x2230f7(%rip)    # 0x251b48 <__pyx_filename>
   2ea51: c7 05 e5 30 22 00 54 01 00 00	movl	$0x154, 0x2230e5(%rip)  # imm = 0x154
                                                                        # 0x251b40 <__pyx_lineno>
   2ea5b: c7 05 df 30 22 00 0a 26 00 00	movl	$0x260a, 0x2230df(%rip) # imm = 0x260A
                                                                        # 0x251b44 <__pyx_clineno>
   2ea65: e9 4b 0d 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2ea6a: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2ea6e: 48 8b 00                     	movq	(%rax), %rax
   2ea71: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2ea75: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2ea79: 48 89 10                     	movq	%rdx, (%rax)
   2ea7c: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2ea80: 48 8b 00                     	movq	(%rax), %rax
   2ea83: 48 85 c0                     	testq	%rax, %rax
   2ea86: 75 15                        	jne	0x2ea9d <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x18a5>
   2ea88: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2ea8c: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2ea90: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2ea94: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2ea98: 48 89 d7                     	movq	%rdx, %rdi
   2ea9b: ff d0                        	callq	*%rax
   2ea9d: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2eaa5: 48 8b 0d 14 39 22 00         	movq	0x223914(%rip), %rcx    # 0x2523c0 <__pyx_tuple__39>
   2eaac: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2eab0: ba 00 00 00 00               	movl	$0x0, %edx
   2eab5: 48 89 ce                     	movq	%rcx, %rsi
   2eab8: 48 89 c7                     	movq	%rax, %rdi
   2eabb: e8 66 7a 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   2eac0: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2eac4: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2eac9: 0f 94 c0                     	sete	%al
   2eacc: 0f b6 c0                     	movzbl	%al, %eax
   2eacf: 48 85 c0                     	testq	%rax, %rax
   2ead2: 74 27                        	je	0x2eafb <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1903>
   2ead4: 48 8b 05 0d 0a 22 00         	movq	0x220a0d(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2eadb: 48 89 05 66 30 22 00         	movq	%rax, 0x223066(%rip)    # 0x251b48 <__pyx_filename>
   2eae2: c7 05 54 30 22 00 54 01 00 00	movl	$0x154, 0x223054(%rip)  # imm = 0x154
                                                                        # 0x251b40 <__pyx_lineno>
   2eaec: c7 05 4e 30 22 00 0d 26 00 00	movl	$0x260d, 0x22304e(%rip) # imm = 0x260D
                                                                        # 0x251b44 <__pyx_clineno>
   2eaf6: e9 ba 0c 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2eafb: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2eaff: 48 8b 00                     	movq	(%rax), %rax
   2eb02: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2eb06: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2eb0a: 48 89 10                     	movq	%rdx, (%rax)
   2eb0d: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2eb11: 48 8b 00                     	movq	(%rax), %rax
   2eb14: 48 85 c0                     	testq	%rax, %rax
   2eb17: 75 15                        	jne	0x2eb2e <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1936>
   2eb19: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2eb1d: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2eb21: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2eb25: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2eb29: 48 89 d7                     	movq	%rdx, %rdi
   2eb2c: ff d0                        	callq	*%rax
   2eb2e: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2eb36: 48 8b 85 28 ff ff ff         	movq	-0xd8(%rbp), %rax
   2eb3d: 48 89 45 d0                  	movq	%rax, -0x30(%rbp)
   2eb41: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2eb45: 48 89 85 28 ff ff ff         	movq	%rax, -0xd8(%rbp)
   2eb4c: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
   2eb50: 48 8b 00                     	movq	(%rax), %rax
   2eb53: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2eb57: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
   2eb5b: 48 89 10                     	movq	%rdx, (%rax)
   2eb5e: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
   2eb62: 48 8b 00                     	movq	(%rax), %rax
   2eb65: 48 85 c0                     	testq	%rax, %rax
   2eb68: 75 15                        	jne	0x2eb7f <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1987>
   2eb6a: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
   2eb6e: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2eb72: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2eb76: 48 8b 55 d0                  	movq	-0x30(%rbp), %rdx
   2eb7a: 48 89 d7                     	movq	%rdx, %rdi
   2eb7d: ff d0                        	callq	*%rax
   2eb7f: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2eb87: 48 8b 35 ba 35 22 00         	movq	0x2235ba(%rip), %rsi    # 0x252148 <__pyx_int_1>
   2eb8e: 48 8b 85 28 ff ff ff         	movq	-0xd8(%rbp), %rax
   2eb95: b9 00 00 00 00               	movl	$0x0, %ecx
   2eb9a: ba 01 00 00 00               	movl	$0x1, %edx
   2eb9f: 48 89 c7                     	movq	%rax, %rdi
   2eba2: e8 33 97 01 00               	callq	0x482da <__Pyx_PyInt_AndObjC>
   2eba7: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2ebab: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2ebb0: 0f 94 c0                     	sete	%al
   2ebb3: 0f b6 c0                     	movzbl	%al, %eax
   2ebb6: 48 85 c0                     	testq	%rax, %rax
   2ebb9: 74 27                        	je	0x2ebe2 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x19ea>
   2ebbb: 48 8b 05 26 09 22 00         	movq	0x220926(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2ebc2: 48 89 05 7f 2f 22 00         	movq	%rax, 0x222f7f(%rip)    # 0x251b48 <__pyx_filename>
   2ebc9: c7 05 6d 2f 22 00 56 01 00 00	movl	$0x156, 0x222f6d(%rip)  # imm = 0x156
                                                                        # 0x251b40 <__pyx_lineno>
   2ebd3: c7 05 67 2f 22 00 1a 26 00 00	movl	$0x261a, 0x222f67(%rip) # imm = 0x261A
                                                                        # 0x251b44 <__pyx_clineno>
   2ebdd: e9 d3 0b 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2ebe2: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2ebe6: 48 89 85 60 ff ff ff         	movq	%rax, -0xa0(%rbp)
   2ebed: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2ebf5: 48 8b 85 60 ff ff ff         	movq	-0xa0(%rbp), %rax
   2ebfc: 48 89 c7                     	movq	%rax, %rdi
   2ebff: e8 33 ce 01 00               	callq	0x4ba37 <__Pyx_PyObject_IsTrue>
   2ec04: 89 85 24 ff ff ff            	movl	%eax, -0xdc(%rbp)
   2ec0a: 8b 85 24 ff ff ff            	movl	-0xdc(%rbp), %eax
   2ec10: c1 e8 1f                     	shrl	$0x1f, %eax
   2ec13: 0f b6 c0                     	movzbl	%al, %eax
   2ec16: 48 85 c0                     	testq	%rax, %rax
   2ec19: 74 27                        	je	0x2ec42 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1a4a>
   2ec1b: 48 8b 05 c6 08 22 00         	movq	0x2208c6(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2ec22: 48 89 05 1f 2f 22 00         	movq	%rax, 0x222f1f(%rip)    # 0x251b48 <__pyx_filename>
   2ec29: c7 05 0d 2f 22 00 57 01 00 00	movl	$0x157, 0x222f0d(%rip)  # imm = 0x157
                                                                        # 0x251b40 <__pyx_lineno>
   2ec33: c7 05 07 2f 22 00 26 26 00 00	movl	$0x2626, 0x222f07(%rip) # imm = 0x2626
                                                                        # 0x251b44 <__pyx_clineno>
   2ec3d: e9 73 0b 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2ec42: 83 bd 24 ff ff ff 00         	cmpl	$0x0, -0xdc(%rbp)
   2ec49: 75 25                        	jne	0x2ec70 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1a78>
   2ec4b: 48 8b 85 60 ff ff ff         	movq	-0xa0(%rbp), %rax
   2ec52: 48 8b 00                     	movq	(%rax), %rax
   2ec55: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   2ec59: 48 8b 85 60 ff ff ff         	movq	-0xa0(%rbp), %rax
   2ec60: 48 89 10                     	movq	%rdx, (%rax)
   2ec63: 48 8b 85 60 ff ff ff         	movq	-0xa0(%rbp), %rax
   2ec6a: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2ec6e: eb 55                        	jmp	0x2ecc5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1acd>
   2ec70: bf 20 00 00 00               	movl	$0x20, %edi
   2ec75: e8 ae c7 01 00               	callq	0x4b428 <__Pyx_PyInt_From_long>
   2ec7a: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2ec7e: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2ec83: 0f 94 c0                     	sete	%al
   2ec86: 0f b6 c0                     	movzbl	%al, %eax
   2ec89: 48 85 c0                     	testq	%rax, %rax
   2ec8c: 74 27                        	je	0x2ecb5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1abd>
   2ec8e: 48 8b 05 53 08 22 00         	movq	0x220853(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2ec95: 48 89 05 ac 2e 22 00         	movq	%rax, 0x222eac(%rip)    # 0x251b48 <__pyx_filename>
   2ec9c: c7 05 9a 2e 22 00 57 01 00 00	movl	$0x157, 0x222e9a(%rip)  # imm = 0x157
                                                                        # 0x251b40 <__pyx_lineno>
   2eca6: c7 05 94 2e 22 00 2d 26 00 00	movl	$0x262d, 0x222e94(%rip) # imm = 0x262D
                                                                        # 0x251b44 <__pyx_clineno>
   2ecb0: e9 00 0b 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2ecb5: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2ecb9: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2ecbd: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2ecc5: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2ecc9: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2ecd0: 48 89 d6                     	movq	%rdx, %rsi
   2ecd3: 48 89 c7                     	movq	%rax, %rdi
   2ecd6: e8 dd 6e fd ff               	callq	0x5bb8 <PyNumber_InPlaceAdd@plt>
   2ecdb: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2ecdf: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2ece4: 0f 94 c0                     	sete	%al
   2ece7: 0f b6 c0                     	movzbl	%al, %eax
   2ecea: 48 85 c0                     	testq	%rax, %rax
   2eced: 74 27                        	je	0x2ed16 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1b1e>
   2ecef: 48 8b 05 f2 07 22 00         	movq	0x2207f2(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2ecf6: 48 89 05 4b 2e 22 00         	movq	%rax, 0x222e4b(%rip)    # 0x251b48 <__pyx_filename>
   2ecfd: c7 05 39 2e 22 00 57 01 00 00	movl	$0x157, 0x222e39(%rip)  # imm = 0x157
                                                                        # 0x251b40 <__pyx_lineno>
   2ed07: c7 05 33 2e 22 00 32 26 00 00	movl	$0x2632, 0x222e33(%rip) # imm = 0x2632
                                                                        # 0x251b44 <__pyx_clineno>
   2ed11: e9 9f 0a 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2ed16: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2ed1a: 48 8b 00                     	movq	(%rax), %rax
   2ed1d: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2ed21: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2ed25: 48 89 10                     	movq	%rdx, (%rax)
   2ed28: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2ed2c: 48 8b 00                     	movq	(%rax), %rax
   2ed2f: 48 85 c0                     	testq	%rax, %rax
   2ed32: 75 15                        	jne	0x2ed49 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1b51>
   2ed34: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2ed38: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2ed3c: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2ed40: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2ed44: 48 89 d7                     	movq	%rdx, %rdi
   2ed47: ff d0                        	callq	*%rax
   2ed49: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2ed51: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2ed58: 48 89 45 d8                  	movq	%rax, -0x28(%rbp)
   2ed5c: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2ed60: 48 89 85 38 ff ff ff         	movq	%rax, -0xc8(%rbp)
   2ed67: 48 8b 45 d8                  	movq	-0x28(%rbp), %rax
   2ed6b: 48 8b 00                     	movq	(%rax), %rax
   2ed6e: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2ed72: 48 8b 45 d8                  	movq	-0x28(%rbp), %rax
   2ed76: 48 89 10                     	movq	%rdx, (%rax)
   2ed79: 48 8b 45 d8                  	movq	-0x28(%rbp), %rax
   2ed7d: 48 8b 00                     	movq	(%rax), %rax
   2ed80: 48 85 c0                     	testq	%rax, %rax
   2ed83: 75 15                        	jne	0x2ed9a <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1ba2>
   2ed85: 48 8b 45 d8                  	movq	-0x28(%rbp), %rax
   2ed89: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2ed8d: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2ed91: 48 8b 55 d8                  	movq	-0x28(%rbp), %rdx
   2ed95: 48 89 d7                     	movq	%rdx, %rdi
   2ed98: ff d0                        	callq	*%rax
   2ed9a: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2eda2: 48 8b 35 8f 34 22 00         	movq	0x22348f(%rip), %rsi    # 0x252238 <__pyx_int_268439584>
   2eda9: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   2edb0: b9 00 00 00 00               	movl	$0x0, %ecx
   2edb5: ba 20 10 00 10               	movl	$0x10001020, %edx       # imm = 0x10001020
   2edba: 48 89 c7                     	movq	%rax, %rdi
   2edbd: e8 18 95 01 00               	callq	0x482da <__Pyx_PyInt_AndObjC>
   2edc2: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2edc6: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2edcb: 0f 94 c0                     	sete	%al
   2edce: 0f b6 c0                     	movzbl	%al, %eax
   2edd1: 48 85 c0                     	testq	%rax, %rax
   2edd4: 74 27                        	je	0x2edfd <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1c05>
   2edd6: 48 8b 05 0b 07 22 00         	movq	0x22070b(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2eddd: 48 89 05 64 2d 22 00         	movq	%rax, 0x222d64(%rip)    # 0x251b48 <__pyx_filename>
   2ede4: c7 05 52 2d 22 00 5b 01 00 00	movl	$0x15b, 0x222d52(%rip)  # imm = 0x15B
                                                                        # 0x251b40 <__pyx_lineno>
   2edee: c7 05 4c 2d 22 00 3f 26 00 00	movl	$0x263f, 0x222d4c(%rip) # imm = 0x263F
                                                                        # 0x251b44 <__pyx_clineno>
   2edf8: e9 b8 09 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2edfd: bf 01 00 00 00               	movl	$0x1, %edi
   2ee02: e8 49 6b fd ff               	callq	0x5950 <PyTuple_New@plt>
   2ee07: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2ee0b: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2ee10: 0f 94 c0                     	sete	%al
   2ee13: 0f b6 c0                     	movzbl	%al, %eax
   2ee16: 48 85 c0                     	testq	%rax, %rax
   2ee19: 74 27                        	je	0x2ee42 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1c4a>
   2ee1b: 48 8b 05 c6 06 22 00         	movq	0x2206c6(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2ee22: 48 89 05 1f 2d 22 00         	movq	%rax, 0x222d1f(%rip)    # 0x251b48 <__pyx_filename>
   2ee29: c7 05 0d 2d 22 00 5b 01 00 00	movl	$0x15b, 0x222d0d(%rip)  # imm = 0x15B
                                                                        # 0x251b40 <__pyx_lineno>
   2ee33: c7 05 07 2d 22 00 41 26 00 00	movl	$0x2641, 0x222d07(%rip) # imm = 0x2641
                                                                        # 0x251b44 <__pyx_clineno>
   2ee3d: e9 73 09 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2ee42: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2ee46: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2ee4a: 48 89 50 18                  	movq	%rdx, 0x18(%rax)
   2ee4e: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2ee56: 48 8b 05 2b 2d 22 00         	movq	0x222d2b(%rip), %rax    # 0x251b88 <__pyx_builtin_bin>
   2ee5d: 48 8b 4d 80                  	movq	-0x80(%rbp), %rcx
   2ee61: ba 00 00 00 00               	movl	$0x0, %edx
   2ee66: 48 89 ce                     	movq	%rcx, %rsi
   2ee69: 48 89 c7                     	movq	%rax, %rdi
   2ee6c: e8 b5 76 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   2ee71: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2ee75: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2ee7a: 0f 94 c0                     	sete	%al
   2ee7d: 0f b6 c0                     	movzbl	%al, %eax
   2ee80: 48 85 c0                     	testq	%rax, %rax
   2ee83: 74 27                        	je	0x2eeac <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1cb4>
   2ee85: 48 8b 05 5c 06 22 00         	movq	0x22065c(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2ee8c: 48 89 05 b5 2c 22 00         	movq	%rax, 0x222cb5(%rip)    # 0x251b48 <__pyx_filename>
   2ee93: c7 05 a3 2c 22 00 5b 01 00 00	movl	$0x15b, 0x222ca3(%rip)  # imm = 0x15B
                                                                        # 0x251b40 <__pyx_lineno>
   2ee9d: c7 05 9d 2c 22 00 46 26 00 00	movl	$0x2646, 0x222c9d(%rip) # imm = 0x2646
                                                                        # 0x251b44 <__pyx_clineno>
   2eea7: e9 09 09 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2eeac: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2eeb0: 48 8b 00                     	movq	(%rax), %rax
   2eeb3: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2eeb7: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2eebb: 48 89 10                     	movq	%rdx, (%rax)
   2eebe: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2eec2: 48 8b 00                     	movq	(%rax), %rax
   2eec5: 48 85 c0                     	testq	%rax, %rax
   2eec8: 75 15                        	jne	0x2eedf <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1ce7>
   2eeca: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2eece: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2eed2: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2eed6: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2eeda: 48 89 d7                     	movq	%rdx, %rdi
   2eedd: ff d0                        	callq	*%rax
   2eedf: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2eee7: 48 8b 15 b2 2e 22 00         	movq	0x222eb2(%rip), %rdx    # 0x251da0 <__pyx_n_s_count>
   2eeee: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2eef2: 48 89 d6                     	movq	%rdx, %rsi
   2eef5: 48 89 c7                     	movq	%rax, %rdi
   2eef8: e8 cd 6d fd ff               	callq	0x5cca <__Pyx_PyObject_GetAttrStr>
   2eefd: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2ef01: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2ef06: 0f 94 c0                     	sete	%al
   2ef09: 0f b6 c0                     	movzbl	%al, %eax
   2ef0c: 48 85 c0                     	testq	%rax, %rax
   2ef0f: 74 27                        	je	0x2ef38 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1d40>
   2ef11: 48 8b 05 d0 05 22 00         	movq	0x2205d0(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2ef18: 48 89 05 29 2c 22 00         	movq	%rax, 0x222c29(%rip)    # 0x251b48 <__pyx_filename>
   2ef1f: c7 05 17 2c 22 00 5b 01 00 00	movl	$0x15b, 0x222c17(%rip)  # imm = 0x15B
                                                                        # 0x251b40 <__pyx_lineno>
   2ef29: c7 05 11 2c 22 00 49 26 00 00	movl	$0x2649, 0x222c11(%rip) # imm = 0x2649
                                                                        # 0x251b44 <__pyx_clineno>
   2ef33: e9 7d 08 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2ef38: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2ef3c: 48 8b 00                     	movq	(%rax), %rax
   2ef3f: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2ef43: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2ef47: 48 89 10                     	movq	%rdx, (%rax)
   2ef4a: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2ef4e: 48 8b 00                     	movq	(%rax), %rax
   2ef51: 48 85 c0                     	testq	%rax, %rax
   2ef54: 75 15                        	jne	0x2ef6b <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1d73>
   2ef56: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2ef5a: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2ef5e: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2ef62: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2ef66: 48 89 d7                     	movq	%rdx, %rdi
   2ef69: ff d0                        	callq	*%rax
   2ef6b: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2ef73: 48 8b 0d 4e 34 22 00         	movq	0x22344e(%rip), %rcx    # 0x2523c8 <__pyx_tuple__40>
   2ef7a: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2ef7e: ba 00 00 00 00               	movl	$0x0, %edx
   2ef83: 48 89 ce                     	movq	%rcx, %rsi
   2ef86: 48 89 c7                     	movq	%rax, %rdi
   2ef89: e8 98 75 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   2ef8e: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2ef92: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2ef97: 0f 94 c0                     	sete	%al
   2ef9a: 0f b6 c0                     	movzbl	%al, %eax
   2ef9d: 48 85 c0                     	testq	%rax, %rax
   2efa0: 74 27                        	je	0x2efc9 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1dd1>
   2efa2: 48 8b 05 3f 05 22 00         	movq	0x22053f(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2efa9: 48 89 05 98 2b 22 00         	movq	%rax, 0x222b98(%rip)    # 0x251b48 <__pyx_filename>
   2efb0: c7 05 86 2b 22 00 5b 01 00 00	movl	$0x15b, 0x222b86(%rip)  # imm = 0x15B
                                                                        # 0x251b40 <__pyx_lineno>
   2efba: c7 05 80 2b 22 00 4c 26 00 00	movl	$0x264c, 0x222b80(%rip) # imm = 0x264C
                                                                        # 0x251b44 <__pyx_clineno>
   2efc4: e9 ec 07 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2efc9: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2efcd: 48 8b 00                     	movq	(%rax), %rax
   2efd0: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2efd4: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2efd8: 48 89 10                     	movq	%rdx, (%rax)
   2efdb: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2efdf: 48 8b 00                     	movq	(%rax), %rax
   2efe2: 48 85 c0                     	testq	%rax, %rax
   2efe5: 75 15                        	jne	0x2effc <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1e04>
   2efe7: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2efeb: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2efef: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2eff3: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2eff7: 48 89 d7                     	movq	%rdx, %rdi
   2effa: ff d0                        	callq	*%rax
   2effc: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2f004: 48 8b 85 28 ff ff ff         	movq	-0xd8(%rbp), %rax
   2f00b: 48 89 45 e0                  	movq	%rax, -0x20(%rbp)
   2f00f: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f013: 48 89 85 28 ff ff ff         	movq	%rax, -0xd8(%rbp)
   2f01a: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   2f01e: 48 8b 00                     	movq	(%rax), %rax
   2f021: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2f025: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   2f029: 48 89 10                     	movq	%rdx, (%rax)
   2f02c: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   2f030: 48 8b 00                     	movq	(%rax), %rax
   2f033: 48 85 c0                     	testq	%rax, %rax
   2f036: 75 15                        	jne	0x2f04d <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1e55>
   2f038: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   2f03c: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2f040: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2f044: 48 8b 55 e0                  	movq	-0x20(%rbp), %rdx
   2f048: 48 89 d7                     	movq	%rdx, %rdi
   2f04b: ff d0                        	callq	*%rax
   2f04d: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2f055: 48 8b 35 ec 30 22 00         	movq	0x2230ec(%rip), %rsi    # 0x252148 <__pyx_int_1>
   2f05c: 48 8b 85 28 ff ff ff         	movq	-0xd8(%rbp), %rax
   2f063: b9 00 00 00 00               	movl	$0x0, %ecx
   2f068: ba 01 00 00 00               	movl	$0x1, %edx
   2f06d: 48 89 c7                     	movq	%rax, %rdi
   2f070: e8 65 92 01 00               	callq	0x482da <__Pyx_PyInt_AndObjC>
   2f075: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2f079: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2f07e: 0f 94 c0                     	sete	%al
   2f081: 0f b6 c0                     	movzbl	%al, %eax
   2f084: 48 85 c0                     	testq	%rax, %rax
   2f087: 74 27                        	je	0x2f0b0 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1eb8>
   2f089: 48 8b 05 58 04 22 00         	movq	0x220458(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2f090: 48 89 05 b1 2a 22 00         	movq	%rax, 0x222ab1(%rip)    # 0x251b48 <__pyx_filename>
   2f097: c7 05 9f 2a 22 00 5d 01 00 00	movl	$0x15d, 0x222a9f(%rip)  # imm = 0x15D
                                                                        # 0x251b40 <__pyx_lineno>
   2f0a1: c7 05 99 2a 22 00 59 26 00 00	movl	$0x2659, 0x222a99(%rip) # imm = 0x2659
                                                                        # 0x251b44 <__pyx_clineno>
   2f0ab: e9 05 07 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2f0b0: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f0b4: 48 89 85 68 ff ff ff         	movq	%rax, -0x98(%rbp)
   2f0bb: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2f0c3: 48 8b 85 68 ff ff ff         	movq	-0x98(%rbp), %rax
   2f0ca: 48 89 c7                     	movq	%rax, %rdi
   2f0cd: e8 65 c9 01 00               	callq	0x4ba37 <__Pyx_PyObject_IsTrue>
   2f0d2: 89 85 24 ff ff ff            	movl	%eax, -0xdc(%rbp)
   2f0d8: 8b 85 24 ff ff ff            	movl	-0xdc(%rbp), %eax
   2f0de: c1 e8 1f                     	shrl	$0x1f, %eax
   2f0e1: 0f b6 c0                     	movzbl	%al, %eax
   2f0e4: 48 85 c0                     	testq	%rax, %rax
   2f0e7: 74 27                        	je	0x2f110 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1f18>
   2f0e9: 48 8b 05 f8 03 22 00         	movq	0x2203f8(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2f0f0: 48 89 05 51 2a 22 00         	movq	%rax, 0x222a51(%rip)    # 0x251b48 <__pyx_filename>
   2f0f7: c7 05 3f 2a 22 00 5e 01 00 00	movl	$0x15e, 0x222a3f(%rip)  # imm = 0x15E
                                                                        # 0x251b40 <__pyx_lineno>
   2f101: c7 05 39 2a 22 00 65 26 00 00	movl	$0x2665, 0x222a39(%rip) # imm = 0x2665
                                                                        # 0x251b44 <__pyx_clineno>
   2f10b: e9 a5 06 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2f110: 83 bd 24 ff ff ff 00         	cmpl	$0x0, -0xdc(%rbp)
   2f117: 75 25                        	jne	0x2f13e <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1f46>
   2f119: 48 8b 85 68 ff ff ff         	movq	-0x98(%rbp), %rax
   2f120: 48 8b 00                     	movq	(%rax), %rax
   2f123: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   2f127: 48 8b 85 68 ff ff ff         	movq	-0x98(%rbp), %rax
   2f12e: 48 89 10                     	movq	%rdx, (%rax)
   2f131: 48 8b 85 68 ff ff ff         	movq	-0x98(%rbp), %rax
   2f138: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2f13c: eb 55                        	jmp	0x2f193 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1f9b>
   2f13e: bf 40 00 00 00               	movl	$0x40, %edi
   2f143: e8 e0 c2 01 00               	callq	0x4b428 <__Pyx_PyInt_From_long>
   2f148: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2f14c: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2f151: 0f 94 c0                     	sete	%al
   2f154: 0f b6 c0                     	movzbl	%al, %eax
   2f157: 48 85 c0                     	testq	%rax, %rax
   2f15a: 74 27                        	je	0x2f183 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1f8b>
   2f15c: 48 8b 05 85 03 22 00         	movq	0x220385(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2f163: 48 89 05 de 29 22 00         	movq	%rax, 0x2229de(%rip)    # 0x251b48 <__pyx_filename>
   2f16a: c7 05 cc 29 22 00 5e 01 00 00	movl	$0x15e, 0x2229cc(%rip)  # imm = 0x15E
                                                                        # 0x251b40 <__pyx_lineno>
   2f174: c7 05 c6 29 22 00 6c 26 00 00	movl	$0x266c, 0x2229c6(%rip) # imm = 0x266C
                                                                        # 0x251b44 <__pyx_clineno>
   2f17e: e9 32 06 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2f183: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2f187: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2f18b: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2f193: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2f197: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2f19e: 48 89 d6                     	movq	%rdx, %rsi
   2f1a1: 48 89 c7                     	movq	%rax, %rdi
   2f1a4: e8 0f 6a fd ff               	callq	0x5bb8 <PyNumber_InPlaceAdd@plt>
   2f1a9: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2f1ad: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2f1b2: 0f 94 c0                     	sete	%al
   2f1b5: 0f b6 c0                     	movzbl	%al, %eax
   2f1b8: 48 85 c0                     	testq	%rax, %rax
   2f1bb: 74 27                        	je	0x2f1e4 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x1fec>
   2f1bd: 48 8b 05 24 03 22 00         	movq	0x220324(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2f1c4: 48 89 05 7d 29 22 00         	movq	%rax, 0x22297d(%rip)    # 0x251b48 <__pyx_filename>
   2f1cb: c7 05 6b 29 22 00 5e 01 00 00	movl	$0x15e, 0x22296b(%rip)  # imm = 0x15E
                                                                        # 0x251b40 <__pyx_lineno>
   2f1d5: c7 05 65 29 22 00 71 26 00 00	movl	$0x2671, 0x222965(%rip) # imm = 0x2671
                                                                        # 0x251b44 <__pyx_clineno>
   2f1df: e9 d1 05 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2f1e4: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f1e8: 48 8b 00                     	movq	(%rax), %rax
   2f1eb: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2f1ef: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f1f3: 48 89 10                     	movq	%rdx, (%rax)
   2f1f6: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f1fa: 48 8b 00                     	movq	(%rax), %rax
   2f1fd: 48 85 c0                     	testq	%rax, %rax
   2f200: 75 15                        	jne	0x2f217 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x201f>
   2f202: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f206: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2f20a: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2f20e: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2f212: 48 89 d7                     	movq	%rdx, %rdi
   2f215: ff d0                        	callq	*%rax
   2f217: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2f21f: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2f226: 48 89 45 e8                  	movq	%rax, -0x18(%rbp)
   2f22a: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2f22e: 48 89 85 38 ff ff ff         	movq	%rax, -0xc8(%rbp)
   2f235: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   2f239: 48 8b 00                     	movq	(%rax), %rax
   2f23c: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2f240: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   2f244: 48 89 10                     	movq	%rdx, (%rax)
   2f247: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   2f24b: 48 8b 00                     	movq	(%rax), %rax
   2f24e: 48 85 c0                     	testq	%rax, %rax
   2f251: 75 15                        	jne	0x2f268 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2070>
   2f253: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   2f257: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2f25b: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2f25f: 48 8b 55 e8                  	movq	-0x18(%rbp), %rdx
   2f263: 48 89 d7                     	movq	%rdx, %rdi
   2f266: ff d0                        	callq	*%rax
   2f268: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2f270: 48 8b 35 d9 2f 22 00         	movq	0x222fd9(%rip), %rsi    # 0x252250 <__pyx_int_536879564>
   2f277: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   2f27e: b9 00 00 00 00               	movl	$0x0, %ecx
   2f283: ba cc 21 00 20               	movl	$0x200021cc, %edx       # imm = 0x200021CC
   2f288: 48 89 c7                     	movq	%rax, %rdi
   2f28b: e8 4a 90 01 00               	callq	0x482da <__Pyx_PyInt_AndObjC>
   2f290: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2f294: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2f299: 0f 94 c0                     	sete	%al
   2f29c: 0f b6 c0                     	movzbl	%al, %eax
   2f29f: 48 85 c0                     	testq	%rax, %rax
   2f2a2: 74 27                        	je	0x2f2cb <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x20d3>
   2f2a4: 48 8b 05 3d 02 22 00         	movq	0x22023d(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2f2ab: 48 89 05 96 28 22 00         	movq	%rax, 0x222896(%rip)    # 0x251b48 <__pyx_filename>
   2f2b2: c7 05 84 28 22 00 62 01 00 00	movl	$0x162, 0x222884(%rip)  # imm = 0x162
                                                                        # 0x251b40 <__pyx_lineno>
   2f2bc: c7 05 7e 28 22 00 7e 26 00 00	movl	$0x267e, 0x22287e(%rip) # imm = 0x267E
                                                                        # 0x251b44 <__pyx_clineno>
   2f2c6: e9 ea 04 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2f2cb: bf 01 00 00 00               	movl	$0x1, %edi
   2f2d0: e8 7b 66 fd ff               	callq	0x5950 <PyTuple_New@plt>
   2f2d5: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2f2d9: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2f2de: 0f 94 c0                     	sete	%al
   2f2e1: 0f b6 c0                     	movzbl	%al, %eax
   2f2e4: 48 85 c0                     	testq	%rax, %rax
   2f2e7: 74 27                        	je	0x2f310 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2118>
   2f2e9: 48 8b 05 f8 01 22 00         	movq	0x2201f8(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2f2f0: 48 89 05 51 28 22 00         	movq	%rax, 0x222851(%rip)    # 0x251b48 <__pyx_filename>
   2f2f7: c7 05 3f 28 22 00 62 01 00 00	movl	$0x162, 0x22283f(%rip)  # imm = 0x162
                                                                        # 0x251b40 <__pyx_lineno>
   2f301: c7 05 39 28 22 00 80 26 00 00	movl	$0x2680, 0x222839(%rip) # imm = 0x2680
                                                                        # 0x251b44 <__pyx_clineno>
   2f30b: e9 a5 04 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2f310: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f314: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2f318: 48 89 50 18                  	movq	%rdx, 0x18(%rax)
   2f31c: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2f324: 48 8b 05 5d 28 22 00         	movq	0x22285d(%rip), %rax    # 0x251b88 <__pyx_builtin_bin>
   2f32b: 48 8b 4d 88                  	movq	-0x78(%rbp), %rcx
   2f32f: ba 00 00 00 00               	movl	$0x0, %edx
   2f334: 48 89 ce                     	movq	%rcx, %rsi
   2f337: 48 89 c7                     	movq	%rax, %rdi
   2f33a: e8 e7 71 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   2f33f: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2f343: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2f348: 0f 94 c0                     	sete	%al
   2f34b: 0f b6 c0                     	movzbl	%al, %eax
   2f34e: 48 85 c0                     	testq	%rax, %rax
   2f351: 74 27                        	je	0x2f37a <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2182>
   2f353: 48 8b 05 8e 01 22 00         	movq	0x22018e(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2f35a: 48 89 05 e7 27 22 00         	movq	%rax, 0x2227e7(%rip)    # 0x251b48 <__pyx_filename>
   2f361: c7 05 d5 27 22 00 62 01 00 00	movl	$0x162, 0x2227d5(%rip)  # imm = 0x162
                                                                        # 0x251b40 <__pyx_lineno>
   2f36b: c7 05 cf 27 22 00 85 26 00 00	movl	$0x2685, 0x2227cf(%rip) # imm = 0x2685
                                                                        # 0x251b44 <__pyx_clineno>
   2f375: e9 3b 04 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2f37a: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f37e: 48 8b 00                     	movq	(%rax), %rax
   2f381: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2f385: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f389: 48 89 10                     	movq	%rdx, (%rax)
   2f38c: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f390: 48 8b 00                     	movq	(%rax), %rax
   2f393: 48 85 c0                     	testq	%rax, %rax
   2f396: 75 15                        	jne	0x2f3ad <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x21b5>
   2f398: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f39c: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2f3a0: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2f3a4: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2f3a8: 48 89 d7                     	movq	%rdx, %rdi
   2f3ab: ff d0                        	callq	*%rax
   2f3ad: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2f3b5: 48 8b 15 e4 29 22 00         	movq	0x2229e4(%rip), %rdx    # 0x251da0 <__pyx_n_s_count>
   2f3bc: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2f3c0: 48 89 d6                     	movq	%rdx, %rsi
   2f3c3: 48 89 c7                     	movq	%rax, %rdi
   2f3c6: e8 ff 68 fd ff               	callq	0x5cca <__Pyx_PyObject_GetAttrStr>
   2f3cb: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2f3cf: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2f3d4: 0f 94 c0                     	sete	%al
   2f3d7: 0f b6 c0                     	movzbl	%al, %eax
   2f3da: 48 85 c0                     	testq	%rax, %rax
   2f3dd: 74 27                        	je	0x2f406 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x220e>
   2f3df: 48 8b 05 02 01 22 00         	movq	0x220102(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2f3e6: 48 89 05 5b 27 22 00         	movq	%rax, 0x22275b(%rip)    # 0x251b48 <__pyx_filename>
   2f3ed: c7 05 49 27 22 00 62 01 00 00	movl	$0x162, 0x222749(%rip)  # imm = 0x162
                                                                        # 0x251b40 <__pyx_lineno>
   2f3f7: c7 05 43 27 22 00 88 26 00 00	movl	$0x2688, 0x222743(%rip) # imm = 0x2688
                                                                        # 0x251b44 <__pyx_clineno>
   2f401: e9 af 03 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2f406: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2f40a: 48 8b 00                     	movq	(%rax), %rax
   2f40d: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2f411: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2f415: 48 89 10                     	movq	%rdx, (%rax)
   2f418: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2f41c: 48 8b 00                     	movq	(%rax), %rax
   2f41f: 48 85 c0                     	testq	%rax, %rax
   2f422: 75 15                        	jne	0x2f439 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2241>
   2f424: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2f428: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2f42c: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2f430: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2f434: 48 89 d7                     	movq	%rdx, %rdi
   2f437: ff d0                        	callq	*%rax
   2f439: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2f441: 48 8b 0d 88 2f 22 00         	movq	0x222f88(%rip), %rcx    # 0x2523d0 <__pyx_tuple__41>
   2f448: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f44c: ba 00 00 00 00               	movl	$0x0, %edx
   2f451: 48 89 ce                     	movq	%rcx, %rsi
   2f454: 48 89 c7                     	movq	%rax, %rdi
   2f457: e8 ca 70 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   2f45c: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2f460: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2f465: 0f 94 c0                     	sete	%al
   2f468: 0f b6 c0                     	movzbl	%al, %eax
   2f46b: 48 85 c0                     	testq	%rax, %rax
   2f46e: 74 27                        	je	0x2f497 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x229f>
   2f470: 48 8b 05 71 00 22 00         	movq	0x220071(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2f477: 48 89 05 ca 26 22 00         	movq	%rax, 0x2226ca(%rip)    # 0x251b48 <__pyx_filename>
   2f47e: c7 05 b8 26 22 00 62 01 00 00	movl	$0x162, 0x2226b8(%rip)  # imm = 0x162
                                                                        # 0x251b40 <__pyx_lineno>
   2f488: c7 05 b2 26 22 00 8b 26 00 00	movl	$0x268b, 0x2226b2(%rip) # imm = 0x268B
                                                                        # 0x251b44 <__pyx_clineno>
   2f492: e9 1e 03 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2f497: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f49b: 48 8b 00                     	movq	(%rax), %rax
   2f49e: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2f4a2: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f4a6: 48 89 10                     	movq	%rdx, (%rax)
   2f4a9: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f4ad: 48 8b 00                     	movq	(%rax), %rax
   2f4b0: 48 85 c0                     	testq	%rax, %rax
   2f4b3: 75 15                        	jne	0x2f4ca <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x22d2>
   2f4b5: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f4b9: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2f4bd: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2f4c1: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2f4c5: 48 89 d7                     	movq	%rdx, %rdi
   2f4c8: ff d0                        	callq	*%rax
   2f4ca: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2f4d2: 48 8b 85 28 ff ff ff         	movq	-0xd8(%rbp), %rax
   2f4d9: 48 89 45 f0                  	movq	%rax, -0x10(%rbp)
   2f4dd: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2f4e1: 48 89 85 28 ff ff ff         	movq	%rax, -0xd8(%rbp)
   2f4e8: 48 8b 45 f0                  	movq	-0x10(%rbp), %rax
   2f4ec: 48 8b 00                     	movq	(%rax), %rax
   2f4ef: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2f4f3: 48 8b 45 f0                  	movq	-0x10(%rbp), %rax
   2f4f7: 48 89 10                     	movq	%rdx, (%rax)
   2f4fa: 48 8b 45 f0                  	movq	-0x10(%rbp), %rax
   2f4fe: 48 8b 00                     	movq	(%rax), %rax
   2f501: 48 85 c0                     	testq	%rax, %rax
   2f504: 75 15                        	jne	0x2f51b <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2323>
   2f506: 48 8b 45 f0                  	movq	-0x10(%rbp), %rax
   2f50a: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2f50e: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2f512: 48 8b 55 f0                  	movq	-0x10(%rbp), %rdx
   2f516: 48 89 d7                     	movq	%rdx, %rdi
   2f519: ff d0                        	callq	*%rax
   2f51b: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2f523: 48 8b 35 1e 2c 22 00         	movq	0x222c1e(%rip), %rsi    # 0x252148 <__pyx_int_1>
   2f52a: 48 8b 85 28 ff ff ff         	movq	-0xd8(%rbp), %rax
   2f531: b9 00 00 00 00               	movl	$0x0, %ecx
   2f536: ba 01 00 00 00               	movl	$0x1, %edx
   2f53b: 48 89 c7                     	movq	%rax, %rdi
   2f53e: e8 97 8d 01 00               	callq	0x482da <__Pyx_PyInt_AndObjC>
   2f543: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2f547: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2f54c: 0f 94 c0                     	sete	%al
   2f54f: 0f b6 c0                     	movzbl	%al, %eax
   2f552: 48 85 c0                     	testq	%rax, %rax
   2f555: 74 27                        	je	0x2f57e <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2386>
   2f557: 48 8b 05 8a ff 21 00         	movq	0x21ff8a(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2f55e: 48 89 05 e3 25 22 00         	movq	%rax, 0x2225e3(%rip)    # 0x251b48 <__pyx_filename>
   2f565: c7 05 d1 25 22 00 64 01 00 00	movl	$0x164, 0x2225d1(%rip)  # imm = 0x164
                                                                        # 0x251b40 <__pyx_lineno>
   2f56f: c7 05 cb 25 22 00 98 26 00 00	movl	$0x2698, 0x2225cb(%rip) # imm = 0x2698
                                                                        # 0x251b44 <__pyx_clineno>
   2f579: e9 37 02 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2f57e: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2f582: 48 89 85 70 ff ff ff         	movq	%rax, -0x90(%rbp)
   2f589: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2f591: 48 8b 85 70 ff ff ff         	movq	-0x90(%rbp), %rax
   2f598: 48 89 c7                     	movq	%rax, %rdi
   2f59b: e8 97 c4 01 00               	callq	0x4ba37 <__Pyx_PyObject_IsTrue>
   2f5a0: 89 85 24 ff ff ff            	movl	%eax, -0xdc(%rbp)
   2f5a6: 8b 85 24 ff ff ff            	movl	-0xdc(%rbp), %eax
   2f5ac: c1 e8 1f                     	shrl	$0x1f, %eax
   2f5af: 0f b6 c0                     	movzbl	%al, %eax
   2f5b2: 48 85 c0                     	testq	%rax, %rax
   2f5b5: 74 27                        	je	0x2f5de <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x23e6>
   2f5b7: 48 8b 05 2a ff 21 00         	movq	0x21ff2a(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2f5be: 48 89 05 83 25 22 00         	movq	%rax, 0x222583(%rip)    # 0x251b48 <__pyx_filename>
   2f5c5: c7 05 71 25 22 00 65 01 00 00	movl	$0x165, 0x222571(%rip)  # imm = 0x165
                                                                        # 0x251b40 <__pyx_lineno>
   2f5cf: c7 05 6b 25 22 00 a4 26 00 00	movl	$0x26a4, 0x22256b(%rip) # imm = 0x26A4
                                                                        # 0x251b44 <__pyx_clineno>
   2f5d9: e9 d7 01 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2f5de: 83 bd 24 ff ff ff 00         	cmpl	$0x0, -0xdc(%rbp)
   2f5e5: 75 25                        	jne	0x2f60c <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2414>
   2f5e7: 48 8b 85 70 ff ff ff         	movq	-0x90(%rbp), %rax
   2f5ee: 48 8b 00                     	movq	(%rax), %rax
   2f5f1: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   2f5f5: 48 8b 85 70 ff ff ff         	movq	-0x90(%rbp), %rax
   2f5fc: 48 89 10                     	movq	%rdx, (%rax)
   2f5ff: 48 8b 85 70 ff ff ff         	movq	-0x90(%rbp), %rax
   2f606: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2f60a: eb 55                        	jmp	0x2f661 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2469>
   2f60c: bf 80 00 00 00               	movl	$0x80, %edi
   2f611: e8 12 be 01 00               	callq	0x4b428 <__Pyx_PyInt_From_long>
   2f616: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2f61a: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2f61f: 0f 94 c0                     	sete	%al
   2f622: 0f b6 c0                     	movzbl	%al, %eax
   2f625: 48 85 c0                     	testq	%rax, %rax
   2f628: 74 27                        	je	0x2f651 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2459>
   2f62a: 48 8b 05 b7 fe 21 00         	movq	0x21feb7(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2f631: 48 89 05 10 25 22 00         	movq	%rax, 0x222510(%rip)    # 0x251b48 <__pyx_filename>
   2f638: c7 05 fe 24 22 00 65 01 00 00	movl	$0x165, 0x2224fe(%rip)  # imm = 0x165
                                                                        # 0x251b40 <__pyx_lineno>
   2f642: c7 05 f8 24 22 00 ab 26 00 00	movl	$0x26ab, 0x2224f8(%rip) # imm = 0x26AB
                                                                        # 0x251b44 <__pyx_clineno>
   2f64c: e9 64 01 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2f651: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f655: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   2f659: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2f661: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2f665: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2f66c: 48 89 d6                     	movq	%rdx, %rsi
   2f66f: 48 89 c7                     	movq	%rax, %rdi
   2f672: e8 41 65 fd ff               	callq	0x5bb8 <PyNumber_InPlaceAdd@plt>
   2f677: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   2f67b: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2f680: 0f 94 c0                     	sete	%al
   2f683: 0f b6 c0                     	movzbl	%al, %eax
   2f686: 48 85 c0                     	testq	%rax, %rax
   2f689: 74 27                        	je	0x2f6b2 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x24ba>
   2f68b: 48 8b 05 56 fe 21 00         	movq	0x21fe56(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2f692: 48 89 05 af 24 22 00         	movq	%rax, 0x2224af(%rip)    # 0x251b48 <__pyx_filename>
   2f699: c7 05 9d 24 22 00 65 01 00 00	movl	$0x165, 0x22249d(%rip)  # imm = 0x165
                                                                        # 0x251b40 <__pyx_lineno>
   2f6a3: c7 05 97 24 22 00 b0 26 00 00	movl	$0x26b0, 0x222497(%rip) # imm = 0x26B0
                                                                        # 0x251b44 <__pyx_clineno>
   2f6ad: e9 03 01 00 00               	jmp	0x2f7b5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25bd>
   2f6b2: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2f6b6: 48 8b 00                     	movq	(%rax), %rax
   2f6b9: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2f6bd: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2f6c1: 48 89 10                     	movq	%rdx, (%rax)
   2f6c4: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2f6c8: 48 8b 00                     	movq	(%rax), %rax
   2f6cb: 48 85 c0                     	testq	%rax, %rax
   2f6ce: 75 15                        	jne	0x2f6e5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x24ed>
   2f6d0: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2f6d4: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2f6d8: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2f6dc: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2f6e0: 48 89 d7                     	movq	%rdx, %rdi
   2f6e3: ff d0                        	callq	*%rax
   2f6e5: 48 c7 45 80 00 00 00 00      	movq	$0x0, -0x80(%rbp)
   2f6ed: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2f6f4: 48 89 45 f8                  	movq	%rax, -0x8(%rbp)
   2f6f8: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f6fc: 48 89 85 38 ff ff ff         	movq	%rax, -0xc8(%rbp)
   2f703: 48 8b 45 f8                  	movq	-0x8(%rbp), %rax
   2f707: 48 8b 00                     	movq	(%rax), %rax
   2f70a: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2f70e: 48 8b 45 f8                  	movq	-0x8(%rbp), %rax
   2f712: 48 89 10                     	movq	%rdx, (%rax)
   2f715: 48 8b 45 f8                  	movq	-0x8(%rbp), %rax
   2f719: 48 8b 00                     	movq	(%rax), %rax
   2f71c: 48 85 c0                     	testq	%rax, %rax
   2f71f: 75 15                        	jne	0x2f736 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x253e>
   2f721: 48 8b 45 f8                  	movq	-0x8(%rbp), %rax
   2f725: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2f729: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2f72d: 48 8b 55 f8                  	movq	-0x8(%rbp), %rdx
   2f731: 48 89 d7                     	movq	%rdx, %rdi
   2f734: ff d0                        	callq	*%rax
   2f736: 48 c7 45 88 00 00 00 00      	movq	$0x0, -0x78(%rbp)
   2f73e: 48 83 bd 78 ff ff ff 00      	cmpq	$0x0, -0x88(%rbp)
   2f746: 74 42                        	je	0x2f78a <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2592>
   2f748: 48 8b 85 78 ff ff ff         	movq	-0x88(%rbp), %rax
   2f74f: 48 8b 00                     	movq	(%rax), %rax
   2f752: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2f756: 48 8b 85 78 ff ff ff         	movq	-0x88(%rbp), %rax
   2f75d: 48 89 10                     	movq	%rdx, (%rax)
   2f760: 48 8b 85 78 ff ff ff         	movq	-0x88(%rbp), %rax
   2f767: 48 8b 00                     	movq	(%rax), %rax
   2f76a: 48 85 c0                     	testq	%rax, %rax
   2f76d: 75 1b                        	jne	0x2f78a <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2592>
   2f76f: 48 8b 85 78 ff ff ff         	movq	-0x88(%rbp), %rax
   2f776: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2f77a: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2f77e: 48 8b 95 78 ff ff ff         	movq	-0x88(%rbp), %rdx
   2f785: 48 89 d7                     	movq	%rdx, %rdi
   2f788: ff d0                        	callq	*%rax
   2f78a: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2f791: 48 8b 00                     	movq	(%rax), %rax
   2f794: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   2f798: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2f79f: 48 89 10                     	movq	%rdx, (%rax)
   2f7a2: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2f7a9: 48 89 85 78 ff ff ff         	movq	%rax, -0x88(%rbp)
   2f7b0: e9 a0 00 00 00               	jmp	0x2f855 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x265d>
   2f7b5: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   2f7ba: 74 33                        	je	0x2f7ef <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25f7>
   2f7bc: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2f7c0: 48 8b 00                     	movq	(%rax), %rax
   2f7c3: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2f7c7: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2f7cb: 48 89 10                     	movq	%rdx, (%rax)
   2f7ce: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2f7d2: 48 8b 00                     	movq	(%rax), %rax
   2f7d5: 48 85 c0                     	testq	%rax, %rax
   2f7d8: 75 15                        	jne	0x2f7ef <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x25f7>
   2f7da: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   2f7de: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2f7e2: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2f7e6: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   2f7ea: 48 89 d7                     	movq	%rdx, %rdi
   2f7ed: ff d0                        	callq	*%rax
   2f7ef: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   2f7f4: 74 33                        	je	0x2f829 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2631>
   2f7f6: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f7fa: 48 8b 00                     	movq	(%rax), %rax
   2f7fd: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2f801: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f805: 48 89 10                     	movq	%rdx, (%rax)
   2f808: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f80c: 48 8b 00                     	movq	(%rax), %rax
   2f80f: 48 85 c0                     	testq	%rax, %rax
   2f812: 75 15                        	jne	0x2f829 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2631>
   2f814: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   2f818: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2f81c: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2f820: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   2f824: 48 89 d7                     	movq	%rdx, %rdi
   2f827: ff d0                        	callq	*%rax
   2f829: 48 8b 0d 18 23 22 00         	movq	0x222318(%rip), %rcx    # 0x251b48 <__pyx_filename>
   2f830: 8b 15 0a 23 22 00            	movl	0x22230a(%rip), %edx    # 0x251b40 <__pyx_lineno>
   2f836: 8b 05 08 23 22 00            	movl	0x222308(%rip), %eax    # 0x251b44 <__pyx_clineno>
   2f83c: 89 c6                        	movl	%eax, %esi
   2f83e: 48 8d 3d 47 cd 01 00         	leaq	0x1cd47(%rip), %rdi     # 0x4c58c <__pyx_k_BaseEfuse___dict_string_parse+0x1ac>
   2f845: e8 84 ba 01 00               	callq	0x4b2ce <__Pyx_AddTraceback>
   2f84a: 48 c7 85 78 ff ff ff 00 00 00 00     	movq	$0x0, -0x88(%rbp)
   2f855: 48 83 bd 28 ff ff ff 00      	cmpq	$0x0, -0xd8(%rbp)
   2f85d: 74 42                        	je	0x2f8a1 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x26a9>
   2f85f: 48 8b 85 28 ff ff ff         	movq	-0xd8(%rbp), %rax
   2f866: 48 8b 00                     	movq	(%rax), %rax
   2f869: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2f86d: 48 8b 85 28 ff ff ff         	movq	-0xd8(%rbp), %rax
   2f874: 48 89 10                     	movq	%rdx, (%rax)
   2f877: 48 8b 85 28 ff ff ff         	movq	-0xd8(%rbp), %rax
   2f87e: 48 8b 00                     	movq	(%rax), %rax
   2f881: 48 85 c0                     	testq	%rax, %rax
   2f884: 75 1b                        	jne	0x2f8a1 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x26a9>
   2f886: 48 8b 85 28 ff ff ff         	movq	-0xd8(%rbp), %rax
   2f88d: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2f891: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2f895: 48 8b 95 28 ff ff ff         	movq	-0xd8(%rbp), %rdx
   2f89c: 48 89 d7                     	movq	%rdx, %rdi
   2f89f: ff d0                        	callq	*%rax
   2f8a1: 48 83 bd 30 ff ff ff 00      	cmpq	$0x0, -0xd0(%rbp)
   2f8a9: 74 42                        	je	0x2f8ed <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x26f5>
   2f8ab: 48 8b 85 30 ff ff ff         	movq	-0xd0(%rbp), %rax
   2f8b2: 48 8b 00                     	movq	(%rax), %rax
   2f8b5: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2f8b9: 48 8b 85 30 ff ff ff         	movq	-0xd0(%rbp), %rax
   2f8c0: 48 89 10                     	movq	%rdx, (%rax)
   2f8c3: 48 8b 85 30 ff ff ff         	movq	-0xd0(%rbp), %rax
   2f8ca: 48 8b 00                     	movq	(%rax), %rax
   2f8cd: 48 85 c0                     	testq	%rax, %rax
   2f8d0: 75 1b                        	jne	0x2f8ed <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x26f5>
   2f8d2: 48 8b 85 30 ff ff ff         	movq	-0xd0(%rbp), %rax
   2f8d9: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2f8dd: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2f8e1: 48 8b 95 30 ff ff ff         	movq	-0xd0(%rbp), %rdx
   2f8e8: 48 89 d7                     	movq	%rdx, %rdi
   2f8eb: ff d0                        	callq	*%rax
   2f8ed: 48 83 bd 38 ff ff ff 00      	cmpq	$0x0, -0xc8(%rbp)
   2f8f5: 74 42                        	je	0x2f939 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2741>
   2f8f7: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2f8fe: 48 8b 00                     	movq	(%rax), %rax
   2f901: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2f905: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2f90c: 48 89 10                     	movq	%rdx, (%rax)
   2f90f: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2f916: 48 8b 00                     	movq	(%rax), %rax
   2f919: 48 85 c0                     	testq	%rax, %rax
   2f91c: 75 1b                        	jne	0x2f939 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2741>
   2f91e: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   2f925: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2f929: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2f92d: 48 8b 95 38 ff ff ff         	movq	-0xc8(%rbp), %rdx
   2f934: 48 89 d7                     	movq	%rdx, %rdi
   2f937: ff d0                        	callq	*%rax
   2f939: 48 83 bd 40 ff ff ff 00      	cmpq	$0x0, -0xc0(%rbp)
   2f941: 74 42                        	je	0x2f985 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x278d>
   2f943: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   2f94a: 48 8b 00                     	movq	(%rax), %rax
   2f94d: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2f951: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   2f958: 48 89 10                     	movq	%rdx, (%rax)
   2f95b: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   2f962: 48 8b 00                     	movq	(%rax), %rax
   2f965: 48 85 c0                     	testq	%rax, %rax
   2f968: 75 1b                        	jne	0x2f985 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x278d>
   2f96a: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   2f971: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2f975: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2f979: 48 8b 95 40 ff ff ff         	movq	-0xc0(%rbp), %rdx
   2f980: 48 89 d7                     	movq	%rdx, %rdi
   2f983: ff d0                        	callq	*%rax
   2f985: 48 83 bd 48 ff ff ff 00      	cmpq	$0x0, -0xb8(%rbp)
   2f98d: 74 42                        	je	0x2f9d1 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x27d9>
   2f98f: 48 8b 85 48 ff ff ff         	movq	-0xb8(%rbp), %rax
   2f996: 48 8b 00                     	movq	(%rax), %rax
   2f999: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2f99d: 48 8b 85 48 ff ff ff         	movq	-0xb8(%rbp), %rax
   2f9a4: 48 89 10                     	movq	%rdx, (%rax)
   2f9a7: 48 8b 85 48 ff ff ff         	movq	-0xb8(%rbp), %rax
   2f9ae: 48 8b 00                     	movq	(%rax), %rax
   2f9b1: 48 85 c0                     	testq	%rax, %rax
   2f9b4: 75 1b                        	jne	0x2f9d1 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x27d9>
   2f9b6: 48 8b 85 48 ff ff ff         	movq	-0xb8(%rbp), %rax
   2f9bd: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2f9c1: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2f9c5: 48 8b 95 48 ff ff ff         	movq	-0xb8(%rbp), %rdx
   2f9cc: 48 89 d7                     	movq	%rdx, %rdi
   2f9cf: ff d0                        	callq	*%rax
   2f9d1: 48 83 bd 50 ff ff ff 00      	cmpq	$0x0, -0xb0(%rbp)
   2f9d9: 74 42                        	je	0x2fa1d <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2825>
   2f9db: 48 8b 85 50 ff ff ff         	movq	-0xb0(%rbp), %rax
   2f9e2: 48 8b 00                     	movq	(%rax), %rax
   2f9e5: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2f9e9: 48 8b 85 50 ff ff ff         	movq	-0xb0(%rbp), %rax
   2f9f0: 48 89 10                     	movq	%rdx, (%rax)
   2f9f3: 48 8b 85 50 ff ff ff         	movq	-0xb0(%rbp), %rax
   2f9fa: 48 8b 00                     	movq	(%rax), %rax
   2f9fd: 48 85 c0                     	testq	%rax, %rax
   2fa00: 75 1b                        	jne	0x2fa1d <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2825>
   2fa02: 48 8b 85 50 ff ff ff         	movq	-0xb0(%rbp), %rax
   2fa09: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2fa0d: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2fa11: 48 8b 95 50 ff ff ff         	movq	-0xb0(%rbp), %rdx
   2fa18: 48 89 d7                     	movq	%rdx, %rdi
   2fa1b: ff d0                        	callq	*%rax
   2fa1d: 48 83 bd 58 ff ff ff 00      	cmpq	$0x0, -0xa8(%rbp)
   2fa25: 74 42                        	je	0x2fa69 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2871>
   2fa27: 48 8b 85 58 ff ff ff         	movq	-0xa8(%rbp), %rax
   2fa2e: 48 8b 00                     	movq	(%rax), %rax
   2fa31: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2fa35: 48 8b 85 58 ff ff ff         	movq	-0xa8(%rbp), %rax
   2fa3c: 48 89 10                     	movq	%rdx, (%rax)
   2fa3f: 48 8b 85 58 ff ff ff         	movq	-0xa8(%rbp), %rax
   2fa46: 48 8b 00                     	movq	(%rax), %rax
   2fa49: 48 85 c0                     	testq	%rax, %rax
   2fa4c: 75 1b                        	jne	0x2fa69 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2871>
   2fa4e: 48 8b 85 58 ff ff ff         	movq	-0xa8(%rbp), %rax
   2fa55: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2fa59: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2fa5d: 48 8b 95 58 ff ff ff         	movq	-0xa8(%rbp), %rdx
   2fa64: 48 89 d7                     	movq	%rdx, %rdi
   2fa67: ff d0                        	callq	*%rax
   2fa69: 48 83 bd 60 ff ff ff 00      	cmpq	$0x0, -0xa0(%rbp)
   2fa71: 74 42                        	je	0x2fab5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x28bd>
   2fa73: 48 8b 85 60 ff ff ff         	movq	-0xa0(%rbp), %rax
   2fa7a: 48 8b 00                     	movq	(%rax), %rax
   2fa7d: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2fa81: 48 8b 85 60 ff ff ff         	movq	-0xa0(%rbp), %rax
   2fa88: 48 89 10                     	movq	%rdx, (%rax)
   2fa8b: 48 8b 85 60 ff ff ff         	movq	-0xa0(%rbp), %rax
   2fa92: 48 8b 00                     	movq	(%rax), %rax
   2fa95: 48 85 c0                     	testq	%rax, %rax
   2fa98: 75 1b                        	jne	0x2fab5 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x28bd>
   2fa9a: 48 8b 85 60 ff ff ff         	movq	-0xa0(%rbp), %rax
   2faa1: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2faa5: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2faa9: 48 8b 95 60 ff ff ff         	movq	-0xa0(%rbp), %rdx
   2fab0: 48 89 d7                     	movq	%rdx, %rdi
   2fab3: ff d0                        	callq	*%rax
   2fab5: 48 83 bd 68 ff ff ff 00      	cmpq	$0x0, -0x98(%rbp)
   2fabd: 74 42                        	je	0x2fb01 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2909>
   2fabf: 48 8b 85 68 ff ff ff         	movq	-0x98(%rbp), %rax
   2fac6: 48 8b 00                     	movq	(%rax), %rax
   2fac9: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2facd: 48 8b 85 68 ff ff ff         	movq	-0x98(%rbp), %rax
   2fad4: 48 89 10                     	movq	%rdx, (%rax)
   2fad7: 48 8b 85 68 ff ff ff         	movq	-0x98(%rbp), %rax
   2fade: 48 8b 00                     	movq	(%rax), %rax
   2fae1: 48 85 c0                     	testq	%rax, %rax
   2fae4: 75 1b                        	jne	0x2fb01 <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2909>
   2fae6: 48 8b 85 68 ff ff ff         	movq	-0x98(%rbp), %rax
   2faed: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2faf1: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2faf5: 48 8b 95 68 ff ff ff         	movq	-0x98(%rbp), %rdx
   2fafc: 48 89 d7                     	movq	%rdx, %rdi
   2faff: ff d0                        	callq	*%rax
   2fb01: 48 83 bd 70 ff ff ff 00      	cmpq	$0x0, -0x90(%rbp)
   2fb09: 74 42                        	je	0x2fb4d <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2955>
   2fb0b: 48 8b 85 70 ff ff ff         	movq	-0x90(%rbp), %rax
   2fb12: 48 8b 00                     	movq	(%rax), %rax
   2fb15: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   2fb19: 48 8b 85 70 ff ff ff         	movq	-0x90(%rbp), %rax
   2fb20: 48 89 10                     	movq	%rdx, (%rax)
   2fb23: 48 8b 85 70 ff ff ff         	movq	-0x90(%rbp), %rax
   2fb2a: 48 8b 00                     	movq	(%rax), %rax
   2fb2d: 48 85 c0                     	testq	%rax, %rax
   2fb30: 75 1b                        	jne	0x2fb4d <__pyx_pf_5efuse_9BaseEfuse_14gen_seed8+0x2955>
   2fb32: 48 8b 85 70 ff ff ff         	movq	-0x90(%rbp), %rax
   2fb39: 48 8b 40 08                  	movq	0x8(%rax), %rax
   2fb3d: 48 8b 40 30                  	movq	0x30(%rax), %rax
   2fb41: 48 8b 95 70 ff ff ff         	movq	-0x90(%rbp), %rdx
   2fb48: 48 89 d7                     	movq	%rdx, %rdi
   2fb4b: ff d0                        	callq	*%rax
   2fb4d: 48 8b 85 78 ff ff ff         	movq	-0x88(%rbp), %rax
   2fb54: c9                           	leave
   2fb55: c3                           	retq

000000000002fb56 <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32>:
   2fb56: 55                           	pushq	%rbp
   2fb57: 48 89 e5                     	movq	%rsp, %rbp
   2fb5a: 48 83 ec 70                  	subq	$0x70, %rsp
   2fb5e: 48 89 7d a8                  	movq	%rdi, -0x58(%rbp)
   2fb62: 48 89 75 a0                  	movq	%rsi, -0x60(%rbp)
   2fb66: 48 89 55 98                  	movq	%rdx, -0x68(%rbp)
   2fb6a: 64 48 8b 04 25 28 00 00 00   	movq	%fs:0x28, %rax
   2fb73: 48 89 45 f8                  	movq	%rax, -0x8(%rbp)
   2fb77: 31 c0                        	xorl	%eax, %eax
   2fb79: 48 c7 45 b8 00 00 00 00      	movq	$0x0, -0x48(%rbp)
   2fb81: 48 c7 45 c0 00 00 00 00      	movq	$0x0, -0x40(%rbp)
   2fb89: 48 c7 45 c8 00 00 00 00      	movq	$0x0, -0x38(%rbp)
   2fb91: 48 c7 45 d0 00 00 00 00      	movq	$0x0, -0x30(%rbp)
   2fb99: 48 c7 45 e0 00 00 00 00      	movq	$0x0, -0x20(%rbp)
   2fba1: 48 c7 45 e8 00 00 00 00      	movq	$0x0, -0x18(%rbp)
   2fba9: 48 c7 45 f0 00 00 00 00      	movq	$0x0, -0x10(%rbp)
   2fbb1: 48 83 7d 98 00               	cmpq	$0x0, -0x68(%rbp)
   2fbb6: 0f 95 c0                     	setne	%al
   2fbb9: 0f b6 c0                     	movzbl	%al, %eax
   2fbbc: 48 85 c0                     	testq	%rax, %rax
   2fbbf: 0f 84 27 02 00 00            	je	0x2fdec <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x296>
   2fbc5: 48 8b 45 a0                  	movq	-0x60(%rbp), %rax
   2fbc9: 48 8b 40 10                  	movq	0x10(%rax), %rax
   2fbcd: 48 89 45 d8                  	movq	%rax, -0x28(%rbp)
   2fbd1: 48 8b 45 d8                  	movq	-0x28(%rbp), %rax
   2fbd5: 48 83 f8 01                  	cmpq	$0x1, %rax
   2fbd9: 74 39                        	je	0x2fc14 <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0xbe>
   2fbdb: 48 83 f8 01                  	cmpq	$0x1, %rax
   2fbdf: 7f 0a                        	jg	0x2fbeb <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x95>
   2fbe1: 48 85 c0                     	testq	%rax, %rax
   2fbe4: 74 3a                        	je	0x2fc20 <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0xca>
   2fbe6: e9 72 02 00 00               	jmp	0x2fe5d <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x307>
   2fbeb: 48 83 f8 02                  	cmpq	$0x2, %rax
   2fbef: 74 17                        	je	0x2fc08 <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0xb2>
   2fbf1: 48 83 f8 03                  	cmpq	$0x3, %rax
   2fbf5: 74 05                        	je	0x2fbfc <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0xa6>
   2fbf7: e9 61 02 00 00               	jmp	0x2fe5d <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x307>
   2fbfc: 48 8b 45 a0                  	movq	-0x60(%rbp), %rax
   2fc00: 48 8b 40 28                  	movq	0x28(%rax), %rax
   2fc04: 48 89 45 f0                  	movq	%rax, -0x10(%rbp)
   2fc08: 48 8b 45 a0                  	movq	-0x60(%rbp), %rax
   2fc0c: 48 8b 40 20                  	movq	0x20(%rax), %rax
   2fc10: 48 89 45 e8                  	movq	%rax, -0x18(%rbp)
   2fc14: 48 8b 45 a0                  	movq	-0x60(%rbp), %rax
   2fc18: 48 8b 40 18                  	movq	0x18(%rax), %rax
   2fc1c: 48 89 45 e0                  	movq	%rax, -0x20(%rbp)
   2fc20: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   2fc24: 48 89 c7                     	movq	%rax, %rdi
   2fc27: e8 34 5a fd ff               	callq	0x5660 <PyDict_Size@plt>
   2fc2c: 48 89 45 b0                  	movq	%rax, -0x50(%rbp)
   2fc30: 48 8b 45 d8                  	movq	-0x28(%rbp), %rax
   2fc34: 48 83 f8 01                  	cmpq	$0x1, %rax
   2fc38: 74 48                        	je	0x2fc82 <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x12c>
   2fc3a: 48 83 f8 02                  	cmpq	$0x2, %rax
   2fc3e: 0f 84 b9 00 00 00            	je	0x2fcfd <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x1a7>
   2fc44: 48 85 c0                     	testq	%rax, %rax
   2fc47: 0f 85 2b 01 00 00            	jne	0x2fd78 <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x222>
   2fc4d: 48 8b 15 3c 24 22 00         	movq	0x22243c(%rip), %rdx    # 0x252090 <__pyx_n_s_self>
   2fc54: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   2fc58: 48 89 d6                     	movq	%rdx, %rsi
   2fc5b: 48 89 c7                     	movq	%rax, %rdi
   2fc5e: e8 9d 5c fd ff               	callq	0x5900 <PyDict_GetItem@plt>
   2fc63: 48 89 45 e0                  	movq	%rax, -0x20(%rbp)
   2fc67: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   2fc6b: 48 85 c0                     	testq	%rax, %rax
   2fc6e: 0f 95 c0                     	setne	%al
   2fc71: 0f b6 c0                     	movzbl	%al, %eax
   2fc74: 48 85 c0                     	testq	%rax, %rax
   2fc77: 0f 84 dc 01 00 00            	je	0x2fe59 <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x303>
   2fc7d: 48 83 6d b0 01               	subq	$0x1, -0x50(%rbp)
   2fc82: 48 8b 15 e7 23 22 00         	movq	0x2223e7(%rip), %rdx    # 0x252070 <__pyx_n_s_seed32>
   2fc89: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   2fc8d: 48 89 d6                     	movq	%rdx, %rsi
   2fc90: 48 89 c7                     	movq	%rax, %rdi
   2fc93: e8 68 5c fd ff               	callq	0x5900 <PyDict_GetItem@plt>
   2fc98: 48 89 45 e8                  	movq	%rax, -0x18(%rbp)
   2fc9c: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   2fca0: 48 85 c0                     	testq	%rax, %rax
   2fca3: 0f 95 c0                     	setne	%al
   2fca6: 0f b6 c0                     	movzbl	%al, %eax
   2fca9: 48 85 c0                     	testq	%rax, %rax
   2fcac: 74 07                        	je	0x2fcb5 <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x15f>
   2fcae: 48 83 6d b0 01               	subq	$0x1, -0x50(%rbp)
   2fcb3: eb 48                        	jmp	0x2fcfd <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x1a7>
   2fcb5: 41 b8 01 00 00 00            	movl	$0x1, %r8d
   2fcbb: b9 03 00 00 00               	movl	$0x3, %ecx
   2fcc0: ba 03 00 00 00               	movl	$0x3, %edx
   2fcc5: be 01 00 00 00               	movl	$0x1, %esi
   2fcca: 48 8d 3d d5 c8 01 00         	leaq	0x1c8d5(%rip), %rdi     # 0x4c5a6 <__pyx_k_BaseEfuse___dict_string_parse+0x1c6>
   2fcd1: e8 ac 5d 01 00               	callq	0x45a82 <__Pyx_RaiseArgtupleInvalid>
   2fcd6: 48 8b 05 0b f8 21 00         	movq	0x21f80b(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2fcdd: 48 89 05 64 1e 22 00         	movq	%rax, 0x221e64(%rip)    # 0x251b48 <__pyx_filename>
   2fce4: c7 05 52 1e 22 00 6d 01 00 00	movl	$0x16d, 0x221e52(%rip)  # imm = 0x16D
                                                                        # 0x251b40 <__pyx_lineno>
   2fcee: c7 05 4c 1e 22 00 0b 27 00 00	movl	$0x270b, 0x221e4c(%rip) # imm = 0x270B
                                                                        # 0x251b44 <__pyx_clineno>
   2fcf8: e9 a9 01 00 00               	jmp	0x2fea6 <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x350>
   2fcfd: 48 8b 15 24 23 22 00         	movq	0x222324(%rip), %rdx    # 0x252028 <__pyx_n_s_prv_data>
   2fd04: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   2fd08: 48 89 d6                     	movq	%rdx, %rsi
   2fd0b: 48 89 c7                     	movq	%rax, %rdi
   2fd0e: e8 ed 5b fd ff               	callq	0x5900 <PyDict_GetItem@plt>
   2fd13: 48 89 45 f0                  	movq	%rax, -0x10(%rbp)
   2fd17: 48 8b 45 f0                  	movq	-0x10(%rbp), %rax
   2fd1b: 48 85 c0                     	testq	%rax, %rax
   2fd1e: 0f 95 c0                     	setne	%al
   2fd21: 0f b6 c0                     	movzbl	%al, %eax
   2fd24: 48 85 c0                     	testq	%rax, %rax
   2fd27: 74 07                        	je	0x2fd30 <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x1da>
   2fd29: 48 83 6d b0 01               	subq	$0x1, -0x50(%rbp)
   2fd2e: eb 48                        	jmp	0x2fd78 <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x222>
   2fd30: 41 b8 02 00 00 00            	movl	$0x2, %r8d
   2fd36: b9 03 00 00 00               	movl	$0x3, %ecx
   2fd3b: ba 03 00 00 00               	movl	$0x3, %edx
   2fd40: be 01 00 00 00               	movl	$0x1, %esi
   2fd45: 48 8d 3d 5a c8 01 00         	leaq	0x1c85a(%rip), %rdi     # 0x4c5a6 <__pyx_k_BaseEfuse___dict_string_parse+0x1c6>
   2fd4c: e8 31 5d 01 00               	callq	0x45a82 <__Pyx_RaiseArgtupleInvalid>
   2fd51: 48 8b 05 90 f7 21 00         	movq	0x21f790(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2fd58: 48 89 05 e9 1d 22 00         	movq	%rax, 0x221de9(%rip)    # 0x251b48 <__pyx_filename>
   2fd5f: c7 05 d7 1d 22 00 6d 01 00 00	movl	$0x16d, 0x221dd7(%rip)  # imm = 0x16D
                                                                        # 0x251b40 <__pyx_lineno>
   2fd69: c7 05 d1 1d 22 00 11 27 00 00	movl	$0x2711, 0x221dd1(%rip) # imm = 0x2711
                                                                        # 0x251b44 <__pyx_clineno>
   2fd73: e9 2e 01 00 00               	jmp	0x2fea6 <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x350>
   2fd78: 48 83 7d b0 00               	cmpq	$0x0, -0x50(%rbp)
   2fd7d: 0f 9f c0                     	setg	%al
   2fd80: 0f b6 c0                     	movzbl	%al, %eax
   2fd83: 48 85 c0                     	testq	%rax, %rax
   2fd86: 0f 84 92 00 00 00            	je	0x2fe1e <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x2c8>
   2fd8c: 48 8b 4d d8                  	movq	-0x28(%rbp), %rcx
   2fd90: 48 8d 55 e0                  	leaq	-0x20(%rbp), %rdx
   2fd94: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   2fd98: 4c 8d 0d 07 c8 01 00         	leaq	0x1c807(%rip), %r9      # 0x4c5a6 <__pyx_k_BaseEfuse___dict_string_parse+0x1c6>
   2fd9f: 49 89 c8                     	movq	%rcx, %r8
   2fda2: 48 89 d1                     	movq	%rdx, %rcx
   2fda5: ba 00 00 00 00               	movl	$0x0, %edx
   2fdaa: 48 8d 35 cf 1b 22 00         	leaq	0x221bcf(%rip), %rsi    # 0x251980 <__pyx_pyargnames.13156>
   2fdb1: 48 89 c7                     	movq	%rax, %rdi
   2fdb4: e8 bd 5d 01 00               	callq	0x45b76 <__Pyx_ParseOptionalKeywords>
   2fdb9: c1 e8 1f                     	shrl	$0x1f, %eax
   2fdbc: 0f b6 c0                     	movzbl	%al, %eax
   2fdbf: 48 85 c0                     	testq	%rax, %rax
   2fdc2: 74 5a                        	je	0x2fe1e <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x2c8>
   2fdc4: 48 8b 05 1d f7 21 00         	movq	0x21f71d(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2fdcb: 48 89 05 76 1d 22 00         	movq	%rax, 0x221d76(%rip)    # 0x251b48 <__pyx_filename>
   2fdd2: c7 05 64 1d 22 00 6d 01 00 00	movl	$0x16d, 0x221d64(%rip)  # imm = 0x16D
                                                                        # 0x251b40 <__pyx_lineno>
   2fddc: c7 05 5e 1d 22 00 15 27 00 00	movl	$0x2715, 0x221d5e(%rip) # imm = 0x2715
                                                                        # 0x251b44 <__pyx_clineno>
   2fde6: 90                           	nop
   2fde7: e9 ba 00 00 00               	jmp	0x2fea6 <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x350>
   2fdec: 48 8b 45 a0                  	movq	-0x60(%rbp), %rax
   2fdf0: 48 8b 40 10                  	movq	0x10(%rax), %rax
   2fdf4: 48 83 f8 03                  	cmpq	$0x3, %rax
   2fdf8: 75 62                        	jne	0x2fe5c <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x306>
   2fdfa: 48 8b 45 a0                  	movq	-0x60(%rbp), %rax
   2fdfe: 48 8b 40 18                  	movq	0x18(%rax), %rax
   2fe02: 48 89 45 e0                  	movq	%rax, -0x20(%rbp)
   2fe06: 48 8b 45 a0                  	movq	-0x60(%rbp), %rax
   2fe0a: 48 8b 40 20                  	movq	0x20(%rax), %rax
   2fe0e: 48 89 45 e8                  	movq	%rax, -0x18(%rbp)
   2fe12: 48 8b 45 a0                  	movq	-0x60(%rbp), %rax
   2fe16: 48 8b 40 28                  	movq	0x28(%rax), %rax
   2fe1a: 48 89 45 f0                  	movq	%rax, -0x10(%rbp)
   2fe1e: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   2fe22: 48 89 45 b8                  	movq	%rax, -0x48(%rbp)
   2fe26: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   2fe2a: 48 89 45 c0                  	movq	%rax, -0x40(%rbp)
   2fe2e: 48 8b 45 f0                  	movq	-0x10(%rbp), %rax
   2fe32: 48 89 45 c8                  	movq	%rax, -0x38(%rbp)
   2fe36: 90                           	nop
   2fe37: 48 8b 4d c8                  	movq	-0x38(%rbp), %rcx
   2fe3b: 48 8b 55 c0                  	movq	-0x40(%rbp), %rdx
   2fe3f: 48 8b 75 b8                  	movq	-0x48(%rbp), %rsi
   2fe43: 48 8b 45 a8                  	movq	-0x58(%rbp), %rax
   2fe47: 48 89 c7                     	movq	%rax, %rdi
   2fe4a: e8 93 00 00 00               	callq	0x2fee2 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32>
   2fe4f: 48 89 45 d0                  	movq	%rax, -0x30(%rbp)
   2fe53: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
   2fe57: eb 73                        	jmp	0x2fecc <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x376>
   2fe59: 90                           	nop
   2fe5a: eb 01                        	jmp	0x2fe5d <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x307>
   2fe5c: 90                           	nop
   2fe5d: 48 8b 45 a0                  	movq	-0x60(%rbp), %rax
   2fe61: 48 8b 40 10                  	movq	0x10(%rax), %rax
   2fe65: 49 89 c0                     	movq	%rax, %r8
   2fe68: b9 03 00 00 00               	movl	$0x3, %ecx
   2fe6d: ba 03 00 00 00               	movl	$0x3, %edx
   2fe72: be 01 00 00 00               	movl	$0x1, %esi
   2fe77: 48 8d 3d 28 c7 01 00         	leaq	0x1c728(%rip), %rdi     # 0x4c5a6 <__pyx_k_BaseEfuse___dict_string_parse+0x1c6>
   2fe7e: e8 ff 5b 01 00               	callq	0x45a82 <__Pyx_RaiseArgtupleInvalid>
   2fe83: 48 8b 05 5e f6 21 00         	movq	0x21f65e(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2fe8a: 48 89 05 b7 1c 22 00         	movq	%rax, 0x221cb7(%rip)    # 0x251b48 <__pyx_filename>
   2fe91: c7 05 a5 1c 22 00 6d 01 00 00	movl	$0x16d, 0x221ca5(%rip)  # imm = 0x16D
                                                                        # 0x251b40 <__pyx_lineno>
   2fe9b: c7 05 9f 1c 22 00 24 27 00 00	movl	$0x2724, 0x221c9f(%rip) # imm = 0x2724
                                                                        # 0x251b44 <__pyx_clineno>
   2fea5: 90                           	nop
   2fea6: 48 8b 0d 9b 1c 22 00         	movq	0x221c9b(%rip), %rcx    # 0x251b48 <__pyx_filename>
   2fead: 8b 15 8d 1c 22 00            	movl	0x221c8d(%rip), %edx    # 0x251b40 <__pyx_lineno>
   2feb3: 8b 05 8b 1c 22 00            	movl	0x221c8b(%rip), %eax    # 0x251b44 <__pyx_clineno>
   2feb9: 89 c6                        	movl	%eax, %esi
   2febb: 48 8d 3d ef c6 01 00         	leaq	0x1c6ef(%rip), %rdi     # 0x4c5b1 <__pyx_k_BaseEfuse___dict_string_parse+0x1d1>
   2fec2: e8 07 b4 01 00               	callq	0x4b2ce <__Pyx_AddTraceback>
   2fec7: b8 00 00 00 00               	movl	$0x0, %eax
   2fecc: 48 8b 7d f8                  	movq	-0x8(%rbp), %rdi
   2fed0: 64 48 33 3c 25 28 00 00 00   	xorq	%fs:0x28, %rdi
   2fed9: 74 05                        	je	0x2fee0 <__pyx_pw_5efuse_9BaseEfuse_17gen_seed32+0x38a>
   2fedb: e8 a0 58 fd ff               	callq	0x5780 <__stack_chk_fail@plt>
   2fee0: c9                           	leave
   2fee1: c3                           	retq

000000000002fee2 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32>:
   2fee2: 55                           	pushq	%rbp
   2fee3: 48 89 e5                     	movq	%rsp, %rbp
   2fee6: 48 83 ec 70                  	subq	$0x70, %rsp
   2feea: 48 89 7d a8                  	movq	%rdi, -0x58(%rbp)
   2feee: 48 89 75 a0                  	movq	%rsi, -0x60(%rbp)
   2fef2: 48 89 55 98                  	movq	%rdx, -0x68(%rbp)
   2fef6: 48 89 4d 90                  	movq	%rcx, -0x70(%rbp)
   2fefa: 48 c7 45 b8 00 00 00 00      	movq	$0x0, -0x48(%rbp)
   2ff02: 48 c7 45 c0 00 00 00 00      	movq	$0x0, -0x40(%rbp)
   2ff0a: 48 c7 45 c8 00 00 00 00      	movq	$0x0, -0x38(%rbp)
   2ff12: 48 c7 45 d0 00 00 00 00      	movq	$0x0, -0x30(%rbp)
   2ff1a: 48 c7 45 d8 00 00 00 00      	movq	$0x0, -0x28(%rbp)
   2ff22: 48 c7 45 e0 00 00 00 00      	movq	$0x0, -0x20(%rbp)
   2ff2a: 48 c7 45 e8 00 00 00 00      	movq	$0x0, -0x18(%rbp)
   2ff32: 48 8b 35 5f 22 22 00         	movq	0x22225f(%rip), %rsi    # 0x252198 <__pyx_int_60>
   2ff39: 48 8b 45 90                  	movq	-0x70(%rbp), %rax
   2ff3d: b9 00 00 00 00               	movl	$0x0, %ecx
   2ff42: ba 3c 00 00 00               	movl	$0x3c, %edx
   2ff47: 48 89 c7                     	movq	%rax, %rdi
   2ff4a: e8 8b 83 01 00               	callq	0x482da <__Pyx_PyInt_AndObjC>
   2ff4f: 48 89 45 e0                  	movq	%rax, -0x20(%rbp)
   2ff53: 48 83 7d e0 00               	cmpq	$0x0, -0x20(%rbp)
   2ff58: 0f 94 c0                     	sete	%al
   2ff5b: 0f b6 c0                     	movzbl	%al, %eax
   2ff5e: 48 85 c0                     	testq	%rax, %rax
   2ff61: 74 27                        	je	0x2ff8a <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0xa8>
   2ff63: 48 8b 05 7e f5 21 00         	movq	0x21f57e(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2ff6a: 48 89 05 d7 1b 22 00         	movq	%rax, 0x221bd7(%rip)    # 0x251b48 <__pyx_filename>
   2ff71: c7 05 c5 1b 22 00 70 01 00 00	movl	$0x170, 0x221bc5(%rip)  # imm = 0x170
                                                                        # 0x251b40 <__pyx_lineno>
   2ff7b: c7 05 bf 1b 22 00 43 27 00 00	movl	$0x2743, 0x221bbf(%rip) # imm = 0x2743
                                                                        # 0x251b44 <__pyx_clineno>
   2ff85: e9 15 09 00 00               	jmp	0x3089f <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9bd>
   2ff8a: bf 01 00 00 00               	movl	$0x1, %edi
   2ff8f: e8 bc 59 fd ff               	callq	0x5950 <PyTuple_New@plt>
   2ff94: 48 89 45 e8                  	movq	%rax, -0x18(%rbp)
   2ff98: 48 83 7d e8 00               	cmpq	$0x0, -0x18(%rbp)
   2ff9d: 0f 94 c0                     	sete	%al
   2ffa0: 0f b6 c0                     	movzbl	%al, %eax
   2ffa3: 48 85 c0                     	testq	%rax, %rax
   2ffa6: 74 27                        	je	0x2ffcf <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0xed>
   2ffa8: 48 8b 05 39 f5 21 00         	movq	0x21f539(%rip), %rax    # 0x24f4e8 <__pyx_f>
   2ffaf: 48 89 05 92 1b 22 00         	movq	%rax, 0x221b92(%rip)    # 0x251b48 <__pyx_filename>
   2ffb6: c7 05 80 1b 22 00 70 01 00 00	movl	$0x170, 0x221b80(%rip)  # imm = 0x170
                                                                        # 0x251b40 <__pyx_lineno>
   2ffc0: c7 05 7a 1b 22 00 45 27 00 00	movl	$0x2745, 0x221b7a(%rip) # imm = 0x2745
                                                                        # 0x251b44 <__pyx_clineno>
   2ffca: e9 d0 08 00 00               	jmp	0x3089f <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9bd>
   2ffcf: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   2ffd3: 48 8b 55 e0                  	movq	-0x20(%rbp), %rdx
   2ffd7: 48 89 50 18                  	movq	%rdx, 0x18(%rax)
   2ffdb: 48 c7 45 e0 00 00 00 00      	movq	$0x0, -0x20(%rbp)
   2ffe3: 48 8b 05 9e 1b 22 00         	movq	0x221b9e(%rip), %rax    # 0x251b88 <__pyx_builtin_bin>
   2ffea: 48 8b 4d e8                  	movq	-0x18(%rbp), %rcx
   2ffee: ba 00 00 00 00               	movl	$0x0, %edx
   2fff3: 48 89 ce                     	movq	%rcx, %rsi
   2fff6: 48 89 c7                     	movq	%rax, %rdi
   2fff9: e8 28 65 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   2fffe: 48 89 45 e0                  	movq	%rax, -0x20(%rbp)
   30002: 48 83 7d e0 00               	cmpq	$0x0, -0x20(%rbp)
   30007: 0f 94 c0                     	sete	%al
   3000a: 0f b6 c0                     	movzbl	%al, %eax
   3000d: 48 85 c0                     	testq	%rax, %rax
   30010: 74 27                        	je	0x30039 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x157>
   30012: 48 8b 05 cf f4 21 00         	movq	0x21f4cf(%rip), %rax    # 0x24f4e8 <__pyx_f>
   30019: 48 89 05 28 1b 22 00         	movq	%rax, 0x221b28(%rip)    # 0x251b48 <__pyx_filename>
   30020: c7 05 16 1b 22 00 70 01 00 00	movl	$0x170, 0x221b16(%rip)  # imm = 0x170
                                                                        # 0x251b40 <__pyx_lineno>
   3002a: c7 05 10 1b 22 00 4a 27 00 00	movl	$0x274a, 0x221b10(%rip) # imm = 0x274A
                                                                        # 0x251b44 <__pyx_clineno>
   30034: e9 66 08 00 00               	jmp	0x3089f <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9bd>
   30039: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   3003d: 48 8b 00                     	movq	(%rax), %rax
   30040: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   30044: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   30048: 48 89 10                     	movq	%rdx, (%rax)
   3004b: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   3004f: 48 8b 00                     	movq	(%rax), %rax
   30052: 48 85 c0                     	testq	%rax, %rax
   30055: 75 15                        	jne	0x3006c <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x18a>
   30057: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   3005b: 48 8b 40 08                  	movq	0x8(%rax), %rax
   3005f: 48 8b 40 30                  	movq	0x30(%rax), %rax
   30063: 48 8b 55 e8                  	movq	-0x18(%rbp), %rdx
   30067: 48 89 d7                     	movq	%rdx, %rdi
   3006a: ff d0                        	callq	*%rax
   3006c: 48 c7 45 e8 00 00 00 00      	movq	$0x0, -0x18(%rbp)
   30074: 48 8b 15 25 1d 22 00         	movq	0x221d25(%rip), %rdx    # 0x251da0 <__pyx_n_s_count>
   3007b: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   3007f: 48 89 d6                     	movq	%rdx, %rsi
   30082: 48 89 c7                     	movq	%rax, %rdi
   30085: e8 40 5c fd ff               	callq	0x5cca <__Pyx_PyObject_GetAttrStr>
   3008a: 48 89 45 e8                  	movq	%rax, -0x18(%rbp)
   3008e: 48 83 7d e8 00               	cmpq	$0x0, -0x18(%rbp)
   30093: 0f 94 c0                     	sete	%al
   30096: 0f b6 c0                     	movzbl	%al, %eax
   30099: 48 85 c0                     	testq	%rax, %rax
   3009c: 74 27                        	je	0x300c5 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x1e3>
   3009e: 48 8b 05 43 f4 21 00         	movq	0x21f443(%rip), %rax    # 0x24f4e8 <__pyx_f>
   300a5: 48 89 05 9c 1a 22 00         	movq	%rax, 0x221a9c(%rip)    # 0x251b48 <__pyx_filename>
   300ac: c7 05 8a 1a 22 00 70 01 00 00	movl	$0x170, 0x221a8a(%rip)  # imm = 0x170
                                                                        # 0x251b40 <__pyx_lineno>
   300b6: c7 05 84 1a 22 00 4d 27 00 00	movl	$0x274d, 0x221a84(%rip) # imm = 0x274D
                                                                        # 0x251b44 <__pyx_clineno>
   300c0: e9 da 07 00 00               	jmp	0x3089f <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9bd>
   300c5: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   300c9: 48 8b 00                     	movq	(%rax), %rax
   300cc: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   300d0: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   300d4: 48 89 10                     	movq	%rdx, (%rax)
   300d7: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   300db: 48 8b 00                     	movq	(%rax), %rax
   300de: 48 85 c0                     	testq	%rax, %rax
   300e1: 75 15                        	jne	0x300f8 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x216>
   300e3: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   300e7: 48 8b 40 08                  	movq	0x8(%rax), %rax
   300eb: 48 8b 40 30                  	movq	0x30(%rax), %rax
   300ef: 48 8b 55 e0                  	movq	-0x20(%rbp), %rdx
   300f3: 48 89 d7                     	movq	%rdx, %rdi
   300f6: ff d0                        	callq	*%rax
   300f8: 48 c7 45 e0 00 00 00 00      	movq	$0x0, -0x20(%rbp)
   30100: 48 8b 0d d1 22 22 00         	movq	0x2222d1(%rip), %rcx    # 0x2523d8 <__pyx_tuple__42>
   30107: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   3010b: ba 00 00 00 00               	movl	$0x0, %edx
   30110: 48 89 ce                     	movq	%rcx, %rsi
   30113: 48 89 c7                     	movq	%rax, %rdi
   30116: e8 0b 64 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   3011b: 48 89 45 e0                  	movq	%rax, -0x20(%rbp)
   3011f: 48 83 7d e0 00               	cmpq	$0x0, -0x20(%rbp)
   30124: 0f 94 c0                     	sete	%al
   30127: 0f b6 c0                     	movzbl	%al, %eax
   3012a: 48 85 c0                     	testq	%rax, %rax
   3012d: 74 27                        	je	0x30156 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x274>
   3012f: 48 8b 05 b2 f3 21 00         	movq	0x21f3b2(%rip), %rax    # 0x24f4e8 <__pyx_f>
   30136: 48 89 05 0b 1a 22 00         	movq	%rax, 0x221a0b(%rip)    # 0x251b48 <__pyx_filename>
   3013d: c7 05 f9 19 22 00 70 01 00 00	movl	$0x170, 0x2219f9(%rip)  # imm = 0x170
                                                                        # 0x251b40 <__pyx_lineno>
   30147: c7 05 f3 19 22 00 50 27 00 00	movl	$0x2750, 0x2219f3(%rip) # imm = 0x2750
                                                                        # 0x251b44 <__pyx_clineno>
   30151: e9 49 07 00 00               	jmp	0x3089f <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9bd>
   30156: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   3015a: 48 8b 00                     	movq	(%rax), %rax
   3015d: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   30161: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   30165: 48 89 10                     	movq	%rdx, (%rax)
   30168: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   3016c: 48 8b 00                     	movq	(%rax), %rax
   3016f: 48 85 c0                     	testq	%rax, %rax
   30172: 75 15                        	jne	0x30189 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x2a7>
   30174: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   30178: 48 8b 40 08                  	movq	0x8(%rax), %rax
   3017c: 48 8b 40 30                  	movq	0x30(%rax), %rax
   30180: 48 8b 55 e8                  	movq	-0x18(%rbp), %rdx
   30184: 48 89 d7                     	movq	%rdx, %rdi
   30187: ff d0                        	callq	*%rax
   30189: 48 c7 45 e8 00 00 00 00      	movq	$0x0, -0x18(%rbp)
   30191: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   30195: 48 89 45 b8                  	movq	%rax, -0x48(%rbp)
   30199: 48 c7 45 e0 00 00 00 00      	movq	$0x0, -0x20(%rbp)
   301a1: 48 8b 55 b8                  	movq	-0x48(%rbp), %rdx
   301a5: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   301a9: 48 89 d6                     	movq	%rdx, %rsi
   301ac: 48 89 c7                     	movq	%rax, %rdi
   301af: e8 bc 59 fd ff               	callq	0x5b70 <PyNumber_Xor@plt>
   301b4: 48 89 45 e0                  	movq	%rax, -0x20(%rbp)
   301b8: 48 83 7d e0 00               	cmpq	$0x0, -0x20(%rbp)
   301bd: 0f 94 c0                     	sete	%al
   301c0: 0f b6 c0                     	movzbl	%al, %eax
   301c3: 48 85 c0                     	testq	%rax, %rax
   301c6: 74 27                        	je	0x301ef <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x30d>
   301c8: 48 8b 05 19 f3 21 00         	movq	0x21f319(%rip), %rax    # 0x24f4e8 <__pyx_f>
   301cf: 48 89 05 72 19 22 00         	movq	%rax, 0x221972(%rip)    # 0x251b48 <__pyx_filename>
   301d6: c7 05 60 19 22 00 73 01 00 00	movl	$0x173, 0x221960(%rip)  # imm = 0x173
                                                                        # 0x251b40 <__pyx_lineno>
   301e0: c7 05 5a 19 22 00 5d 27 00 00	movl	$0x275d, 0x22195a(%rip) # imm = 0x275D
                                                                        # 0x251b44 <__pyx_clineno>
   301ea: e9 b0 06 00 00               	jmp	0x3089f <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9bd>
   301ef: 48 8b 35 52 1f 22 00         	movq	0x221f52(%rip), %rsi    # 0x252148 <__pyx_int_1>
   301f6: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   301fa: b9 00 00 00 00               	movl	$0x0, %ecx
   301ff: ba 01 00 00 00               	movl	$0x1, %edx
   30204: 48 89 c7                     	movq	%rax, %rdi
   30207: e8 ce 80 01 00               	callq	0x482da <__Pyx_PyInt_AndObjC>
   3020c: 48 89 45 e8                  	movq	%rax, -0x18(%rbp)
   30210: 48 83 7d e8 00               	cmpq	$0x0, -0x18(%rbp)
   30215: 0f 94 c0                     	sete	%al
   30218: 0f b6 c0                     	movzbl	%al, %eax
   3021b: 48 85 c0                     	testq	%rax, %rax
   3021e: 74 27                        	je	0x30247 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x365>
   30220: 48 8b 05 c1 f2 21 00         	movq	0x21f2c1(%rip), %rax    # 0x24f4e8 <__pyx_f>
   30227: 48 89 05 1a 19 22 00         	movq	%rax, 0x22191a(%rip)    # 0x251b48 <__pyx_filename>
   3022e: c7 05 08 19 22 00 73 01 00 00	movl	$0x173, 0x221908(%rip)  # imm = 0x173
                                                                        # 0x251b40 <__pyx_lineno>
   30238: c7 05 02 19 22 00 5f 27 00 00	movl	$0x275f, 0x221902(%rip) # imm = 0x275F
                                                                        # 0x251b44 <__pyx_clineno>
   30242: e9 58 06 00 00               	jmp	0x3089f <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9bd>
   30247: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   3024b: 48 8b 00                     	movq	(%rax), %rax
   3024e: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   30252: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   30256: 48 89 10                     	movq	%rdx, (%rax)
   30259: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   3025d: 48 8b 00                     	movq	(%rax), %rax
   30260: 48 85 c0                     	testq	%rax, %rax
   30263: 75 15                        	jne	0x3027a <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x398>
   30265: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   30269: 48 8b 40 08                  	movq	0x8(%rax), %rax
   3026d: 48 8b 40 30                  	movq	0x30(%rax), %rax
   30271: 48 8b 55 e0                  	movq	-0x20(%rbp), %rdx
   30275: 48 89 d7                     	movq	%rdx, %rdi
   30278: ff d0                        	callq	*%rax
   3027a: 48 c7 45 e0 00 00 00 00      	movq	$0x0, -0x20(%rbp)
   30282: 48 8b 35 bf 1e 22 00         	movq	0x221ebf(%rip), %rsi    # 0x252148 <__pyx_int_1>
   30289: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   3028d: b9 00 00 00 00               	movl	$0x0, %ecx
   30292: ba 01 00 00 00               	movl	$0x1, %edx
   30297: 48 89 c7                     	movq	%rax, %rdi
   3029a: e8 1b 82 01 00               	callq	0x484ba <__Pyx_PyInt_LshiftObjC>
   3029f: 48 89 45 e0                  	movq	%rax, -0x20(%rbp)
   302a3: 48 83 7d e0 00               	cmpq	$0x0, -0x20(%rbp)
   302a8: 0f 94 c0                     	sete	%al
   302ab: 0f b6 c0                     	movzbl	%al, %eax
   302ae: 48 85 c0                     	testq	%rax, %rax
   302b1: 74 27                        	je	0x302da <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x3f8>
   302b3: 48 8b 05 2e f2 21 00         	movq	0x21f22e(%rip), %rax    # 0x24f4e8 <__pyx_f>
   302ba: 48 89 05 87 18 22 00         	movq	%rax, 0x221887(%rip)    # 0x251b48 <__pyx_filename>
   302c1: c7 05 75 18 22 00 73 01 00 00	movl	$0x173, 0x221875(%rip)  # imm = 0x173
                                                                        # 0x251b40 <__pyx_lineno>
   302cb: c7 05 6f 18 22 00 62 27 00 00	movl	$0x2762, 0x22186f(%rip) # imm = 0x2762
                                                                        # 0x251b44 <__pyx_clineno>
   302d5: e9 c5 05 00 00               	jmp	0x3089f <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9bd>
   302da: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   302de: 48 8b 00                     	movq	(%rax), %rax
   302e1: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   302e5: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   302e9: 48 89 10                     	movq	%rdx, (%rax)
   302ec: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   302f0: 48 8b 00                     	movq	(%rax), %rax
   302f3: 48 85 c0                     	testq	%rax, %rax
   302f6: 75 15                        	jne	0x3030d <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x42b>
   302f8: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   302fc: 48 8b 40 08                  	movq	0x8(%rax), %rax
   30300: 48 8b 40 30                  	movq	0x30(%rax), %rax
   30304: 48 8b 55 e8                  	movq	-0x18(%rbp), %rdx
   30308: 48 89 d7                     	movq	%rdx, %rdi
   3030b: ff d0                        	callq	*%rax
   3030d: 48 c7 45 e8 00 00 00 00      	movq	$0x0, -0x18(%rbp)
   30315: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   30319: 48 89 45 c0                  	movq	%rax, -0x40(%rbp)
   3031d: 48 c7 45 e0 00 00 00 00      	movq	$0x0, -0x20(%rbp)
   30325: 48 8b 15 44 1f 22 00         	movq	0x221f44(%rip), %rdx    # 0x252270 <__pyx_int_2187366107>
   3032c: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   30330: 48 89 d6                     	movq	%rdx, %rsi
   30333: 48 89 c7                     	movq	%rax, %rdi
   30336: e8 8d 58 fd ff               	callq	0x5bc8 <PyNumber_And@plt>
   3033b: 48 89 45 e0                  	movq	%rax, -0x20(%rbp)
   3033f: 48 83 7d e0 00               	cmpq	$0x0, -0x20(%rbp)
   30344: 0f 94 c0                     	sete	%al
   30347: 0f b6 c0                     	movzbl	%al, %eax
   3034a: 48 85 c0                     	testq	%rax, %rax
   3034d: 74 27                        	je	0x30376 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x494>
   3034f: 48 8b 05 92 f1 21 00         	movq	0x21f192(%rip), %rax    # 0x24f4e8 <__pyx_f>
   30356: 48 89 05 eb 17 22 00         	movq	%rax, 0x2217eb(%rip)    # 0x251b48 <__pyx_filename>
   3035d: c7 05 d9 17 22 00 77 01 00 00	movl	$0x177, 0x2217d9(%rip)  # imm = 0x177
                                                                        # 0x251b40 <__pyx_lineno>
   30367: c7 05 d3 17 22 00 6f 27 00 00	movl	$0x276f, 0x2217d3(%rip) # imm = 0x276F
                                                                        # 0x251b44 <__pyx_clineno>
   30371: e9 29 05 00 00               	jmp	0x3089f <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9bd>
   30376: bf 01 00 00 00               	movl	$0x1, %edi
   3037b: e8 d0 55 fd ff               	callq	0x5950 <PyTuple_New@plt>
   30380: 48 89 45 e8                  	movq	%rax, -0x18(%rbp)
   30384: 48 83 7d e8 00               	cmpq	$0x0, -0x18(%rbp)
   30389: 0f 94 c0                     	sete	%al
   3038c: 0f b6 c0                     	movzbl	%al, %eax
   3038f: 48 85 c0                     	testq	%rax, %rax
   30392: 74 27                        	je	0x303bb <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x4d9>
   30394: 48 8b 05 4d f1 21 00         	movq	0x21f14d(%rip), %rax    # 0x24f4e8 <__pyx_f>
   3039b: 48 89 05 a6 17 22 00         	movq	%rax, 0x2217a6(%rip)    # 0x251b48 <__pyx_filename>
   303a2: c7 05 94 17 22 00 77 01 00 00	movl	$0x177, 0x221794(%rip)  # imm = 0x177
                                                                        # 0x251b40 <__pyx_lineno>
   303ac: c7 05 8e 17 22 00 71 27 00 00	movl	$0x2771, 0x22178e(%rip) # imm = 0x2771
                                                                        # 0x251b44 <__pyx_clineno>
   303b6: e9 e4 04 00 00               	jmp	0x3089f <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9bd>
   303bb: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   303bf: 48 8b 55 e0                  	movq	-0x20(%rbp), %rdx
   303c3: 48 89 50 18                  	movq	%rdx, 0x18(%rax)
   303c7: 48 c7 45 e0 00 00 00 00      	movq	$0x0, -0x20(%rbp)
   303cf: 48 8b 05 b2 17 22 00         	movq	0x2217b2(%rip), %rax    # 0x251b88 <__pyx_builtin_bin>
   303d6: 48 8b 4d e8                  	movq	-0x18(%rbp), %rcx
   303da: ba 00 00 00 00               	movl	$0x0, %edx
   303df: 48 89 ce                     	movq	%rcx, %rsi
   303e2: 48 89 c7                     	movq	%rax, %rdi
   303e5: e8 3c 61 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   303ea: 48 89 45 e0                  	movq	%rax, -0x20(%rbp)
   303ee: 48 83 7d e0 00               	cmpq	$0x0, -0x20(%rbp)
   303f3: 0f 94 c0                     	sete	%al
   303f6: 0f b6 c0                     	movzbl	%al, %eax
   303f9: 48 85 c0                     	testq	%rax, %rax
   303fc: 74 27                        	je	0x30425 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x543>
   303fe: 48 8b 05 e3 f0 21 00         	movq	0x21f0e3(%rip), %rax    # 0x24f4e8 <__pyx_f>
   30405: 48 89 05 3c 17 22 00         	movq	%rax, 0x22173c(%rip)    # 0x251b48 <__pyx_filename>
   3040c: c7 05 2a 17 22 00 77 01 00 00	movl	$0x177, 0x22172a(%rip)  # imm = 0x177
                                                                        # 0x251b40 <__pyx_lineno>
   30416: c7 05 24 17 22 00 76 27 00 00	movl	$0x2776, 0x221724(%rip) # imm = 0x2776
                                                                        # 0x251b44 <__pyx_clineno>
   30420: e9 7a 04 00 00               	jmp	0x3089f <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9bd>
   30425: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   30429: 48 8b 00                     	movq	(%rax), %rax
   3042c: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   30430: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   30434: 48 89 10                     	movq	%rdx, (%rax)
   30437: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   3043b: 48 8b 00                     	movq	(%rax), %rax
   3043e: 48 85 c0                     	testq	%rax, %rax
   30441: 75 15                        	jne	0x30458 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x576>
   30443: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   30447: 48 8b 40 08                  	movq	0x8(%rax), %rax
   3044b: 48 8b 40 30                  	movq	0x30(%rax), %rax
   3044f: 48 8b 55 e8                  	movq	-0x18(%rbp), %rdx
   30453: 48 89 d7                     	movq	%rdx, %rdi
   30456: ff d0                        	callq	*%rax
   30458: 48 c7 45 e8 00 00 00 00      	movq	$0x0, -0x18(%rbp)
   30460: 48 8b 15 39 19 22 00         	movq	0x221939(%rip), %rdx    # 0x251da0 <__pyx_n_s_count>
   30467: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   3046b: 48 89 d6                     	movq	%rdx, %rsi
   3046e: 48 89 c7                     	movq	%rax, %rdi
   30471: e8 54 58 fd ff               	callq	0x5cca <__Pyx_PyObject_GetAttrStr>
   30476: 48 89 45 e8                  	movq	%rax, -0x18(%rbp)
   3047a: 48 83 7d e8 00               	cmpq	$0x0, -0x18(%rbp)
   3047f: 0f 94 c0                     	sete	%al
   30482: 0f b6 c0                     	movzbl	%al, %eax
   30485: 48 85 c0                     	testq	%rax, %rax
   30488: 74 27                        	je	0x304b1 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x5cf>
   3048a: 48 8b 05 57 f0 21 00         	movq	0x21f057(%rip), %rax    # 0x24f4e8 <__pyx_f>
   30491: 48 89 05 b0 16 22 00         	movq	%rax, 0x2216b0(%rip)    # 0x251b48 <__pyx_filename>
   30498: c7 05 9e 16 22 00 77 01 00 00	movl	$0x177, 0x22169e(%rip)  # imm = 0x177
                                                                        # 0x251b40 <__pyx_lineno>
   304a2: c7 05 98 16 22 00 79 27 00 00	movl	$0x2779, 0x221698(%rip) # imm = 0x2779
                                                                        # 0x251b44 <__pyx_clineno>
   304ac: e9 ee 03 00 00               	jmp	0x3089f <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9bd>
   304b1: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   304b5: 48 8b 00                     	movq	(%rax), %rax
   304b8: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   304bc: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   304c0: 48 89 10                     	movq	%rdx, (%rax)
   304c3: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   304c7: 48 8b 00                     	movq	(%rax), %rax
   304ca: 48 85 c0                     	testq	%rax, %rax
   304cd: 75 15                        	jne	0x304e4 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x602>
   304cf: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   304d3: 48 8b 40 08                  	movq	0x8(%rax), %rax
   304d7: 48 8b 40 30                  	movq	0x30(%rax), %rax
   304db: 48 8b 55 e0                  	movq	-0x20(%rbp), %rdx
   304df: 48 89 d7                     	movq	%rdx, %rdi
   304e2: ff d0                        	callq	*%rax
   304e4: 48 c7 45 e0 00 00 00 00      	movq	$0x0, -0x20(%rbp)
   304ec: 48 8b 0d ed 1e 22 00         	movq	0x221eed(%rip), %rcx    # 0x2523e0 <__pyx_tuple__43>
   304f3: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   304f7: ba 00 00 00 00               	movl	$0x0, %edx
   304fc: 48 89 ce                     	movq	%rcx, %rsi
   304ff: 48 89 c7                     	movq	%rax, %rdi
   30502: e8 1f 60 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   30507: 48 89 45 e0                  	movq	%rax, -0x20(%rbp)
   3050b: 48 83 7d e0 00               	cmpq	$0x0, -0x20(%rbp)
   30510: 0f 94 c0                     	sete	%al
   30513: 0f b6 c0                     	movzbl	%al, %eax
   30516: 48 85 c0                     	testq	%rax, %rax
   30519: 74 27                        	je	0x30542 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x660>
   3051b: 48 8b 05 c6 ef 21 00         	movq	0x21efc6(%rip), %rax    # 0x24f4e8 <__pyx_f>
   30522: 48 89 05 1f 16 22 00         	movq	%rax, 0x22161f(%rip)    # 0x251b48 <__pyx_filename>
   30529: c7 05 0d 16 22 00 77 01 00 00	movl	$0x177, 0x22160d(%rip)  # imm = 0x177
                                                                        # 0x251b40 <__pyx_lineno>
   30533: c7 05 07 16 22 00 7c 27 00 00	movl	$0x277c, 0x221607(%rip) # imm = 0x277C
                                                                        # 0x251b44 <__pyx_clineno>
   3053d: e9 5d 03 00 00               	jmp	0x3089f <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9bd>
   30542: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   30546: 48 8b 00                     	movq	(%rax), %rax
   30549: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   3054d: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   30551: 48 89 10                     	movq	%rdx, (%rax)
   30554: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   30558: 48 8b 00                     	movq	(%rax), %rax
   3055b: 48 85 c0                     	testq	%rax, %rax
   3055e: 75 15                        	jne	0x30575 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x693>
   30560: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   30564: 48 8b 40 08                  	movq	0x8(%rax), %rax
   30568: 48 8b 40 30                  	movq	0x30(%rax), %rax
   3056c: 48 8b 55 e8                  	movq	-0x18(%rbp), %rdx
   30570: 48 89 d7                     	movq	%rdx, %rdi
   30573: ff d0                        	callq	*%rax
   30575: 48 c7 45 e8 00 00 00 00      	movq	$0x0, -0x18(%rbp)
   3057d: 48 8b 45 b8                  	movq	-0x48(%rbp), %rax
   30581: 48 89 45 f0                  	movq	%rax, -0x10(%rbp)
   30585: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   30589: 48 89 45 b8                  	movq	%rax, -0x48(%rbp)
   3058d: 48 8b 45 f0                  	movq	-0x10(%rbp), %rax
   30591: 48 8b 00                     	movq	(%rax), %rax
   30594: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   30598: 48 8b 45 f0                  	movq	-0x10(%rbp), %rax
   3059c: 48 89 10                     	movq	%rdx, (%rax)
   3059f: 48 8b 45 f0                  	movq	-0x10(%rbp), %rax
   305a3: 48 8b 00                     	movq	(%rax), %rax
   305a6: 48 85 c0                     	testq	%rax, %rax
   305a9: 75 15                        	jne	0x305c0 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x6de>
   305ab: 48 8b 45 f0                  	movq	-0x10(%rbp), %rax
   305af: 48 8b 40 08                  	movq	0x8(%rax), %rax
   305b3: 48 8b 40 30                  	movq	0x30(%rax), %rax
   305b7: 48 8b 55 f0                  	movq	-0x10(%rbp), %rdx
   305bb: 48 89 d7                     	movq	%rdx, %rdi
   305be: ff d0                        	callq	*%rax
   305c0: 48 c7 45 e0 00 00 00 00      	movq	$0x0, -0x20(%rbp)
   305c8: 48 8b 35 79 1b 22 00         	movq	0x221b79(%rip), %rsi    # 0x252148 <__pyx_int_1>
   305cf: 48 8b 45 b8                  	movq	-0x48(%rbp), %rax
   305d3: b9 00 00 00 00               	movl	$0x0, %ecx
   305d8: ba 01 00 00 00               	movl	$0x1, %edx
   305dd: 48 89 c7                     	movq	%rax, %rdi
   305e0: e8 f5 7c 01 00               	callq	0x482da <__Pyx_PyInt_AndObjC>
   305e5: 48 89 45 e0                  	movq	%rax, -0x20(%rbp)
   305e9: 48 83 7d e0 00               	cmpq	$0x0, -0x20(%rbp)
   305ee: 0f 94 c0                     	sete	%al
   305f1: 0f b6 c0                     	movzbl	%al, %eax
   305f4: 48 85 c0                     	testq	%rax, %rax
   305f7: 74 27                        	je	0x30620 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x73e>
   305f9: 48 8b 05 e8 ee 21 00         	movq	0x21eee8(%rip), %rax    # 0x24f4e8 <__pyx_f>
   30600: 48 89 05 41 15 22 00         	movq	%rax, 0x221541(%rip)    # 0x251b48 <__pyx_filename>
   30607: c7 05 2f 15 22 00 79 01 00 00	movl	$0x179, 0x22152f(%rip)  # imm = 0x179
                                                                        # 0x251b40 <__pyx_lineno>
   30611: c7 05 29 15 22 00 89 27 00 00	movl	$0x2789, 0x221529(%rip) # imm = 0x2789
                                                                        # 0x251b44 <__pyx_clineno>
   3061b: e9 7f 02 00 00               	jmp	0x3089f <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9bd>
   30620: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   30624: 48 89 45 c8                  	movq	%rax, -0x38(%rbp)
   30628: 48 c7 45 e0 00 00 00 00      	movq	$0x0, -0x20(%rbp)
   30630: 48 8b 35 11 1b 22 00         	movq	0x221b11(%rip), %rsi    # 0x252148 <__pyx_int_1>
   30637: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   3063b: b9 00 00 00 00               	movl	$0x0, %ecx
   30640: ba 01 00 00 00               	movl	$0x1, %edx
   30645: 48 89 c7                     	movq	%rax, %rdi
   30648: e8 6d 7e 01 00               	callq	0x484ba <__Pyx_PyInt_LshiftObjC>
   3064d: 48 89 45 e0                  	movq	%rax, -0x20(%rbp)
   30651: 48 83 7d e0 00               	cmpq	$0x0, -0x20(%rbp)
   30656: 0f 94 c0                     	sete	%al
   30659: 0f b6 c0                     	movzbl	%al, %eax
   3065c: 48 85 c0                     	testq	%rax, %rax
   3065f: 74 27                        	je	0x30688 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x7a6>
   30661: 48 8b 05 80 ee 21 00         	movq	0x21ee80(%rip), %rax    # 0x24f4e8 <__pyx_f>
   30668: 48 89 05 d9 14 22 00         	movq	%rax, 0x2214d9(%rip)    # 0x251b48 <__pyx_filename>
   3066f: c7 05 c7 14 22 00 7c 01 00 00	movl	$0x17c, 0x2214c7(%rip)  # imm = 0x17C
                                                                        # 0x251b40 <__pyx_lineno>
   30679: c7 05 c1 14 22 00 95 27 00 00	movl	$0x2795, 0x2214c1(%rip) # imm = 0x2795
                                                                        # 0x251b44 <__pyx_clineno>
   30683: e9 17 02 00 00               	jmp	0x3089f <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9bd>
   30688: 48 8b 15 e9 1b 22 00         	movq	0x221be9(%rip), %rdx    # 0x252278 <__pyx_int_4294967292>
   3068f: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   30693: 48 89 d6                     	movq	%rdx, %rsi
   30696: 48 89 c7                     	movq	%rax, %rdi
   30699: e8 2a 55 fd ff               	callq	0x5bc8 <PyNumber_And@plt>
   3069e: 48 89 45 e8                  	movq	%rax, -0x18(%rbp)
   306a2: 48 83 7d e8 00               	cmpq	$0x0, -0x18(%rbp)
   306a7: 0f 94 c0                     	sete	%al
   306aa: 0f b6 c0                     	movzbl	%al, %eax
   306ad: 48 85 c0                     	testq	%rax, %rax
   306b0: 74 27                        	je	0x306d9 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x7f7>
   306b2: 48 8b 05 2f ee 21 00         	movq	0x21ee2f(%rip), %rax    # 0x24f4e8 <__pyx_f>
   306b9: 48 89 05 88 14 22 00         	movq	%rax, 0x221488(%rip)    # 0x251b48 <__pyx_filename>
   306c0: c7 05 76 14 22 00 7c 01 00 00	movl	$0x17c, 0x221476(%rip)  # imm = 0x17C
                                                                        # 0x251b40 <__pyx_lineno>
   306ca: c7 05 70 14 22 00 97 27 00 00	movl	$0x2797, 0x221470(%rip) # imm = 0x2797
                                                                        # 0x251b44 <__pyx_clineno>
   306d4: e9 c6 01 00 00               	jmp	0x3089f <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9bd>
   306d9: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   306dd: 48 8b 00                     	movq	(%rax), %rax
   306e0: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   306e4: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   306e8: 48 89 10                     	movq	%rdx, (%rax)
   306eb: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   306ef: 48 8b 00                     	movq	(%rax), %rax
   306f2: 48 85 c0                     	testq	%rax, %rax
   306f5: 75 15                        	jne	0x3070c <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x82a>
   306f7: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   306fb: 48 8b 40 08                  	movq	0x8(%rax), %rax
   306ff: 48 8b 40 30                  	movq	0x30(%rax), %rax
   30703: 48 8b 55 e0                  	movq	-0x20(%rbp), %rdx
   30707: 48 89 d7                     	movq	%rdx, %rdi
   3070a: ff d0                        	callq	*%rax
   3070c: 48 c7 45 e0 00 00 00 00      	movq	$0x0, -0x20(%rbp)
   30714: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   30718: 48 89 45 d0                  	movq	%rax, -0x30(%rbp)
   3071c: 48 c7 45 e8 00 00 00 00      	movq	$0x0, -0x18(%rbp)
   30724: 48 8b 55 c0                  	movq	-0x40(%rbp), %rdx
   30728: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
   3072c: 48 89 d6                     	movq	%rdx, %rsi
   3072f: 48 89 c7                     	movq	%rax, %rdi
   30732: e8 89 54 fd ff               	callq	0x5bc0 <PyNumber_Add@plt>
   30737: 48 89 45 e8                  	movq	%rax, -0x18(%rbp)
   3073b: 48 83 7d e8 00               	cmpq	$0x0, -0x18(%rbp)
   30740: 0f 94 c0                     	sete	%al
   30743: 0f b6 c0                     	movzbl	%al, %eax
   30746: 48 85 c0                     	testq	%rax, %rax
   30749: 74 27                        	je	0x30772 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x890>
   3074b: 48 8b 05 96 ed 21 00         	movq	0x21ed96(%rip), %rax    # 0x24f4e8 <__pyx_f>
   30752: 48 89 05 ef 13 22 00         	movq	%rax, 0x2213ef(%rip)    # 0x251b48 <__pyx_filename>
   30759: c7 05 dd 13 22 00 7d 01 00 00	movl	$0x17d, 0x2213dd(%rip)  # imm = 0x17D
                                                                        # 0x251b40 <__pyx_lineno>
   30763: c7 05 d7 13 22 00 a4 27 00 00	movl	$0x27a4, 0x2213d7(%rip) # imm = 0x27A4
                                                                        # 0x251b44 <__pyx_clineno>
   3076d: e9 2d 01 00 00               	jmp	0x3089f <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9bd>
   30772: 48 8b 55 c8                  	movq	-0x38(%rbp), %rdx
   30776: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   3077a: 48 89 d6                     	movq	%rdx, %rsi
   3077d: 48 89 c7                     	movq	%rax, %rdi
   30780: e8 3b 54 fd ff               	callq	0x5bc0 <PyNumber_Add@plt>
   30785: 48 89 45 e0                  	movq	%rax, -0x20(%rbp)
   30789: 48 83 7d e0 00               	cmpq	$0x0, -0x20(%rbp)
   3078e: 0f 94 c0                     	sete	%al
   30791: 0f b6 c0                     	movzbl	%al, %eax
   30794: 48 85 c0                     	testq	%rax, %rax
   30797: 74 27                        	je	0x307c0 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x8de>
   30799: 48 8b 05 48 ed 21 00         	movq	0x21ed48(%rip), %rax    # 0x24f4e8 <__pyx_f>
   307a0: 48 89 05 a1 13 22 00         	movq	%rax, 0x2213a1(%rip)    # 0x251b48 <__pyx_filename>
   307a7: c7 05 8f 13 22 00 7d 01 00 00	movl	$0x17d, 0x22138f(%rip)  # imm = 0x17D
                                                                        # 0x251b40 <__pyx_lineno>
   307b1: c7 05 89 13 22 00 a6 27 00 00	movl	$0x27a6, 0x221389(%rip) # imm = 0x27A6
                                                                        # 0x251b44 <__pyx_clineno>
   307bb: e9 df 00 00 00               	jmp	0x3089f <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9bd>
   307c0: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   307c4: 48 8b 00                     	movq	(%rax), %rax
   307c7: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   307cb: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   307cf: 48 89 10                     	movq	%rdx, (%rax)
   307d2: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   307d6: 48 8b 00                     	movq	(%rax), %rax
   307d9: 48 85 c0                     	testq	%rax, %rax
   307dc: 75 15                        	jne	0x307f3 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x911>
   307de: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   307e2: 48 8b 40 08                  	movq	0x8(%rax), %rax
   307e6: 48 8b 40 30                  	movq	0x30(%rax), %rax
   307ea: 48 8b 55 e8                  	movq	-0x18(%rbp), %rdx
   307ee: 48 89 d7                     	movq	%rdx, %rdi
   307f1: ff d0                        	callq	*%rax
   307f3: 48 c7 45 e8 00 00 00 00      	movq	$0x0, -0x18(%rbp)
   307fb: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
   307ff: 48 89 45 f8                  	movq	%rax, -0x8(%rbp)
   30803: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   30807: 48 89 45 d0                  	movq	%rax, -0x30(%rbp)
   3080b: 48 8b 45 f8                  	movq	-0x8(%rbp), %rax
   3080f: 48 8b 00                     	movq	(%rax), %rax
   30812: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   30816: 48 8b 45 f8                  	movq	-0x8(%rbp), %rax
   3081a: 48 89 10                     	movq	%rdx, (%rax)
   3081d: 48 8b 45 f8                  	movq	-0x8(%rbp), %rax
   30821: 48 8b 00                     	movq	(%rax), %rax
   30824: 48 85 c0                     	testq	%rax, %rax
   30827: 75 15                        	jne	0x3083e <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x95c>
   30829: 48 8b 45 f8                  	movq	-0x8(%rbp), %rax
   3082d: 48 8b 40 08                  	movq	0x8(%rax), %rax
   30831: 48 8b 40 30                  	movq	0x30(%rax), %rax
   30835: 48 8b 55 f8                  	movq	-0x8(%rbp), %rdx
   30839: 48 89 d7                     	movq	%rdx, %rdi
   3083c: ff d0                        	callq	*%rax
   3083e: 48 c7 45 e0 00 00 00 00      	movq	$0x0, -0x20(%rbp)
   30846: 48 83 7d d8 00               	cmpq	$0x0, -0x28(%rbp)
   3084b: 74 33                        	je	0x30880 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x99e>
   3084d: 48 8b 45 d8                  	movq	-0x28(%rbp), %rax
   30851: 48 8b 00                     	movq	(%rax), %rax
   30854: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   30858: 48 8b 45 d8                  	movq	-0x28(%rbp), %rax
   3085c: 48 89 10                     	movq	%rdx, (%rax)
   3085f: 48 8b 45 d8                  	movq	-0x28(%rbp), %rax
   30863: 48 8b 00                     	movq	(%rax), %rax
   30866: 48 85 c0                     	testq	%rax, %rax
   30869: 75 15                        	jne	0x30880 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x99e>
   3086b: 48 8b 45 d8                  	movq	-0x28(%rbp), %rax
   3086f: 48 8b 40 08                  	movq	0x8(%rax), %rax
   30873: 48 8b 40 30                  	movq	0x30(%rax), %rax
   30877: 48 8b 55 d8                  	movq	-0x28(%rbp), %rdx
   3087b: 48 89 d7                     	movq	%rdx, %rdi
   3087e: ff d0                        	callq	*%rax
   30880: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
   30884: 48 8b 00                     	movq	(%rax), %rax
   30887: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   3088b: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
   3088f: 48 89 10                     	movq	%rdx, (%rax)
   30892: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
   30896: 48 89 45 d8                  	movq	%rax, -0x28(%rbp)
   3089a: e9 9d 00 00 00               	jmp	0x3093c <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0xa5a>
   3089f: 48 83 7d e0 00               	cmpq	$0x0, -0x20(%rbp)
   308a4: 74 33                        	je	0x308d9 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9f7>
   308a6: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   308aa: 48 8b 00                     	movq	(%rax), %rax
   308ad: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   308b1: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   308b5: 48 89 10                     	movq	%rdx, (%rax)
   308b8: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   308bc: 48 8b 00                     	movq	(%rax), %rax
   308bf: 48 85 c0                     	testq	%rax, %rax
   308c2: 75 15                        	jne	0x308d9 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0x9f7>
   308c4: 48 8b 45 e0                  	movq	-0x20(%rbp), %rax
   308c8: 48 8b 40 08                  	movq	0x8(%rax), %rax
   308cc: 48 8b 40 30                  	movq	0x30(%rax), %rax
   308d0: 48 8b 55 e0                  	movq	-0x20(%rbp), %rdx
   308d4: 48 89 d7                     	movq	%rdx, %rdi
   308d7: ff d0                        	callq	*%rax
   308d9: 48 83 7d e8 00               	cmpq	$0x0, -0x18(%rbp)
   308de: 74 33                        	je	0x30913 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0xa31>
   308e0: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   308e4: 48 8b 00                     	movq	(%rax), %rax
   308e7: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   308eb: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   308ef: 48 89 10                     	movq	%rdx, (%rax)
   308f2: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   308f6: 48 8b 00                     	movq	(%rax), %rax
   308f9: 48 85 c0                     	testq	%rax, %rax
   308fc: 75 15                        	jne	0x30913 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0xa31>
   308fe: 48 8b 45 e8                  	movq	-0x18(%rbp), %rax
   30902: 48 8b 40 08                  	movq	0x8(%rax), %rax
   30906: 48 8b 40 30                  	movq	0x30(%rax), %rax
   3090a: 48 8b 55 e8                  	movq	-0x18(%rbp), %rdx
   3090e: 48 89 d7                     	movq	%rdx, %rdi
   30911: ff d0                        	callq	*%rax
   30913: 48 8b 0d 2e 12 22 00         	movq	0x22122e(%rip), %rcx    # 0x251b48 <__pyx_filename>
   3091a: 8b 15 20 12 22 00            	movl	0x221220(%rip), %edx    # 0x251b40 <__pyx_lineno>
   30920: 8b 05 1e 12 22 00            	movl	0x22121e(%rip), %eax    # 0x251b44 <__pyx_clineno>
   30926: 89 c6                        	movl	%eax, %esi
   30928: 48 8d 3d 82 bc 01 00         	leaq	0x1bc82(%rip), %rdi     # 0x4c5b1 <__pyx_k_BaseEfuse___dict_string_parse+0x1d1>
   3092f: e8 9a a9 01 00               	callq	0x4b2ce <__Pyx_AddTraceback>
   30934: 48 c7 45 d8 00 00 00 00      	movq	$0x0, -0x28(%rbp)
   3093c: 48 83 7d b8 00               	cmpq	$0x0, -0x48(%rbp)
   30941: 74 33                        	je	0x30976 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0xa94>
   30943: 48 8b 45 b8                  	movq	-0x48(%rbp), %rax
   30947: 48 8b 00                     	movq	(%rax), %rax
   3094a: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   3094e: 48 8b 45 b8                  	movq	-0x48(%rbp), %rax
   30952: 48 89 10                     	movq	%rdx, (%rax)
   30955: 48 8b 45 b8                  	movq	-0x48(%rbp), %rax
   30959: 48 8b 00                     	movq	(%rax), %rax
   3095c: 48 85 c0                     	testq	%rax, %rax
   3095f: 75 15                        	jne	0x30976 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0xa94>
   30961: 48 8b 45 b8                  	movq	-0x48(%rbp), %rax
   30965: 48 8b 40 08                  	movq	0x8(%rax), %rax
   30969: 48 8b 40 30                  	movq	0x30(%rax), %rax
   3096d: 48 8b 55 b8                  	movq	-0x48(%rbp), %rdx
   30971: 48 89 d7                     	movq	%rdx, %rdi
   30974: ff d0                        	callq	*%rax
   30976: 48 83 7d c0 00               	cmpq	$0x0, -0x40(%rbp)
   3097b: 74 33                        	je	0x309b0 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0xace>
   3097d: 48 8b 45 c0                  	movq	-0x40(%rbp), %rax
   30981: 48 8b 00                     	movq	(%rax), %rax
   30984: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   30988: 48 8b 45 c0                  	movq	-0x40(%rbp), %rax
   3098c: 48 89 10                     	movq	%rdx, (%rax)
   3098f: 48 8b 45 c0                  	movq	-0x40(%rbp), %rax
   30993: 48 8b 00                     	movq	(%rax), %rax
   30996: 48 85 c0                     	testq	%rax, %rax
   30999: 75 15                        	jne	0x309b0 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0xace>
   3099b: 48 8b 45 c0                  	movq	-0x40(%rbp), %rax
   3099f: 48 8b 40 08                  	movq	0x8(%rax), %rax
   309a3: 48 8b 40 30                  	movq	0x30(%rax), %rax
   309a7: 48 8b 55 c0                  	movq	-0x40(%rbp), %rdx
   309ab: 48 89 d7                     	movq	%rdx, %rdi
   309ae: ff d0                        	callq	*%rax
   309b0: 48 83 7d c8 00               	cmpq	$0x0, -0x38(%rbp)
   309b5: 74 33                        	je	0x309ea <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0xb08>
   309b7: 48 8b 45 c8                  	movq	-0x38(%rbp), %rax
   309bb: 48 8b 00                     	movq	(%rax), %rax
   309be: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   309c2: 48 8b 45 c8                  	movq	-0x38(%rbp), %rax
   309c6: 48 89 10                     	movq	%rdx, (%rax)
   309c9: 48 8b 45 c8                  	movq	-0x38(%rbp), %rax
   309cd: 48 8b 00                     	movq	(%rax), %rax
   309d0: 48 85 c0                     	testq	%rax, %rax
   309d3: 75 15                        	jne	0x309ea <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0xb08>
   309d5: 48 8b 45 c8                  	movq	-0x38(%rbp), %rax
   309d9: 48 8b 40 08                  	movq	0x8(%rax), %rax
   309dd: 48 8b 40 30                  	movq	0x30(%rax), %rax
   309e1: 48 8b 55 c8                  	movq	-0x38(%rbp), %rdx
   309e5: 48 89 d7                     	movq	%rdx, %rdi
   309e8: ff d0                        	callq	*%rax
   309ea: 48 83 7d d0 00               	cmpq	$0x0, -0x30(%rbp)
   309ef: 74 33                        	je	0x30a24 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0xb42>
   309f1: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
   309f5: 48 8b 00                     	movq	(%rax), %rax
   309f8: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   309fc: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
   30a00: 48 89 10                     	movq	%rdx, (%rax)
   30a03: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
   30a07: 48 8b 00                     	movq	(%rax), %rax
   30a0a: 48 85 c0                     	testq	%rax, %rax
   30a0d: 75 15                        	jne	0x30a24 <__pyx_pf_5efuse_9BaseEfuse_16gen_seed32+0xb42>
   30a0f: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
   30a13: 48 8b 40 08                  	movq	0x8(%rax), %rax
   30a17: 48 8b 40 30                  	movq	0x30(%rax), %rax
   30a1b: 48 8b 55 d0                  	movq	-0x30(%rbp), %rdx
   30a1f: 48 89 d7                     	movq	%rdx, %rdi
   30a22: ff d0                        	callq	*%rax
   30a24: 48 8b 45 d8                  	movq	-0x28(%rbp), %rax
   30a28: c9                           	leave
   30a29: c3                           	retq

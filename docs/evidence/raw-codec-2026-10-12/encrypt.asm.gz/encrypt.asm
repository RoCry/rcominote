
/tmp/comi-encrypt-static/EFUSEX~1.SO~:	file format elf64-x86-64

Disassembly of section .text:

000000000003100f <__pyx_pf_5efuse_9BaseEfuse_18encrypt>:
   3100f: 55                           	pushq	%rbp
   31010: 48 89 e5                     	movq	%rsp, %rbp
   31013: 48 81 ec a0 01 00 00         	subq	$0x1a0, %rsp            # imm = 0x1A0
   3101a: 48 89 bd 98 fe ff ff         	movq	%rdi, -0x168(%rbp)
   31021: 48 89 b5 90 fe ff ff         	movq	%rsi, -0x170(%rbp)
   31028: 48 89 95 88 fe ff ff         	movq	%rdx, -0x178(%rbp)
   3102f: 48 89 8d 80 fe ff ff         	movq	%rcx, -0x180(%rbp)
   31036: 4c 89 85 78 fe ff ff         	movq	%r8, -0x188(%rbp)
   3103d: 4c 89 8d 70 fe ff ff         	movq	%r9, -0x190(%rbp)
   31044: 48 8b 45 10                  	movq	0x10(%rbp), %rax
   31048: 48 89 85 68 fe ff ff         	movq	%rax, -0x198(%rbp)
   3104f: 64 48 8b 04 25 28 00 00 00   	movq	%fs:0x28, %rax
   31058: 48 89 45 f8                  	movq	%rax, -0x8(%rbp)
   3105c: 31 c0                        	xorl	%eax, %eax
   3105e: 48 c7 85 b0 fe ff ff 00 00 00 00     	movq	$0x0, -0x150(%rbp)
   31069: 48 c7 85 b8 fe ff ff 00 00 00 00     	movq	$0x0, -0x148(%rbp)
   31074: 48 c7 85 c0 fe ff ff 00 00 00 00     	movq	$0x0, -0x140(%rbp)
   3107f: 48 c7 85 c8 fe ff ff 00 00 00 00     	movq	$0x0, -0x138(%rbp)
   3108a: 48 c7 85 d0 fe ff ff 00 00 00 00     	movq	$0x0, -0x130(%rbp)
   31095: 48 c7 85 d8 fe ff ff 00 00 00 00     	movq	$0x0, -0x128(%rbp)
   310a0: 48 c7 85 e0 fe ff ff 00 00 00 00     	movq	$0x0, -0x120(%rbp)
   310ab: 48 c7 85 e8 fe ff ff 00 00 00 00     	movq	$0x0, -0x118(%rbp)
   310b6: 48 c7 85 f0 fe ff ff 00 00 00 00     	movq	$0x0, -0x110(%rbp)
   310c1: 48 c7 85 f8 fe ff ff 00 00 00 00     	movq	$0x0, -0x108(%rbp)
   310cc: 48 c7 85 00 ff ff ff 00 00 00 00     	movq	$0x0, -0x100(%rbp)
   310d7: 48 c7 85 08 ff ff ff 00 00 00 00     	movq	$0x0, -0xf8(%rbp)
   310e2: 48 c7 85 18 ff ff ff 00 00 00 00     	movq	$0x0, -0xe8(%rbp)
   310ed: 48 c7 85 38 ff ff ff 00 00 00 00     	movq	$0x0, -0xc8(%rbp)
   310f8: 48 c7 85 40 ff ff ff 00 00 00 00     	movq	$0x0, -0xc0(%rbp)
   31103: 48 8b 85 68 fe ff ff         	movq	-0x198(%rbp), %rax
   3110a: 48 8b 00                     	movq	(%rax), %rax
   3110d: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   31111: 48 8b 85 68 fe ff ff         	movq	-0x198(%rbp), %rax
   31118: 48 89 10                     	movq	%rdx, (%rax)
   3111b: 48 8b 05 d6 0f 22 00         	movq	0x220fd6(%rip), %rax    # 0x2520f8 <__pyx_n_s_time>
   31122: 48 89 c7                     	movq	%rax, %rdi
   31125: e8 72 4e 01 00               	callq	0x45f9c <__Pyx_GetModuleGlobalName>
   3112a: 48 89 85 00 ff ff ff         	movq	%rax, -0x100(%rbp)
   31131: 48 83 bd 00 ff ff ff 00      	cmpq	$0x0, -0x100(%rbp)
   31139: 0f 94 c0                     	sete	%al
   3113c: 0f b6 c0                     	movzbl	%al, %eax
   3113f: 48 85 c0                     	testq	%rax, %rax
   31142: 74 27                        	je	0x3116b <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x15c>
   31144: 48 8b 05 9d e3 21 00         	movq	0x21e39d(%rip), %rax    # 0x24f4e8 <__pyx_f>
   3114b: 48 89 05 f6 09 22 00         	movq	%rax, 0x2209f6(%rip)    # 0x251b48 <__pyx_filename>
   31152: c7 05 e4 09 22 00 86 01 00 00	movl	$0x186, 0x2209e4(%rip)  # imm = 0x186
                                                                        # 0x251b40 <__pyx_lineno>
   3115c: c7 05 de 09 22 00 6b 28 00 00	movl	$0x286b, 0x2209de(%rip) # imm = 0x286B
                                                                        # 0x251b44 <__pyx_clineno>
   31166: e9 4e 25 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   3116b: 48 8b 15 16 0c 22 00         	movq	0x220c16(%rip), %rdx    # 0x251d88 <__pyx_n_s_clock>
   31172: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   31179: 48 89 d6                     	movq	%rdx, %rsi
   3117c: 48 89 c7                     	movq	%rax, %rdi
   3117f: e8 46 4b fd ff               	callq	0x5cca <__Pyx_PyObject_GetAttrStr>
   31184: 48 89 85 08 ff ff ff         	movq	%rax, -0xf8(%rbp)
   3118b: 48 83 bd 08 ff ff ff 00      	cmpq	$0x0, -0xf8(%rbp)
   31193: 0f 94 c0                     	sete	%al
   31196: 0f b6 c0                     	movzbl	%al, %eax
   31199: 48 85 c0                     	testq	%rax, %rax
   3119c: 74 27                        	je	0x311c5 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1b6>
   3119e: 48 8b 05 43 e3 21 00         	movq	0x21e343(%rip), %rax    # 0x24f4e8 <__pyx_f>
   311a5: 48 89 05 9c 09 22 00         	movq	%rax, 0x22099c(%rip)    # 0x251b48 <__pyx_filename>
   311ac: c7 05 8a 09 22 00 86 01 00 00	movl	$0x186, 0x22098a(%rip)  # imm = 0x186
                                                                        # 0x251b40 <__pyx_lineno>
   311b6: c7 05 84 09 22 00 6d 28 00 00	movl	$0x286d, 0x220984(%rip) # imm = 0x286D
                                                                        # 0x251b44 <__pyx_clineno>
   311c0: e9 f4 24 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   311c5: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   311cc: 48 8b 00                     	movq	(%rax), %rax
   311cf: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   311d3: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   311da: 48 89 10                     	movq	%rdx, (%rax)
   311dd: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   311e4: 48 8b 00                     	movq	(%rax), %rax
   311e7: 48 85 c0                     	testq	%rax, %rax
   311ea: 75 1b                        	jne	0x31207 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1f8>
   311ec: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   311f3: 48 8b 40 08                  	movq	0x8(%rax), %rax
   311f7: 48 8b 40 30                  	movq	0x30(%rax), %rax
   311fb: 48 8b 95 00 ff ff ff         	movq	-0x100(%rbp), %rdx
   31202: 48 89 d7                     	movq	%rdx, %rdi
   31205: ff d0                        	callq	*%rax
   31207: 48 c7 85 00 ff ff ff 00 00 00 00     	movq	$0x0, -0x100(%rbp)
   31212: 48 c7 85 00 ff ff ff 00 00 00 00     	movq	$0x0, -0x100(%rbp)
   3121d: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31224: 48 8b 40 08                  	movq	0x8(%rax), %rax
   31228: 48 8b 15 81 dc 21 00         	movq	0x21dc81(%rip), %rdx    # 0x24eeb0 <memcmp@@GLIBC_2.2.5+0x24eeb0>
   3122f: 48 39 d0                     	cmpq	%rdx, %rax
   31232: 0f 94 c0                     	sete	%al
   31235: 0f b6 c0                     	movzbl	%al, %eax
   31238: 48 85 c0                     	testq	%rax, %rax
   3123b: 0f 84 c9 00 00 00            	je	0x3130a <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2fb>
   31241: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31248: 48 8b 40 18                  	movq	0x18(%rax), %rax
   3124c: 48 89 85 00 ff ff ff         	movq	%rax, -0x100(%rbp)
   31253: 48 83 bd 00 ff ff ff 00      	cmpq	$0x0, -0x100(%rbp)
   3125b: 0f 95 c0                     	setne	%al
   3125e: 0f b6 c0                     	movzbl	%al, %eax
   31261: 48 85 c0                     	testq	%rax, %rax
   31264: 0f 84 a0 00 00 00            	je	0x3130a <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2fb>
   3126a: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31271: 48 8b 40 10                  	movq	0x10(%rax), %rax
   31275: 48 89 85 48 ff ff ff         	movq	%rax, -0xb8(%rbp)
   3127c: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   31283: 48 8b 00                     	movq	(%rax), %rax
   31286: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   3128a: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   31291: 48 89 10                     	movq	%rdx, (%rax)
   31294: 48 8b 85 48 ff ff ff         	movq	-0xb8(%rbp), %rax
   3129b: 48 8b 00                     	movq	(%rax), %rax
   3129e: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   312a2: 48 8b 85 48 ff ff ff         	movq	-0xb8(%rbp), %rax
   312a9: 48 89 10                     	movq	%rdx, (%rax)
   312ac: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   312b3: 48 89 85 50 ff ff ff         	movq	%rax, -0xb0(%rbp)
   312ba: 48 8b 85 48 ff ff ff         	movq	-0xb8(%rbp), %rax
   312c1: 48 89 85 08 ff ff ff         	movq	%rax, -0xf8(%rbp)
   312c8: 48 8b 85 50 ff ff ff         	movq	-0xb0(%rbp), %rax
   312cf: 48 8b 00                     	movq	(%rax), %rax
   312d2: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   312d6: 48 8b 85 50 ff ff ff         	movq	-0xb0(%rbp), %rax
   312dd: 48 89 10                     	movq	%rdx, (%rax)
   312e0: 48 8b 85 50 ff ff ff         	movq	-0xb0(%rbp), %rax
   312e7: 48 8b 00                     	movq	(%rax), %rax
   312ea: 48 85 c0                     	testq	%rax, %rax
   312ed: 75 1b                        	jne	0x3130a <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2fb>
   312ef: 48 8b 85 50 ff ff ff         	movq	-0xb0(%rbp), %rax
   312f6: 48 8b 40 08                  	movq	0x8(%rax), %rax
   312fa: 48 8b 40 30                  	movq	0x30(%rax), %rax
   312fe: 48 8b 95 50 ff ff ff         	movq	-0xb0(%rbp), %rdx
   31305: 48 89 d7                     	movq	%rdx, %rdi
   31308: ff d0                        	callq	*%rax
   3130a: 48 83 bd 00 ff ff ff 00      	cmpq	$0x0, -0x100(%rbp)
   31312: 0f 84 a9 00 00 00            	je	0x313c1 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x3b2>
   31318: 48 8b 95 00 ff ff ff         	movq	-0x100(%rbp), %rdx
   3131f: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31326: 48 89 d6                     	movq	%rdx, %rsi
   31329: 48 89 c7                     	movq	%rax, %rdi
   3132c: e8 8f 54 01 00               	callq	0x467c0 <__Pyx_PyObject_CallOneArg>
   31331: 48 89 85 f8 fe ff ff         	movq	%rax, -0x108(%rbp)
   31338: 48 83 bd f8 fe ff ff 00      	cmpq	$0x0, -0x108(%rbp)
   31340: 0f 94 c0                     	sete	%al
   31343: 0f b6 c0                     	movzbl	%al, %eax
   31346: 48 85 c0                     	testq	%rax, %rax
   31349: 74 27                        	je	0x31372 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x363>
   3134b: 48 8b 05 96 e1 21 00         	movq	0x21e196(%rip), %rax    # 0x24f4e8 <__pyx_f>
   31352: 48 89 05 ef 07 22 00         	movq	%rax, 0x2207ef(%rip)    # 0x251b48 <__pyx_filename>
   31359: c7 05 dd 07 22 00 86 01 00 00	movl	$0x186, 0x2207dd(%rip)  # imm = 0x186
                                                                        # 0x251b40 <__pyx_lineno>
   31363: c7 05 d7 07 22 00 7b 28 00 00	movl	$0x287b, 0x2207d7(%rip) # imm = 0x287B
                                                                        # 0x251b44 <__pyx_clineno>
   3136d: e9 47 23 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   31372: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   31379: 48 8b 00                     	movq	(%rax), %rax
   3137c: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   31380: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   31387: 48 89 10                     	movq	%rdx, (%rax)
   3138a: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   31391: 48 8b 00                     	movq	(%rax), %rax
   31394: 48 85 c0                     	testq	%rax, %rax
   31397: 75 1b                        	jne	0x313b4 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x3a5>
   31399: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   313a0: 48 8b 40 08                  	movq	0x8(%rax), %rax
   313a4: 48 8b 40 30                  	movq	0x30(%rax), %rax
   313a8: 48 8b 95 00 ff ff ff         	movq	-0x100(%rbp), %rdx
   313af: 48 89 d7                     	movq	%rdx, %rdi
   313b2: ff d0                        	callq	*%rax
   313b4: 48 c7 85 00 ff ff ff 00 00 00 00     	movq	$0x0, -0x100(%rbp)
   313bf: eb 50                        	jmp	0x31411 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x402>
   313c1: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   313c8: 48 89 c7                     	movq	%rax, %rdi
   313cb: e8 92 54 01 00               	callq	0x46862 <__Pyx_PyObject_CallNoArg>
   313d0: 48 89 85 f8 fe ff ff         	movq	%rax, -0x108(%rbp)
   313d7: 48 83 bd f8 fe ff ff 00      	cmpq	$0x0, -0x108(%rbp)
   313df: 0f 94 c0                     	sete	%al
   313e2: 0f b6 c0                     	movzbl	%al, %eax
   313e5: 48 85 c0                     	testq	%rax, %rax
   313e8: 74 27                        	je	0x31411 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x402>
   313ea: 48 8b 05 f7 e0 21 00         	movq	0x21e0f7(%rip), %rax    # 0x24f4e8 <__pyx_f>
   313f1: 48 89 05 50 07 22 00         	movq	%rax, 0x220750(%rip)    # 0x251b48 <__pyx_filename>
   313f8: c7 05 3e 07 22 00 86 01 00 00	movl	$0x186, 0x22073e(%rip)  # imm = 0x186
                                                                        # 0x251b40 <__pyx_lineno>
   31402: c7 05 38 07 22 00 7e 28 00 00	movl	$0x287e, 0x220738(%rip) # imm = 0x287E
                                                                        # 0x251b44 <__pyx_clineno>
   3140c: e9 a8 22 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   31411: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31418: 48 8b 00                     	movq	(%rax), %rax
   3141b: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   3141f: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31426: 48 89 10                     	movq	%rdx, (%rax)
   31429: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31430: 48 8b 00                     	movq	(%rax), %rax
   31433: 48 85 c0                     	testq	%rax, %rax
   31436: 75 1b                        	jne	0x31453 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x444>
   31438: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   3143f: 48 8b 40 08                  	movq	0x8(%rax), %rax
   31443: 48 8b 40 30                  	movq	0x30(%rax), %rax
   31447: 48 8b 95 08 ff ff ff         	movq	-0xf8(%rbp), %rdx
   3144e: 48 89 d7                     	movq	%rdx, %rdi
   31451: ff d0                        	callq	*%rax
   31453: 48 c7 85 08 ff ff ff 00 00 00 00     	movq	$0x0, -0xf8(%rbp)
   3145e: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   31465: 48 89 85 b0 fe ff ff         	movq	%rax, -0x150(%rbp)
   3146c: 48 c7 85 f8 fe ff ff 00 00 00 00     	movq	$0x0, -0x108(%rbp)
   31477: 48 8b 05 da da 21 00         	movq	0x21dada(%rip), %rax    # 0x24ef58 <memcmp@@GLIBC_2.2.5+0x24ef58>
   3147e: 48 39 85 68 fe ff ff         	cmpq	%rax, -0x198(%rbp)
   31485: 0f 94 c0                     	sete	%al
   31488: 0f b6 c0                     	movzbl	%al, %eax
   3148b: 89 85 a8 fe ff ff            	movl	%eax, -0x158(%rbp)
   31491: 83 bd a8 fe ff ff 00         	cmpl	$0x0, -0x158(%rbp)
   31498: 0f 95 c0                     	setne	%al
   3149b: 0f b6 c0                     	movzbl	%al, %eax
   3149e: 89 85 ac fe ff ff            	movl	%eax, -0x154(%rbp)
   314a4: 83 bd ac fe ff ff 00         	cmpl	$0x0, -0x154(%rbp)
   314ab: 0f 84 b0 01 00 00            	je	0x31661 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x652>
   314b1: 48 8b 85 88 fe ff ff         	movq	-0x178(%rbp), %rax
   314b8: 48 89 c7                     	movq	%rax, %rdi
   314bb: e8 30 45 fd ff               	callq	0x59f0 <PyObject_Size@plt>
   314c0: 48 89 85 10 ff ff ff         	movq	%rax, -0xf0(%rbp)
   314c7: 48 83 bd 10 ff ff ff ff      	cmpq	$-0x1, -0xf0(%rbp)
   314cf: 0f 94 c0                     	sete	%al
   314d2: 0f b6 c0                     	movzbl	%al, %eax
   314d5: 48 85 c0                     	testq	%rax, %rax
   314d8: 74 27                        	je	0x31501 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x4f2>
   314da: 48 8b 05 07 e0 21 00         	movq	0x21e007(%rip), %rax    # 0x24f4e8 <__pyx_f>
   314e1: 48 89 05 60 06 22 00         	movq	%rax, 0x220660(%rip)    # 0x251b48 <__pyx_filename>
   314e8: c7 05 4e 06 22 00 8a 01 00 00	movl	$0x18a, 0x22064e(%rip)  # imm = 0x18A
                                                                        # 0x251b40 <__pyx_lineno>
   314f2: c7 05 48 06 22 00 97 28 00 00	movl	$0x2897, 0x220648(%rip) # imm = 0x2897
                                                                        # 0x251b44 <__pyx_clineno>
   314fc: e9 b8 21 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   31501: 48 8b 85 10 ff ff ff         	movq	-0xf0(%rbp), %rax
   31508: 48 89 c7                     	movq	%rax, %rdi
   3150b: e8 d0 42 fd ff               	callq	0x57e0 <PyInt_FromSsize_t@plt>
   31510: 48 89 85 f8 fe ff ff         	movq	%rax, -0x108(%rbp)
   31517: 48 83 bd f8 fe ff ff 00      	cmpq	$0x0, -0x108(%rbp)
   3151f: 0f 94 c0                     	sete	%al
   31522: 0f b6 c0                     	movzbl	%al, %eax
   31525: 48 85 c0                     	testq	%rax, %rax
   31528: 74 27                        	je	0x31551 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x542>
   3152a: 48 8b 05 b7 df 21 00         	movq	0x21dfb7(%rip), %rax    # 0x24f4e8 <__pyx_f>
   31531: 48 89 05 10 06 22 00         	movq	%rax, 0x220610(%rip)    # 0x251b48 <__pyx_filename>
   31538: c7 05 fe 05 22 00 8a 01 00 00	movl	$0x18a, 0x2205fe(%rip)  # imm = 0x18A
                                                                        # 0x251b40 <__pyx_lineno>
   31542: c7 05 f8 05 22 00 98 28 00 00	movl	$0x2898, 0x2205f8(%rip) # imm = 0x2898
                                                                        # 0x251b44 <__pyx_clineno>
   3154c: e9 68 21 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   31551: 48 8b 95 70 fe ff ff         	movq	-0x190(%rbp), %rdx
   31558: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   3155f: 48 89 d6                     	movq	%rdx, %rsi
   31562: 48 89 c7                     	movq	%rax, %rdi
   31565: e8 76 46 fd ff               	callq	0x5be0 <PyNumber_Subtract@plt>
   3156a: 48 89 85 08 ff ff ff         	movq	%rax, -0xf8(%rbp)
   31571: 48 83 bd 08 ff ff ff 00      	cmpq	$0x0, -0xf8(%rbp)
   31579: 0f 94 c0                     	sete	%al
   3157c: 0f b6 c0                     	movzbl	%al, %eax
   3157f: 48 85 c0                     	testq	%rax, %rax
   31582: 74 27                        	je	0x315ab <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x59c>
   31584: 48 8b 05 5d df 21 00         	movq	0x21df5d(%rip), %rax    # 0x24f4e8 <__pyx_f>
   3158b: 48 89 05 b6 05 22 00         	movq	%rax, 0x2205b6(%rip)    # 0x251b48 <__pyx_filename>
   31592: c7 05 a4 05 22 00 8a 01 00 00	movl	$0x18a, 0x2205a4(%rip)  # imm = 0x18A
                                                                        # 0x251b40 <__pyx_lineno>
   3159c: c7 05 9e 05 22 00 9a 28 00 00	movl	$0x289a, 0x22059e(%rip) # imm = 0x289A
                                                                        # 0x251b44 <__pyx_clineno>
   315a6: e9 0e 21 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   315ab: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   315b2: 48 8b 00                     	movq	(%rax), %rax
   315b5: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   315b9: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   315c0: 48 89 10                     	movq	%rdx, (%rax)
   315c3: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   315ca: 48 8b 00                     	movq	(%rax), %rax
   315cd: 48 85 c0                     	testq	%rax, %rax
   315d0: 75 1b                        	jne	0x315ed <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x5de>
   315d2: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   315d9: 48 8b 40 08                  	movq	0x8(%rax), %rax
   315dd: 48 8b 40 30                  	movq	0x30(%rax), %rax
   315e1: 48 8b 95 f8 fe ff ff         	movq	-0x108(%rbp), %rdx
   315e8: 48 89 d7                     	movq	%rdx, %rdi
   315eb: ff d0                        	callq	*%rax
   315ed: 48 c7 85 f8 fe ff ff 00 00 00 00     	movq	$0x0, -0x108(%rbp)
   315f8: 48 8b 85 68 fe ff ff         	movq	-0x198(%rbp), %rax
   315ff: 48 89 85 58 ff ff ff         	movq	%rax, -0xa8(%rbp)
   31606: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   3160d: 48 89 85 68 fe ff ff         	movq	%rax, -0x198(%rbp)
   31614: 48 8b 85 58 ff ff ff         	movq	-0xa8(%rbp), %rax
   3161b: 48 8b 00                     	movq	(%rax), %rax
   3161e: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   31622: 48 8b 85 58 ff ff ff         	movq	-0xa8(%rbp), %rax
   31629: 48 89 10                     	movq	%rdx, (%rax)
   3162c: 48 8b 85 58 ff ff ff         	movq	-0xa8(%rbp), %rax
   31633: 48 8b 00                     	movq	(%rax), %rax
   31636: 48 85 c0                     	testq	%rax, %rax
   31639: 75 1b                        	jne	0x31656 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x647>
   3163b: 48 8b 85 58 ff ff ff         	movq	-0xa8(%rbp), %rax
   31642: 48 8b 40 08                  	movq	0x8(%rax), %rax
   31646: 48 8b 40 30                  	movq	0x30(%rax), %rax
   3164a: 48 8b 95 58 ff ff ff         	movq	-0xa8(%rbp), %rdx
   31651: 48 89 d7                     	movq	%rdx, %rdi
   31654: ff d0                        	callq	*%rax
   31656: 48 c7 85 08 ff ff ff 00 00 00 00     	movq	$0x0, -0xf8(%rbp)
   31661: 48 8b 15 70 08 22 00         	movq	0x220870(%rip), %rdx    # 0x251ed8 <__pyx_n_s_gen_seed8>
   31668: 48 8b 85 90 fe ff ff         	movq	-0x170(%rbp), %rax
   3166f: 48 89 d6                     	movq	%rdx, %rsi
   31672: 48 89 c7                     	movq	%rax, %rdi
   31675: e8 50 46 fd ff               	callq	0x5cca <__Pyx_PyObject_GetAttrStr>
   3167a: 48 89 85 f8 fe ff ff         	movq	%rax, -0x108(%rbp)
   31681: 48 83 bd f8 fe ff ff 00      	cmpq	$0x0, -0x108(%rbp)
   31689: 0f 94 c0                     	sete	%al
   3168c: 0f b6 c0                     	movzbl	%al, %eax
   3168f: 48 85 c0                     	testq	%rax, %rax
   31692: 74 27                        	je	0x316bb <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x6ac>
   31694: 48 8b 05 4d de 21 00         	movq	0x21de4d(%rip), %rax    # 0x24f4e8 <__pyx_f>
   3169b: 48 89 05 a6 04 22 00         	movq	%rax, 0x2204a6(%rip)    # 0x251b48 <__pyx_filename>
   316a2: c7 05 94 04 22 00 92 01 00 00	movl	$0x192, 0x220494(%rip)  # imm = 0x192
                                                                        # 0x251b40 <__pyx_lineno>
   316ac: c7 05 8e 04 22 00 b0 28 00 00	movl	$0x28b0, 0x22048e(%rip) # imm = 0x28B0
                                                                        # 0x251b44 <__pyx_clineno>
   316b6: e9 fe 1f 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   316bb: 48 c7 85 00 ff ff ff 00 00 00 00     	movq	$0x0, -0x100(%rbp)
   316c6: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   316cd: 48 8b 40 08                  	movq	0x8(%rax), %rax
   316d1: 48 8b 15 d8 d7 21 00         	movq	0x21d7d8(%rip), %rdx    # 0x24eeb0 <memcmp@@GLIBC_2.2.5+0x24eeb0>
   316d8: 48 39 d0                     	cmpq	%rdx, %rax
   316db: 0f 94 c0                     	sete	%al
   316de: 0f b6 c0                     	movzbl	%al, %eax
   316e1: 48 85 c0                     	testq	%rax, %rax
   316e4: 0f 84 c9 00 00 00            	je	0x317b3 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x7a4>
   316ea: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   316f1: 48 8b 40 18                  	movq	0x18(%rax), %rax
   316f5: 48 89 85 00 ff ff ff         	movq	%rax, -0x100(%rbp)
   316fc: 48 83 bd 00 ff ff ff 00      	cmpq	$0x0, -0x100(%rbp)
   31704: 0f 95 c0                     	setne	%al
   31707: 0f b6 c0                     	movzbl	%al, %eax
   3170a: 48 85 c0                     	testq	%rax, %rax
   3170d: 0f 84 a0 00 00 00            	je	0x317b3 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x7a4>
   31713: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   3171a: 48 8b 40 10                  	movq	0x10(%rax), %rax
   3171e: 48 89 85 60 ff ff ff         	movq	%rax, -0xa0(%rbp)
   31725: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   3172c: 48 8b 00                     	movq	(%rax), %rax
   3172f: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   31733: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   3173a: 48 89 10                     	movq	%rdx, (%rax)
   3173d: 48 8b 85 60 ff ff ff         	movq	-0xa0(%rbp), %rax
   31744: 48 8b 00                     	movq	(%rax), %rax
   31747: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   3174b: 48 8b 85 60 ff ff ff         	movq	-0xa0(%rbp), %rax
   31752: 48 89 10                     	movq	%rdx, (%rax)
   31755: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   3175c: 48 89 85 68 ff ff ff         	movq	%rax, -0x98(%rbp)
   31763: 48 8b 85 60 ff ff ff         	movq	-0xa0(%rbp), %rax
   3176a: 48 89 85 f8 fe ff ff         	movq	%rax, -0x108(%rbp)
   31771: 48 8b 85 68 ff ff ff         	movq	-0x98(%rbp), %rax
   31778: 48 8b 00                     	movq	(%rax), %rax
   3177b: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   3177f: 48 8b 85 68 ff ff ff         	movq	-0x98(%rbp), %rax
   31786: 48 89 10                     	movq	%rdx, (%rax)
   31789: 48 8b 85 68 ff ff ff         	movq	-0x98(%rbp), %rax
   31790: 48 8b 00                     	movq	(%rax), %rax
   31793: 48 85 c0                     	testq	%rax, %rax
   31796: 75 1b                        	jne	0x317b3 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x7a4>
   31798: 48 8b 85 68 ff ff ff         	movq	-0x98(%rbp), %rax
   3179f: 48 8b 40 08                  	movq	0x8(%rax), %rax
   317a3: 48 8b 40 30                  	movq	0x30(%rax), %rax
   317a7: 48 8b 95 68 ff ff ff         	movq	-0x98(%rbp), %rdx
   317ae: 48 89 d7                     	movq	%rdx, %rdi
   317b1: ff d0                        	callq	*%rax
   317b3: 48 83 bd 00 ff ff ff 00      	cmpq	$0x0, -0x100(%rbp)
   317bb: 75 5e                        	jne	0x3181b <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x80c>
   317bd: 48 8b 95 80 fe ff ff         	movq	-0x180(%rbp), %rdx
   317c4: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   317cb: 48 89 d6                     	movq	%rdx, %rsi
   317ce: 48 89 c7                     	movq	%rax, %rdi
   317d1: e8 ea 4f 01 00               	callq	0x467c0 <__Pyx_PyObject_CallOneArg>
   317d6: 48 89 85 08 ff ff ff         	movq	%rax, -0xf8(%rbp)
   317dd: 48 83 bd 08 ff ff ff 00      	cmpq	$0x0, -0xf8(%rbp)
   317e5: 0f 94 c0                     	sete	%al
   317e8: 0f b6 c0                     	movzbl	%al, %eax
   317eb: 48 85 c0                     	testq	%rax, %rax
   317ee: 0f 84 50 02 00 00            	je	0x31a44 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0xa35>
   317f4: 48 8b 05 ed dc 21 00         	movq	0x21dced(%rip), %rax    # 0x24f4e8 <__pyx_f>
   317fb: 48 89 05 46 03 22 00         	movq	%rax, 0x220346(%rip)    # 0x251b48 <__pyx_filename>
   31802: c7 05 34 03 22 00 92 01 00 00	movl	$0x192, 0x220334(%rip)  # imm = 0x192
                                                                        # 0x251b40 <__pyx_lineno>
   3180c: c7 05 2e 03 22 00 bd 28 00 00	movl	$0x28bd, 0x22032e(%rip) # imm = 0x28BD
                                                                        # 0x251b44 <__pyx_clineno>
   31816: e9 9e 1e 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   3181b: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   31822: 48 8b 40 08                  	movq	0x8(%rax), %rax
   31826: 48 8b 15 43 d7 21 00         	movq	0x21d743(%rip), %rdx    # 0x24ef70 <memcmp@@GLIBC_2.2.5+0x24ef70>
   3182d: 48 39 d0                     	cmpq	%rdx, %rax
   31830: 0f 85 d0 00 00 00            	jne	0x31906 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x8f7>
   31836: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   3183d: 48 89 45 e0                  	movq	%rax, -0x20(%rbp)
   31841: 48 8b 85 80 fe ff ff         	movq	-0x180(%rbp), %rax
   31848: 48 89 45 e8                  	movq	%rax, -0x18(%rbp)
   3184c: 48 8d 75 e0                  	leaq	-0x20(%rbp), %rsi
   31850: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   31857: b9 00 00 00 00               	movl	$0x0, %ecx
   3185c: ba 02 00 00 00               	movl	$0x2, %edx
   31861: 48 89 c7                     	movq	%rax, %rdi
   31864: e8 00 49 01 00               	callq	0x46169 <__Pyx_PyFunction_FastCallDict>
   31869: 48 89 85 08 ff ff ff         	movq	%rax, -0xf8(%rbp)
   31870: 48 83 bd 08 ff ff ff 00      	cmpq	$0x0, -0xf8(%rbp)
   31878: 0f 94 c0                     	sete	%al
   3187b: 0f b6 c0                     	movzbl	%al, %eax
   3187e: 48 85 c0                     	testq	%rax, %rax
   31881: 74 27                        	je	0x318aa <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x89b>
   31883: 48 8b 05 5e dc 21 00         	movq	0x21dc5e(%rip), %rax    # 0x24f4e8 <__pyx_f>
   3188a: 48 89 05 b7 02 22 00         	movq	%rax, 0x2202b7(%rip)    # 0x251b48 <__pyx_filename>
   31891: c7 05 a5 02 22 00 92 01 00 00	movl	$0x192, 0x2202a5(%rip)  # imm = 0x192
                                                                        # 0x251b40 <__pyx_lineno>
   3189b: c7 05 9f 02 22 00 c3 28 00 00	movl	$0x28c3, 0x22029f(%rip) # imm = 0x28C3
                                                                        # 0x251b44 <__pyx_clineno>
   318a5: e9 0f 1e 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   318aa: 48 83 bd 00 ff ff ff 00      	cmpq	$0x0, -0x100(%rbp)
   318b2: 74 42                        	je	0x318f6 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x8e7>
   318b4: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   318bb: 48 8b 00                     	movq	(%rax), %rax
   318be: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   318c2: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   318c9: 48 89 10                     	movq	%rdx, (%rax)
   318cc: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   318d3: 48 8b 00                     	movq	(%rax), %rax
   318d6: 48 85 c0                     	testq	%rax, %rax
   318d9: 75 1b                        	jne	0x318f6 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x8e7>
   318db: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   318e2: 48 8b 40 08                  	movq	0x8(%rax), %rax
   318e6: 48 8b 40 30                  	movq	0x30(%rax), %rax
   318ea: 48 8b 95 00 ff ff ff         	movq	-0x100(%rbp), %rdx
   318f1: 48 89 d7                     	movq	%rdx, %rdi
   318f4: ff d0                        	callq	*%rax
   318f6: 48 c7 85 00 ff ff ff 00 00 00 00     	movq	$0x0, -0x100(%rbp)
   31901: e9 3e 01 00 00               	jmp	0x31a44 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0xa35>
   31906: bf 02 00 00 00               	movl	$0x2, %edi
   3190b: e8 40 40 fd ff               	callq	0x5950 <PyTuple_New@plt>
   31910: 48 89 85 18 ff ff ff         	movq	%rax, -0xe8(%rbp)
   31917: 48 83 bd 18 ff ff ff 00      	cmpq	$0x0, -0xe8(%rbp)
   3191f: 0f 94 c0                     	sete	%al
   31922: 0f b6 c0                     	movzbl	%al, %eax
   31925: 48 85 c0                     	testq	%rax, %rax
   31928: 74 27                        	je	0x31951 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x942>
   3192a: 48 8b 05 b7 db 21 00         	movq	0x21dbb7(%rip), %rax    # 0x24f4e8 <__pyx_f>
   31931: 48 89 05 10 02 22 00         	movq	%rax, 0x220210(%rip)    # 0x251b48 <__pyx_filename>
   31938: c7 05 fe 01 22 00 92 01 00 00	movl	$0x192, 0x2201fe(%rip)  # imm = 0x192
                                                                        # 0x251b40 <__pyx_lineno>
   31942: c7 05 f8 01 22 00 d1 28 00 00	movl	$0x28d1, 0x2201f8(%rip) # imm = 0x28D1
                                                                        # 0x251b44 <__pyx_clineno>
   3194c: e9 68 1d 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   31951: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   31958: 48 8b 95 00 ff ff ff         	movq	-0x100(%rbp), %rdx
   3195f: 48 89 50 18                  	movq	%rdx, 0x18(%rax)
   31963: 48 c7 85 00 ff ff ff 00 00 00 00     	movq	$0x0, -0x100(%rbp)
   3196e: 48 8b 85 80 fe ff ff         	movq	-0x180(%rbp), %rax
   31975: 48 8b 00                     	movq	(%rax), %rax
   31978: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   3197c: 48 8b 85 80 fe ff ff         	movq	-0x180(%rbp), %rax
   31983: 48 89 10                     	movq	%rdx, (%rax)
   31986: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   3198d: 48 8b 95 80 fe ff ff         	movq	-0x180(%rbp), %rdx
   31994: 48 89 50 20                  	movq	%rdx, 0x20(%rax)
   31998: 48 8b 8d 18 ff ff ff         	movq	-0xe8(%rbp), %rcx
   3199f: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   319a6: ba 00 00 00 00               	movl	$0x0, %edx
   319ab: 48 89 ce                     	movq	%rcx, %rsi
   319ae: 48 89 c7                     	movq	%rax, %rdi
   319b1: e8 70 4b 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   319b6: 48 89 85 08 ff ff ff         	movq	%rax, -0xf8(%rbp)
   319bd: 48 83 bd 08 ff ff ff 00      	cmpq	$0x0, -0xf8(%rbp)
   319c5: 0f 94 c0                     	sete	%al
   319c8: 0f b6 c0                     	movzbl	%al, %eax
   319cb: 48 85 c0                     	testq	%rax, %rax
   319ce: 74 27                        	je	0x319f7 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x9e8>
   319d0: 48 8b 05 11 db 21 00         	movq	0x21db11(%rip), %rax    # 0x24f4e8 <__pyx_f>
   319d7: 48 89 05 6a 01 22 00         	movq	%rax, 0x22016a(%rip)    # 0x251b48 <__pyx_filename>
   319de: c7 05 58 01 22 00 92 01 00 00	movl	$0x192, 0x220158(%rip)  # imm = 0x192
                                                                        # 0x251b40 <__pyx_lineno>
   319e8: c7 05 52 01 22 00 d7 28 00 00	movl	$0x28d7, 0x220152(%rip) # imm = 0x28D7
                                                                        # 0x251b44 <__pyx_clineno>
   319f2: e9 c2 1c 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   319f7: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   319fe: 48 8b 00                     	movq	(%rax), %rax
   31a01: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   31a05: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   31a0c: 48 89 10                     	movq	%rdx, (%rax)
   31a0f: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   31a16: 48 8b 00                     	movq	(%rax), %rax
   31a19: 48 85 c0                     	testq	%rax, %rax
   31a1c: 75 1b                        	jne	0x31a39 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0xa2a>
   31a1e: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   31a25: 48 8b 40 08                  	movq	0x8(%rax), %rax
   31a29: 48 8b 40 30                  	movq	0x30(%rax), %rax
   31a2d: 48 8b 95 18 ff ff ff         	movq	-0xe8(%rbp), %rdx
   31a34: 48 89 d7                     	movq	%rdx, %rdi
   31a37: ff d0                        	callq	*%rax
   31a39: 48 c7 85 18 ff ff ff 00 00 00 00     	movq	$0x0, -0xe8(%rbp)
   31a44: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   31a4b: 48 8b 00                     	movq	(%rax), %rax
   31a4e: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   31a52: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   31a59: 48 89 10                     	movq	%rdx, (%rax)
   31a5c: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   31a63: 48 8b 00                     	movq	(%rax), %rax
   31a66: 48 85 c0                     	testq	%rax, %rax
   31a69: 75 1b                        	jne	0x31a86 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0xa77>
   31a6b: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   31a72: 48 8b 40 08                  	movq	0x8(%rax), %rax
   31a76: 48 8b 40 30                  	movq	0x30(%rax), %rax
   31a7a: 48 8b 95 f8 fe ff ff         	movq	-0x108(%rbp), %rdx
   31a81: 48 89 d7                     	movq	%rdx, %rdi
   31a84: ff d0                        	callq	*%rax
   31a86: 48 c7 85 f8 fe ff ff 00 00 00 00     	movq	$0x0, -0x108(%rbp)
   31a91: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31a98: 48 89 85 b8 fe ff ff         	movq	%rax, -0x148(%rbp)
   31a9f: 48 c7 85 08 ff ff ff 00 00 00 00     	movq	$0x0, -0xf8(%rbp)
   31aaa: 48 8b 95 78 fe ff ff         	movq	-0x188(%rbp), %rdx
   31ab1: 48 8b 85 68 fe ff ff         	movq	-0x198(%rbp), %rax
   31ab8: 48 89 d6                     	movq	%rdx, %rsi
   31abb: 48 89 c7                     	movq	%rax, %rdi
   31abe: e8 1d 41 fd ff               	callq	0x5be0 <PyNumber_Subtract@plt>
   31ac3: 48 89 85 08 ff ff ff         	movq	%rax, -0xf8(%rbp)
   31aca: 48 83 bd 08 ff ff ff 00      	cmpq	$0x0, -0xf8(%rbp)
   31ad2: 0f 94 c0                     	sete	%al
   31ad5: 0f b6 c0                     	movzbl	%al, %eax
   31ad8: 48 85 c0                     	testq	%rax, %rax
   31adb: 74 27                        	je	0x31b04 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0xaf5>
   31add: 48 8b 05 04 da 21 00         	movq	0x21da04(%rip), %rax    # 0x24f4e8 <__pyx_f>
   31ae4: 48 89 05 5d 00 22 00         	movq	%rax, 0x22005d(%rip)    # 0x251b48 <__pyx_filename>
   31aeb: c7 05 4b 00 22 00 94 01 00 00	movl	$0x194, 0x22004b(%rip)  # imm = 0x194
                                                                        # 0x251b40 <__pyx_lineno>
   31af5: c7 05 45 00 22 00 e7 28 00 00	movl	$0x28e7, 0x220045(%rip) # imm = 0x28E7
                                                                        # 0x251b44 <__pyx_clineno>
   31aff: e9 b5 1b 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   31b04: 48 8b 35 3d 06 22 00         	movq	0x22063d(%rip), %rsi    # 0x252148 <__pyx_int_1>
   31b0b: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31b12: b9 00 00 00 00               	movl	$0x0, %ecx
   31b17: ba 01 00 00 00               	movl	$0x1, %edx
   31b1c: 48 89 c7                     	movq	%rax, %rdi
   31b1f: e8 70 56 01 00               	callq	0x47194 <__Pyx_PyInt_AddObjC>
   31b24: 48 89 85 f8 fe ff ff         	movq	%rax, -0x108(%rbp)
   31b2b: 48 83 bd f8 fe ff ff 00      	cmpq	$0x0, -0x108(%rbp)
   31b33: 0f 94 c0                     	sete	%al
   31b36: 0f b6 c0                     	movzbl	%al, %eax
   31b39: 48 85 c0                     	testq	%rax, %rax
   31b3c: 74 27                        	je	0x31b65 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0xb56>
   31b3e: 48 8b 05 a3 d9 21 00         	movq	0x21d9a3(%rip), %rax    # 0x24f4e8 <__pyx_f>
   31b45: 48 89 05 fc ff 21 00         	movq	%rax, 0x21fffc(%rip)    # 0x251b48 <__pyx_filename>
   31b4c: c7 05 ea ff 21 00 94 01 00 00	movl	$0x194, 0x21ffea(%rip)  # imm = 0x194
                                                                        # 0x251b40 <__pyx_lineno>
   31b56: c7 05 e4 ff 21 00 e9 28 00 00	movl	$0x28e9, 0x21ffe4(%rip) # imm = 0x28E9
                                                                        # 0x251b44 <__pyx_clineno>
   31b60: e9 54 1b 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   31b65: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31b6c: 48 8b 00                     	movq	(%rax), %rax
   31b6f: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   31b73: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31b7a: 48 89 10                     	movq	%rdx, (%rax)
   31b7d: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31b84: 48 8b 00                     	movq	(%rax), %rax
   31b87: 48 85 c0                     	testq	%rax, %rax
   31b8a: 75 1b                        	jne	0x31ba7 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0xb98>
   31b8c: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31b93: 48 8b 40 08                  	movq	0x8(%rax), %rax
   31b97: 48 8b 40 30                  	movq	0x30(%rax), %rax
   31b9b: 48 8b 95 08 ff ff ff         	movq	-0xf8(%rbp), %rdx
   31ba2: 48 89 d7                     	movq	%rdx, %rdi
   31ba5: ff d0                        	callq	*%rax
   31ba7: 48 c7 85 08 ff ff ff 00 00 00 00     	movq	$0x0, -0xf8(%rbp)
   31bb2: bf 03 00 00 00               	movl	$0x3, %edi
   31bb7: e8 94 3d fd ff               	callq	0x5950 <PyTuple_New@plt>
   31bbc: 48 89 85 08 ff ff ff         	movq	%rax, -0xf8(%rbp)
   31bc3: 48 83 bd 08 ff ff ff 00      	cmpq	$0x0, -0xf8(%rbp)
   31bcb: 0f 94 c0                     	sete	%al
   31bce: 0f b6 c0                     	movzbl	%al, %eax
   31bd1: 48 85 c0                     	testq	%rax, %rax
   31bd4: 74 27                        	je	0x31bfd <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0xbee>
   31bd6: 48 8b 05 0b d9 21 00         	movq	0x21d90b(%rip), %rax    # 0x24f4e8 <__pyx_f>
   31bdd: 48 89 05 64 ff 21 00         	movq	%rax, 0x21ff64(%rip)    # 0x251b48 <__pyx_filename>
   31be4: c7 05 52 ff 21 00 94 01 00 00	movl	$0x194, 0x21ff52(%rip)  # imm = 0x194
                                                                        # 0x251b40 <__pyx_lineno>
   31bee: c7 05 4c ff 21 00 ec 28 00 00	movl	$0x28ec, 0x21ff4c(%rip) # imm = 0x28EC
                                                                        # 0x251b44 <__pyx_clineno>
   31bf8: e9 bc 1a 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   31bfd: 48 8b 85 70 fe ff ff         	movq	-0x190(%rbp), %rax
   31c04: 48 8b 00                     	movq	(%rax), %rax
   31c07: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   31c0b: 48 8b 85 70 fe ff ff         	movq	-0x190(%rbp), %rax
   31c12: 48 89 10                     	movq	%rdx, (%rax)
   31c15: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31c1c: 48 8b 95 70 fe ff ff         	movq	-0x190(%rbp), %rdx
   31c23: 48 89 50 18                  	movq	%rdx, 0x18(%rax)
   31c27: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31c2e: 48 8b 95 f8 fe ff ff         	movq	-0x108(%rbp), %rdx
   31c35: 48 89 50 20                  	movq	%rdx, 0x20(%rax)
   31c39: 48 8b 85 78 fe ff ff         	movq	-0x188(%rbp), %rax
   31c40: 48 8b 00                     	movq	(%rax), %rax
   31c43: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   31c47: 48 8b 85 78 fe ff ff         	movq	-0x188(%rbp), %rax
   31c4e: 48 89 10                     	movq	%rdx, (%rax)
   31c51: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31c58: 48 8b 95 78 fe ff ff         	movq	-0x188(%rbp), %rdx
   31c5f: 48 89 50 28                  	movq	%rdx, 0x28(%rax)
   31c63: 48 c7 85 f8 fe ff ff 00 00 00 00     	movq	$0x0, -0x108(%rbp)
   31c6e: 48 8b 05 1b ff 21 00         	movq	0x21ff1b(%rip), %rax    # 0x251b90 <__pyx_builtin_xrange>
   31c75: 48 8b 8d 08 ff ff ff         	movq	-0xf8(%rbp), %rcx
   31c7c: ba 00 00 00 00               	movl	$0x0, %edx
   31c81: 48 89 ce                     	movq	%rcx, %rsi
   31c84: 48 89 c7                     	movq	%rax, %rdi
   31c87: e8 9a 48 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   31c8c: 48 89 85 f8 fe ff ff         	movq	%rax, -0x108(%rbp)
   31c93: 48 83 bd f8 fe ff ff 00      	cmpq	$0x0, -0x108(%rbp)
   31c9b: 0f 94 c0                     	sete	%al
   31c9e: 0f b6 c0                     	movzbl	%al, %eax
   31ca1: 48 85 c0                     	testq	%rax, %rax
   31ca4: 74 27                        	je	0x31ccd <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0xcbe>
   31ca6: 48 8b 05 3b d8 21 00         	movq	0x21d83b(%rip), %rax    # 0x24f4e8 <__pyx_f>
   31cad: 48 89 05 94 fe 21 00         	movq	%rax, 0x21fe94(%rip)    # 0x251b48 <__pyx_filename>
   31cb4: c7 05 82 fe 21 00 94 01 00 00	movl	$0x194, 0x21fe82(%rip)  # imm = 0x194
                                                                        # 0x251b40 <__pyx_lineno>
   31cbe: c7 05 7c fe 21 00 f7 28 00 00	movl	$0x28f7, 0x21fe7c(%rip) # imm = 0x28F7
                                                                        # 0x251b44 <__pyx_clineno>
   31cc8: e9 ec 19 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   31ccd: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31cd4: 48 8b 00                     	movq	(%rax), %rax
   31cd7: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   31cdb: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31ce2: 48 89 10                     	movq	%rdx, (%rax)
   31ce5: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31cec: 48 8b 00                     	movq	(%rax), %rax
   31cef: 48 85 c0                     	testq	%rax, %rax
   31cf2: 75 1b                        	jne	0x31d0f <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0xd00>
   31cf4: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31cfb: 48 8b 40 08                  	movq	0x8(%rax), %rax
   31cff: 48 8b 40 30                  	movq	0x30(%rax), %rax
   31d03: 48 8b 95 08 ff ff ff         	movq	-0xf8(%rbp), %rdx
   31d0a: 48 89 d7                     	movq	%rdx, %rdi
   31d0d: ff d0                        	callq	*%rax
   31d0f: 48 c7 85 08 ff ff ff 00 00 00 00     	movq	$0x0, -0xf8(%rbp)
   31d1a: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   31d21: 48 8b 40 08                  	movq	0x8(%rax), %rax
   31d25: 48 8b 15 cc d2 21 00         	movq	0x21d2cc(%rip), %rdx    # 0x24eff8 <memcmp@@GLIBC_2.2.5+0x24eff8>
   31d2c: 48 39 d0                     	cmpq	%rdx, %rax
   31d2f: 0f 94 c0                     	sete	%al
   31d32: 0f b6 c0                     	movzbl	%al, %eax
   31d35: 48 85 c0                     	testq	%rax, %rax
   31d38: 75 17                        	jne	0x31d51 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0xd42>
   31d3a: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   31d41: 48 8b 40 08                  	movq	0x8(%rax), %rax
   31d45: 48 8b 15 7c d1 21 00         	movq	0x21d17c(%rip), %rdx    # 0x24eec8 <memcmp@@GLIBC_2.2.5+0x24eec8>
   31d4c: 48 39 d0                     	cmpq	%rdx, %rax
   31d4f: 75 41                        	jne	0x31d92 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0xd83>
   31d51: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   31d58: 48 89 85 08 ff ff ff         	movq	%rax, -0xf8(%rbp)
   31d5f: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31d66: 48 8b 00                     	movq	(%rax), %rax
   31d69: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   31d6d: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31d74: 48 89 10                     	movq	%rdx, (%rax)
   31d77: 48 c7 85 10 ff ff ff 00 00 00 00     	movq	$0x0, -0xf0(%rbp)
   31d82: 48 c7 85 20 ff ff ff 00 00 00 00     	movq	$0x0, -0xe0(%rbp)
   31d8d: e9 ae 00 00 00               	jmp	0x31e40 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0xe31>
   31d92: 48 c7 85 10 ff ff ff ff ff ff ff     	movq	$-0x1, -0xf0(%rbp)
   31d9d: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   31da4: 48 89 c7                     	movq	%rax, %rdi
   31da7: e8 f4 3c fd ff               	callq	0x5aa0 <PyObject_GetIter@plt>
   31dac: 48 89 85 08 ff ff ff         	movq	%rax, -0xf8(%rbp)
   31db3: 48 83 bd 08 ff ff ff 00      	cmpq	$0x0, -0xf8(%rbp)
   31dbb: 0f 94 c0                     	sete	%al
   31dbe: 0f b6 c0                     	movzbl	%al, %eax
   31dc1: 48 85 c0                     	testq	%rax, %rax
   31dc4: 74 27                        	je	0x31ded <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0xdde>
   31dc6: 48 8b 05 1b d7 21 00         	movq	0x21d71b(%rip), %rax    # 0x24f4e8 <__pyx_f>
   31dcd: 48 89 05 74 fd 21 00         	movq	%rax, 0x21fd74(%rip)    # 0x251b48 <__pyx_filename>
   31dd4: c7 05 62 fd 21 00 94 01 00 00	movl	$0x194, 0x21fd62(%rip)  # imm = 0x194
                                                                        # 0x251b40 <__pyx_lineno>
   31dde: c7 05 5c fd 21 00 fe 28 00 00	movl	$0x28fe, 0x21fd5c(%rip) # imm = 0x28FE
                                                                        # 0x251b44 <__pyx_clineno>
   31de8: e9 cc 18 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   31ded: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31df4: 48 8b 40 08                  	movq	0x8(%rax), %rax
   31df8: 48 8b 80 e0 00 00 00         	movq	0xe0(%rax), %rax
   31dff: 48 89 85 20 ff ff ff         	movq	%rax, -0xe0(%rbp)
   31e06: 48 83 bd 20 ff ff ff 00      	cmpq	$0x0, -0xe0(%rbp)
   31e0e: 0f 94 c0                     	sete	%al
   31e11: 0f b6 c0                     	movzbl	%al, %eax
   31e14: 48 85 c0                     	testq	%rax, %rax
   31e17: 74 27                        	je	0x31e40 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0xe31>
   31e19: 48 8b 05 c8 d6 21 00         	movq	0x21d6c8(%rip), %rax    # 0x24f4e8 <__pyx_f>
   31e20: 48 89 05 21 fd 21 00         	movq	%rax, 0x21fd21(%rip)    # 0x251b48 <__pyx_filename>
   31e27: c7 05 0f fd 21 00 94 01 00 00	movl	$0x194, 0x21fd0f(%rip)  # imm = 0x194
                                                                        # 0x251b40 <__pyx_lineno>
   31e31: c7 05 09 fd 21 00 00 29 00 00	movl	$0x2900, 0x21fd09(%rip) # imm = 0x2900
                                                                        # 0x251b44 <__pyx_clineno>
   31e3b: e9 79 18 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   31e40: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   31e47: 48 8b 00                     	movq	(%rax), %rax
   31e4a: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   31e4e: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   31e55: 48 89 10                     	movq	%rdx, (%rax)
   31e58: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   31e5f: 48 8b 00                     	movq	(%rax), %rax
   31e62: 48 85 c0                     	testq	%rax, %rax
   31e65: 75 1b                        	jne	0x31e82 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0xe73>
   31e67: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   31e6e: 48 8b 40 08                  	movq	0x8(%rax), %rax
   31e72: 48 8b 40 30                  	movq	0x30(%rax), %rax
   31e76: 48 8b 95 f8 fe ff ff         	movq	-0x108(%rbp), %rdx
   31e7d: 48 89 d7                     	movq	%rdx, %rdi
   31e80: ff d0                        	callq	*%rax
   31e82: 48 c7 85 f8 fe ff ff 00 00 00 00     	movq	$0x0, -0x108(%rbp)
   31e8d: 48 83 bd 20 ff ff ff 00      	cmpq	$0x0, -0xe0(%rbp)
   31e95: 0f 94 c0                     	sete	%al
   31e98: 0f b6 c0                     	movzbl	%al, %eax
   31e9b: 48 85 c0                     	testq	%rax, %rax
   31e9e: 0f 84 db 00 00 00            	je	0x31f7f <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0xf70>
   31ea4: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31eab: 48 8b 40 08                  	movq	0x8(%rax), %rax
   31eaf: 48 8b 15 42 d1 21 00         	movq	0x21d142(%rip), %rdx    # 0x24eff8 <memcmp@@GLIBC_2.2.5+0x24eff8>
   31eb6: 48 39 d0                     	cmpq	%rdx, %rax
   31eb9: 0f 94 c0                     	sete	%al
   31ebc: 0f b6 c0                     	movzbl	%al, %eax
   31ebf: 48 85 c0                     	testq	%rax, %rax
   31ec2: 74 60                        	je	0x31f24 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0xf15>
   31ec4: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31ecb: 48 8b 40 10                  	movq	0x10(%rax), %rax
   31ecf: 48 39 85 10 ff ff ff         	cmpq	%rax, -0xf0(%rbp)
   31ed6: 0f 8d 19 17 00 00            	jge	0x335f5 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x25e6>
   31edc: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31ee3: 48 8b 40 18                  	movq	0x18(%rax), %rax
   31ee7: 48 8b 95 10 ff ff ff         	movq	-0xf0(%rbp), %rdx
   31eee: 48 c1 e2 03                  	shlq	$0x3, %rdx
   31ef2: 48 01 d0                     	addq	%rdx, %rax
   31ef5: 48 8b 00                     	movq	(%rax), %rax
   31ef8: 48 89 85 f8 fe ff ff         	movq	%rax, -0x108(%rbp)
   31eff: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   31f06: 48 8b 00                     	movq	(%rax), %rax
   31f09: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   31f0d: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   31f14: 48 89 10                     	movq	%rdx, (%rax)
   31f17: 48 83 85 10 ff ff ff 01      	addq	$0x1, -0xf0(%rbp)
   31f1f: e9 1c 01 00 00               	jmp	0x32040 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1031>
   31f24: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31f2b: 48 8b 40 10                  	movq	0x10(%rax), %rax
   31f2f: 48 39 85 10 ff ff ff         	cmpq	%rax, -0xf0(%rbp)
   31f36: 0f 8d bc 16 00 00            	jge	0x335f8 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x25e9>
   31f3c: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   31f43: 48 8b 95 10 ff ff ff         	movq	-0xf0(%rbp), %rdx
   31f4a: 48 83 c2 02                  	addq	$0x2, %rdx
   31f4e: 48 8b 44 d0 08               	movq	0x8(%rax,%rdx,8), %rax
   31f53: 48 89 85 f8 fe ff ff         	movq	%rax, -0x108(%rbp)
   31f5a: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   31f61: 48 8b 00                     	movq	(%rax), %rax
   31f64: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   31f68: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   31f6f: 48 89 10                     	movq	%rdx, (%rax)
   31f72: 48 83 85 10 ff ff ff 01      	addq	$0x1, -0xf0(%rbp)
   31f7a: e9 c1 00 00 00               	jmp	0x32040 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1031>
   31f7f: 48 8b 95 08 ff ff ff         	movq	-0xf8(%rbp), %rdx
   31f86: 48 8b 85 20 ff ff ff         	movq	-0xe0(%rbp), %rax
   31f8d: 48 89 d7                     	movq	%rdx, %rdi
   31f90: ff d0                        	callq	*%rax
   31f92: 48 89 85 f8 fe ff ff         	movq	%rax, -0x108(%rbp)
   31f99: 48 83 bd f8 fe ff ff 00      	cmpq	$0x0, -0x108(%rbp)
   31fa1: 0f 94 c0                     	sete	%al
   31fa4: 0f b6 c0                     	movzbl	%al, %eax
   31fa7: 48 85 c0                     	testq	%rax, %rax
   31faa: 0f 84 90 00 00 00            	je	0x32040 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1031>
   31fb0: e8 cb 39 fd ff               	callq	0x5980 <PyErr_Occurred@plt>
   31fb5: 48 89 85 70 ff ff ff         	movq	%rax, -0x90(%rbp)
   31fbc: 48 83 bd 70 ff ff ff 00      	cmpq	$0x0, -0x90(%rbp)
   31fc4: 0f 84 31 16 00 00            	je	0x335fb <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x25ec>
   31fca: 48 8b 05 d7 cf 21 00         	movq	0x21cfd7(%rip), %rax    # 0x24efa8 <memcmp@@GLIBC_2.2.5+0x24efa8>
   31fd1: 48 8b 00                     	movq	(%rax), %rax
   31fd4: 48 39 85 70 ff ff ff         	cmpq	%rax, -0x90(%rbp)
   31fdb: 0f 94 c0                     	sete	%al
   31fde: 0f b6 c0                     	movzbl	%al, %eax
   31fe1: 48 85 c0                     	testq	%rax, %rax
   31fe4: 75 29                        	jne	0x3200f <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1000>
   31fe6: 48 8b 05 bb cf 21 00         	movq	0x21cfbb(%rip), %rax    # 0x24efa8 <memcmp@@GLIBC_2.2.5+0x24efa8>
   31fed: 48 8b 10                     	movq	(%rax), %rdx
   31ff0: 48 8b 85 70 ff ff ff         	movq	-0x90(%rbp), %rax
   31ff7: 48 89 d6                     	movq	%rdx, %rsi
   31ffa: 48 89 c7                     	movq	%rax, %rdi
   31ffd: e8 8e 37 fd ff               	callq	0x5790 <PyErr_GivenExceptionMatches@plt>
   32002: 85 c0                        	testl	%eax, %eax
   32004: 0f 95 c0                     	setne	%al
   32007: 0f b6 c0                     	movzbl	%al, %eax
   3200a: 48 85 c0                     	testq	%rax, %rax
   3200d: 74 0a                        	je	0x32019 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x100a>
   3200f: e8 0c 39 fd ff               	callq	0x5920 <PyErr_Clear@plt>
   32014: e9 e2 15 00 00               	jmp	0x335fb <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x25ec>
   32019: 48 8b 05 c8 d4 21 00         	movq	0x21d4c8(%rip), %rax    # 0x24f4e8 <__pyx_f>
   32020: 48 89 05 21 fb 21 00         	movq	%rax, 0x21fb21(%rip)    # 0x251b48 <__pyx_filename>
   32027: c7 05 0f fb 21 00 94 01 00 00	movl	$0x194, 0x21fb0f(%rip)  # imm = 0x194
                                                                        # 0x251b40 <__pyx_lineno>
   32031: c7 05 09 fb 21 00 1c 29 00 00	movl	$0x291c, 0x21fb09(%rip) # imm = 0x291C
                                                                        # 0x251b44 <__pyx_clineno>
   3203b: e9 79 16 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   32040: 48 8b 85 c0 fe ff ff         	movq	-0x140(%rbp), %rax
   32047: 48 89 85 78 ff ff ff         	movq	%rax, -0x88(%rbp)
   3204e: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   32055: 48 89 85 c0 fe ff ff         	movq	%rax, -0x140(%rbp)
   3205c: 48 83 bd 78 ff ff ff 00      	cmpq	$0x0, -0x88(%rbp)
   32064: 74 42                        	je	0x320a8 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1099>
   32066: 48 8b 85 78 ff ff ff         	movq	-0x88(%rbp), %rax
   3206d: 48 8b 00                     	movq	(%rax), %rax
   32070: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   32074: 48 8b 85 78 ff ff ff         	movq	-0x88(%rbp), %rax
   3207b: 48 89 10                     	movq	%rdx, (%rax)
   3207e: 48 8b 85 78 ff ff ff         	movq	-0x88(%rbp), %rax
   32085: 48 8b 00                     	movq	(%rax), %rax
   32088: 48 85 c0                     	testq	%rax, %rax
   3208b: 75 1b                        	jne	0x320a8 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1099>
   3208d: 48 8b 85 78 ff ff ff         	movq	-0x88(%rbp), %rax
   32094: 48 8b 40 08                  	movq	0x8(%rax), %rax
   32098: 48 8b 40 30                  	movq	0x30(%rax), %rax
   3209c: 48 8b 95 78 ff ff ff         	movq	-0x88(%rbp), %rdx
   320a3: 48 89 d7                     	movq	%rdx, %rdi
   320a6: ff d0                        	callq	*%rax
   320a8: 48 c7 85 f8 fe ff ff 00 00 00 00     	movq	$0x0, -0x108(%rbp)
   320b3: 48 8b 85 80 fe ff ff         	movq	-0x180(%rbp), %rax
   320ba: 48 8b 00                     	movq	(%rax), %rax
   320bd: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   320c1: 48 8b 85 80 fe ff ff         	movq	-0x180(%rbp), %rax
   320c8: 48 89 10                     	movq	%rdx, (%rax)
   320cb: 48 8b 85 c8 fe ff ff         	movq	-0x138(%rbp), %rax
   320d2: 48 89 45 80                  	movq	%rax, -0x80(%rbp)
   320d6: 48 8b 85 80 fe ff ff         	movq	-0x180(%rbp), %rax
   320dd: 48 89 85 c8 fe ff ff         	movq	%rax, -0x138(%rbp)
   320e4: 48 83 7d 80 00               	cmpq	$0x0, -0x80(%rbp)
   320e9: 74 33                        	je	0x3211e <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x110f>
   320eb: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   320ef: 48 8b 00                     	movq	(%rax), %rax
   320f2: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   320f6: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   320fa: 48 89 10                     	movq	%rdx, (%rax)
   320fd: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   32101: 48 8b 00                     	movq	(%rax), %rax
   32104: 48 85 c0                     	testq	%rax, %rax
   32107: 75 15                        	jne	0x3211e <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x110f>
   32109: 48 8b 45 80                  	movq	-0x80(%rbp), %rax
   3210d: 48 8b 40 08                  	movq	0x8(%rax), %rax
   32111: 48 8b 40 30                  	movq	0x30(%rax), %rax
   32115: 48 8b 55 80                  	movq	-0x80(%rbp), %rdx
   32119: 48 89 d7                     	movq	%rdx, %rdi
   3211c: ff d0                        	callq	*%rax
   3211e: 48 8b 85 b8 fe ff ff         	movq	-0x148(%rbp), %rax
   32125: 48 8b 00                     	movq	(%rax), %rax
   32128: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   3212c: 48 8b 85 b8 fe ff ff         	movq	-0x148(%rbp), %rax
   32133: 48 89 10                     	movq	%rdx, (%rax)
   32136: 48 8b 85 d0 fe ff ff         	movq	-0x130(%rbp), %rax
   3213d: 48 89 45 88                  	movq	%rax, -0x78(%rbp)
   32141: 48 8b 85 b8 fe ff ff         	movq	-0x148(%rbp), %rax
   32148: 48 89 85 d0 fe ff ff         	movq	%rax, -0x130(%rbp)
   3214f: 48 83 7d 88 00               	cmpq	$0x0, -0x78(%rbp)
   32154: 74 33                        	je	0x32189 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x117a>
   32156: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   3215a: 48 8b 00                     	movq	(%rax), %rax
   3215d: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   32161: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   32165: 48 89 10                     	movq	%rdx, (%rax)
   32168: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   3216c: 48 8b 00                     	movq	(%rax), %rax
   3216f: 48 85 c0                     	testq	%rax, %rax
   32172: 75 15                        	jne	0x32189 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x117a>
   32174: 48 8b 45 88                  	movq	-0x78(%rbp), %rax
   32178: 48 8b 40 08                  	movq	0x8(%rax), %rax
   3217c: 48 8b 40 30                  	movq	0x30(%rax), %rax
   32180: 48 8b 55 88                  	movq	-0x78(%rbp), %rdx
   32184: 48 89 d7                     	movq	%rdx, %rdi
   32187: ff d0                        	callq	*%rax
   32189: 48 8b 95 78 fe ff ff         	movq	-0x188(%rbp), %rdx
   32190: 48 8b 85 c0 fe ff ff         	movq	-0x140(%rbp), %rax
   32197: 48 89 d6                     	movq	%rdx, %rsi
   3219a: 48 89 c7                     	movq	%rax, %rdi
   3219d: e8 1e 3a fd ff               	callq	0x5bc0 <PyNumber_Add@plt>
   321a2: 48 89 85 f8 fe ff ff         	movq	%rax, -0x108(%rbp)
   321a9: 48 83 bd f8 fe ff ff 00      	cmpq	$0x0, -0x108(%rbp)
   321b1: 0f 94 c0                     	sete	%al
   321b4: 0f b6 c0                     	movzbl	%al, %eax
   321b7: 48 85 c0                     	testq	%rax, %rax
   321ba: 74 27                        	je	0x321e3 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x11d4>
   321bc: 48 8b 05 25 d3 21 00         	movq	0x21d325(%rip), %rax    # 0x24f4e8 <__pyx_f>
   321c3: 48 89 05 7e f9 21 00         	movq	%rax, 0x21f97e(%rip)    # 0x251b48 <__pyx_filename>
   321ca: c7 05 6c f9 21 00 99 01 00 00	movl	$0x199, 0x21f96c(%rip)  # imm = 0x199
                                                                        # 0x251b40 <__pyx_lineno>
   321d4: c7 05 66 f9 21 00 40 29 00 00	movl	$0x2940, 0x21f966(%rip) # imm = 0x2940
                                                                        # 0x251b44 <__pyx_clineno>
   321de: e9 d6 14 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   321e3: 48 8b 35 5e ff 21 00         	movq	0x21ff5e(%rip), %rsi    # 0x252148 <__pyx_int_1>
   321ea: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   321f1: b9 00 00 00 00               	movl	$0x0, %ecx
   321f6: ba 01 00 00 00               	movl	$0x1, %edx
   321fb: 48 89 c7                     	movq	%rax, %rdi
   321fe: e8 64 54 01 00               	callq	0x47667 <__Pyx_PyInt_SubtractObjC>
   32203: 48 89 85 18 ff ff ff         	movq	%rax, -0xe8(%rbp)
   3220a: 48 83 bd 18 ff ff ff 00      	cmpq	$0x0, -0xe8(%rbp)
   32212: 0f 94 c0                     	sete	%al
   32215: 0f b6 c0                     	movzbl	%al, %eax
   32218: 48 85 c0                     	testq	%rax, %rax
   3221b: 74 27                        	je	0x32244 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1235>
   3221d: 48 8b 05 c4 d2 21 00         	movq	0x21d2c4(%rip), %rax    # 0x24f4e8 <__pyx_f>
   32224: 48 89 05 1d f9 21 00         	movq	%rax, 0x21f91d(%rip)    # 0x251b48 <__pyx_filename>
   3222b: c7 05 0b f9 21 00 99 01 00 00	movl	$0x199, 0x21f90b(%rip)  # imm = 0x199
                                                                        # 0x251b40 <__pyx_lineno>
   32235: c7 05 05 f9 21 00 42 29 00 00	movl	$0x2942, 0x21f905(%rip) # imm = 0x2942
                                                                        # 0x251b44 <__pyx_clineno>
   3223f: e9 75 14 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   32244: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   3224b: 48 8b 00                     	movq	(%rax), %rax
   3224e: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   32252: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   32259: 48 89 10                     	movq	%rdx, (%rax)
   3225c: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   32263: 48 8b 00                     	movq	(%rax), %rax
   32266: 48 85 c0                     	testq	%rax, %rax
   32269: 75 1b                        	jne	0x32286 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1277>
   3226b: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   32272: 48 8b 40 08                  	movq	0x8(%rax), %rax
   32276: 48 8b 40 30                  	movq	0x30(%rax), %rax
   3227a: 48 8b 95 f8 fe ff ff         	movq	-0x108(%rbp), %rdx
   32281: 48 89 d7                     	movq	%rdx, %rdi
   32284: ff d0                        	callq	*%rax
   32286: 48 c7 85 f8 fe ff ff 00 00 00 00     	movq	$0x0, -0x108(%rbp)
   32291: bf 02 00 00 00               	movl	$0x2, %edi
   32296: e8 b5 36 fd ff               	callq	0x5950 <PyTuple_New@plt>
   3229b: 48 89 85 f8 fe ff ff         	movq	%rax, -0x108(%rbp)
   322a2: 48 83 bd f8 fe ff ff 00      	cmpq	$0x0, -0x108(%rbp)
   322aa: 0f 94 c0                     	sete	%al
   322ad: 0f b6 c0                     	movzbl	%al, %eax
   322b0: 48 85 c0                     	testq	%rax, %rax
   322b3: 74 27                        	je	0x322dc <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x12cd>
   322b5: 48 8b 05 2c d2 21 00         	movq	0x21d22c(%rip), %rax    # 0x24f4e8 <__pyx_f>
   322bc: 48 89 05 85 f8 21 00         	movq	%rax, 0x21f885(%rip)    # 0x251b48 <__pyx_filename>
   322c3: c7 05 73 f8 21 00 99 01 00 00	movl	$0x199, 0x21f873(%rip)  # imm = 0x199
                                                                        # 0x251b40 <__pyx_lineno>
   322cd: c7 05 6d f8 21 00 45 29 00 00	movl	$0x2945, 0x21f86d(%rip) # imm = 0x2945
                                                                        # 0x251b44 <__pyx_clineno>
   322d7: e9 dd 13 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   322dc: 48 8b 85 c0 fe ff ff         	movq	-0x140(%rbp), %rax
   322e3: 48 8b 00                     	movq	(%rax), %rax
   322e6: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   322ea: 48 8b 85 c0 fe ff ff         	movq	-0x140(%rbp), %rax
   322f1: 48 89 10                     	movq	%rdx, (%rax)
   322f4: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   322fb: 48 8b 95 c0 fe ff ff         	movq	-0x140(%rbp), %rdx
   32302: 48 89 50 18                  	movq	%rdx, 0x18(%rax)
   32306: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   3230d: 48 8b 95 18 ff ff ff         	movq	-0xe8(%rbp), %rdx
   32314: 48 89 50 20                  	movq	%rdx, 0x20(%rax)
   32318: 48 c7 85 18 ff ff ff 00 00 00 00     	movq	$0x0, -0xe8(%rbp)
   32323: 48 8b 05 66 f8 21 00         	movq	0x21f866(%rip), %rax    # 0x251b90 <__pyx_builtin_xrange>
   3232a: 48 8b 8d f8 fe ff ff         	movq	-0x108(%rbp), %rcx
   32331: ba 00 00 00 00               	movl	$0x0, %edx
   32336: 48 89 ce                     	movq	%rcx, %rsi
   32339: 48 89 c7                     	movq	%rax, %rdi
   3233c: e8 e5 41 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   32341: 48 89 85 18 ff ff ff         	movq	%rax, -0xe8(%rbp)
   32348: 48 83 bd 18 ff ff ff 00      	cmpq	$0x0, -0xe8(%rbp)
   32350: 0f 94 c0                     	sete	%al
   32353: 0f b6 c0                     	movzbl	%al, %eax
   32356: 48 85 c0                     	testq	%rax, %rax
   32359: 74 27                        	je	0x32382 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1373>
   3235b: 48 8b 05 86 d1 21 00         	movq	0x21d186(%rip), %rax    # 0x24f4e8 <__pyx_f>
   32362: 48 89 05 df f7 21 00         	movq	%rax, 0x21f7df(%rip)    # 0x251b48 <__pyx_filename>
   32369: c7 05 cd f7 21 00 99 01 00 00	movl	$0x199, 0x21f7cd(%rip)  # imm = 0x199
                                                                        # 0x251b40 <__pyx_lineno>
   32373: c7 05 c7 f7 21 00 4d 29 00 00	movl	$0x294d, 0x21f7c7(%rip) # imm = 0x294D
                                                                        # 0x251b44 <__pyx_clineno>
   3237d: e9 37 13 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   32382: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   32389: 48 8b 00                     	movq	(%rax), %rax
   3238c: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   32390: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   32397: 48 89 10                     	movq	%rdx, (%rax)
   3239a: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   323a1: 48 8b 00                     	movq	(%rax), %rax
   323a4: 48 85 c0                     	testq	%rax, %rax
   323a7: 75 1b                        	jne	0x323c4 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x13b5>
   323a9: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   323b0: 48 8b 40 08                  	movq	0x8(%rax), %rax
   323b4: 48 8b 40 30                  	movq	0x30(%rax), %rax
   323b8: 48 8b 95 f8 fe ff ff         	movq	-0x108(%rbp), %rdx
   323bf: 48 89 d7                     	movq	%rdx, %rdi
   323c2: ff d0                        	callq	*%rax
   323c4: 48 c7 85 f8 fe ff ff 00 00 00 00     	movq	$0x0, -0x108(%rbp)
   323cf: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   323d6: 48 8b 40 08                  	movq	0x8(%rax), %rax
   323da: 48 8b 15 17 cc 21 00         	movq	0x21cc17(%rip), %rdx    # 0x24eff8 <memcmp@@GLIBC_2.2.5+0x24eff8>
   323e1: 48 39 d0                     	cmpq	%rdx, %rax
   323e4: 0f 94 c0                     	sete	%al
   323e7: 0f b6 c0                     	movzbl	%al, %eax
   323ea: 48 85 c0                     	testq	%rax, %rax
   323ed: 75 17                        	jne	0x32406 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x13f7>
   323ef: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   323f6: 48 8b 40 08                  	movq	0x8(%rax), %rax
   323fa: 48 8b 15 c7 ca 21 00         	movq	0x21cac7(%rip), %rdx    # 0x24eec8 <memcmp@@GLIBC_2.2.5+0x24eec8>
   32401: 48 39 d0                     	cmpq	%rdx, %rax
   32404: 75 41                        	jne	0x32447 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1438>
   32406: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   3240d: 48 89 85 f8 fe ff ff         	movq	%rax, -0x108(%rbp)
   32414: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   3241b: 48 8b 00                     	movq	(%rax), %rax
   3241e: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   32422: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   32429: 48 89 10                     	movq	%rdx, (%rax)
   3242c: 48 c7 85 28 ff ff ff 00 00 00 00     	movq	$0x0, -0xd8(%rbp)
   32437: 48 c7 85 30 ff ff ff 00 00 00 00     	movq	$0x0, -0xd0(%rbp)
   32442: e9 ae 00 00 00               	jmp	0x324f5 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x14e6>
   32447: 48 c7 85 28 ff ff ff ff ff ff ff     	movq	$-0x1, -0xd8(%rbp)
   32452: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   32459: 48 89 c7                     	movq	%rax, %rdi
   3245c: e8 3f 36 fd ff               	callq	0x5aa0 <PyObject_GetIter@plt>
   32461: 48 89 85 f8 fe ff ff         	movq	%rax, -0x108(%rbp)
   32468: 48 83 bd f8 fe ff ff 00      	cmpq	$0x0, -0x108(%rbp)
   32470: 0f 94 c0                     	sete	%al
   32473: 0f b6 c0                     	movzbl	%al, %eax
   32476: 48 85 c0                     	testq	%rax, %rax
   32479: 74 27                        	je	0x324a2 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1493>
   3247b: 48 8b 05 66 d0 21 00         	movq	0x21d066(%rip), %rax    # 0x24f4e8 <__pyx_f>
   32482: 48 89 05 bf f6 21 00         	movq	%rax, 0x21f6bf(%rip)    # 0x251b48 <__pyx_filename>
   32489: c7 05 ad f6 21 00 99 01 00 00	movl	$0x199, 0x21f6ad(%rip)  # imm = 0x199
                                                                        # 0x251b40 <__pyx_lineno>
   32493: c7 05 a7 f6 21 00 54 29 00 00	movl	$0x2954, 0x21f6a7(%rip) # imm = 0x2954
                                                                        # 0x251b44 <__pyx_clineno>
   3249d: e9 17 12 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   324a2: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   324a9: 48 8b 40 08                  	movq	0x8(%rax), %rax
   324ad: 48 8b 80 e0 00 00 00         	movq	0xe0(%rax), %rax
   324b4: 48 89 85 30 ff ff ff         	movq	%rax, -0xd0(%rbp)
   324bb: 48 83 bd 30 ff ff ff 00      	cmpq	$0x0, -0xd0(%rbp)
   324c3: 0f 94 c0                     	sete	%al
   324c6: 0f b6 c0                     	movzbl	%al, %eax
   324c9: 48 85 c0                     	testq	%rax, %rax
   324cc: 74 27                        	je	0x324f5 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x14e6>
   324ce: 48 8b 05 13 d0 21 00         	movq	0x21d013(%rip), %rax    # 0x24f4e8 <__pyx_f>
   324d5: 48 89 05 6c f6 21 00         	movq	%rax, 0x21f66c(%rip)    # 0x251b48 <__pyx_filename>
   324dc: c7 05 5a f6 21 00 99 01 00 00	movl	$0x199, 0x21f65a(%rip)  # imm = 0x199
                                                                        # 0x251b40 <__pyx_lineno>
   324e6: c7 05 54 f6 21 00 56 29 00 00	movl	$0x2956, 0x21f654(%rip) # imm = 0x2956
                                                                        # 0x251b44 <__pyx_clineno>
   324f0: e9 c4 11 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   324f5: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   324fc: 48 8b 00                     	movq	(%rax), %rax
   324ff: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   32503: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   3250a: 48 89 10                     	movq	%rdx, (%rax)
   3250d: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   32514: 48 8b 00                     	movq	(%rax), %rax
   32517: 48 85 c0                     	testq	%rax, %rax
   3251a: 75 1b                        	jne	0x32537 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1528>
   3251c: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   32523: 48 8b 40 08                  	movq	0x8(%rax), %rax
   32527: 48 8b 40 30                  	movq	0x30(%rax), %rax
   3252b: 48 8b 95 18 ff ff ff         	movq	-0xe8(%rbp), %rdx
   32532: 48 89 d7                     	movq	%rdx, %rdi
   32535: ff d0                        	callq	*%rax
   32537: 48 c7 85 18 ff ff ff 00 00 00 00     	movq	$0x0, -0xe8(%rbp)
   32542: 48 83 bd 30 ff ff ff 00      	cmpq	$0x0, -0xd0(%rbp)
   3254a: 0f 94 c0                     	sete	%al
   3254d: 0f b6 c0                     	movzbl	%al, %eax
   32550: 48 85 c0                     	testq	%rax, %rax
   32553: 0f 84 db 00 00 00            	je	0x32634 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1625>
   32559: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   32560: 48 8b 40 08                  	movq	0x8(%rax), %rax
   32564: 48 8b 15 8d ca 21 00         	movq	0x21ca8d(%rip), %rdx    # 0x24eff8 <memcmp@@GLIBC_2.2.5+0x24eff8>
   3256b: 48 39 d0                     	cmpq	%rdx, %rax
   3256e: 0f 94 c0                     	sete	%al
   32571: 0f b6 c0                     	movzbl	%al, %eax
   32574: 48 85 c0                     	testq	%rax, %rax
   32577: 74 60                        	je	0x325d9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x15ca>
   32579: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   32580: 48 8b 40 10                  	movq	0x10(%rax), %rax
   32584: 48 39 85 28 ff ff ff         	cmpq	%rax, -0xd8(%rbp)
   3258b: 0f 8d 83 0c 00 00            	jge	0x33214 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2205>
   32591: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   32598: 48 8b 40 18                  	movq	0x18(%rax), %rax
   3259c: 48 8b 95 28 ff ff ff         	movq	-0xd8(%rbp), %rdx
   325a3: 48 c1 e2 03                  	shlq	$0x3, %rdx
   325a7: 48 01 d0                     	addq	%rdx, %rax
   325aa: 48 8b 00                     	movq	(%rax), %rax
   325ad: 48 89 85 18 ff ff ff         	movq	%rax, -0xe8(%rbp)
   325b4: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   325bb: 48 8b 00                     	movq	(%rax), %rax
   325be: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   325c2: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   325c9: 48 89 10                     	movq	%rdx, (%rax)
   325cc: 48 83 85 28 ff ff ff 01      	addq	$0x1, -0xd8(%rbp)
   325d4: e9 10 01 00 00               	jmp	0x326e9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x16da>
   325d9: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   325e0: 48 8b 40 10                  	movq	0x10(%rax), %rax
   325e4: 48 39 85 28 ff ff ff         	cmpq	%rax, -0xd8(%rbp)
   325eb: 0f 8d 26 0c 00 00            	jge	0x33217 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2208>
   325f1: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   325f8: 48 8b 95 28 ff ff ff         	movq	-0xd8(%rbp), %rdx
   325ff: 48 83 c2 02                  	addq	$0x2, %rdx
   32603: 48 8b 44 d0 08               	movq	0x8(%rax,%rdx,8), %rax
   32608: 48 89 85 18 ff ff ff         	movq	%rax, -0xe8(%rbp)
   3260f: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   32616: 48 8b 00                     	movq	(%rax), %rax
   32619: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   3261d: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   32624: 48 89 10                     	movq	%rdx, (%rax)
   32627: 48 83 85 28 ff ff ff 01      	addq	$0x1, -0xd8(%rbp)
   3262f: e9 b5 00 00 00               	jmp	0x326e9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x16da>
   32634: 48 8b 95 f8 fe ff ff         	movq	-0x108(%rbp), %rdx
   3263b: 48 8b 85 30 ff ff ff         	movq	-0xd0(%rbp), %rax
   32642: 48 89 d7                     	movq	%rdx, %rdi
   32645: ff d0                        	callq	*%rax
   32647: 48 89 85 18 ff ff ff         	movq	%rax, -0xe8(%rbp)
   3264e: 48 83 bd 18 ff ff ff 00      	cmpq	$0x0, -0xe8(%rbp)
   32656: 0f 94 c0                     	sete	%al
   32659: 0f b6 c0                     	movzbl	%al, %eax
   3265c: 48 85 c0                     	testq	%rax, %rax
   3265f: 0f 84 84 00 00 00            	je	0x326e9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x16da>
   32665: e8 16 33 fd ff               	callq	0x5980 <PyErr_Occurred@plt>
   3266a: 48 89 45 90                  	movq	%rax, -0x70(%rbp)
   3266e: 48 83 7d 90 00               	cmpq	$0x0, -0x70(%rbp)
   32673: 0f 84 a1 0b 00 00            	je	0x3321a <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x220b>
   32679: 48 8b 05 28 c9 21 00         	movq	0x21c928(%rip), %rax    # 0x24efa8 <memcmp@@GLIBC_2.2.5+0x24efa8>
   32680: 48 8b 00                     	movq	(%rax), %rax
   32683: 48 39 45 90                  	cmpq	%rax, -0x70(%rbp)
   32687: 0f 94 c0                     	sete	%al
   3268a: 0f b6 c0                     	movzbl	%al, %eax
   3268d: 48 85 c0                     	testq	%rax, %rax
   32690: 75 26                        	jne	0x326b8 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x16a9>
   32692: 48 8b 05 0f c9 21 00         	movq	0x21c90f(%rip), %rax    # 0x24efa8 <memcmp@@GLIBC_2.2.5+0x24efa8>
   32699: 48 8b 10                     	movq	(%rax), %rdx
   3269c: 48 8b 45 90                  	movq	-0x70(%rbp), %rax
   326a0: 48 89 d6                     	movq	%rdx, %rsi
   326a3: 48 89 c7                     	movq	%rax, %rdi
   326a6: e8 e5 30 fd ff               	callq	0x5790 <PyErr_GivenExceptionMatches@plt>
   326ab: 85 c0                        	testl	%eax, %eax
   326ad: 0f 95 c0                     	setne	%al
   326b0: 0f b6 c0                     	movzbl	%al, %eax
   326b3: 48 85 c0                     	testq	%rax, %rax
   326b6: 74 0a                        	je	0x326c2 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x16b3>
   326b8: e8 63 32 fd ff               	callq	0x5920 <PyErr_Clear@plt>
   326bd: e9 58 0b 00 00               	jmp	0x3321a <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x220b>
   326c2: 48 8b 05 1f ce 21 00         	movq	0x21ce1f(%rip), %rax    # 0x24f4e8 <__pyx_f>
   326c9: 48 89 05 78 f4 21 00         	movq	%rax, 0x21f478(%rip)    # 0x251b48 <__pyx_filename>
   326d0: c7 05 66 f4 21 00 99 01 00 00	movl	$0x199, 0x21f466(%rip)  # imm = 0x199
                                                                        # 0x251b40 <__pyx_lineno>
   326da: c7 05 60 f4 21 00 72 29 00 00	movl	$0x2972, 0x21f460(%rip) # imm = 0x2972
                                                                        # 0x251b44 <__pyx_clineno>
   326e4: e9 d0 0f 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   326e9: 48 8b 85 d8 fe ff ff         	movq	-0x128(%rbp), %rax
   326f0: 48 89 45 98                  	movq	%rax, -0x68(%rbp)
   326f4: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   326fb: 48 89 85 d8 fe ff ff         	movq	%rax, -0x128(%rbp)
   32702: 48 83 7d 98 00               	cmpq	$0x0, -0x68(%rbp)
   32707: 74 33                        	je	0x3273c <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x172d>
   32709: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   3270d: 48 8b 00                     	movq	(%rax), %rax
   32710: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   32714: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   32718: 48 89 10                     	movq	%rdx, (%rax)
   3271b: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   3271f: 48 8b 00                     	movq	(%rax), %rax
   32722: 48 85 c0                     	testq	%rax, %rax
   32725: 75 15                        	jne	0x3273c <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x172d>
   32727: 48 8b 45 98                  	movq	-0x68(%rbp), %rax
   3272b: 48 8b 40 08                  	movq	0x8(%rax), %rax
   3272f: 48 8b 40 30                  	movq	0x30(%rax), %rax
   32733: 48 8b 55 98                  	movq	-0x68(%rbp), %rdx
   32737: 48 89 d7                     	movq	%rdx, %rdi
   3273a: ff d0                        	callq	*%rax
   3273c: 48 c7 85 18 ff ff ff 00 00 00 00     	movq	$0x0, -0xe8(%rbp)
   32747: 48 8b 95 d8 fe ff ff         	movq	-0x128(%rbp), %rdx
   3274e: 48 8b 85 88 fe ff ff         	movq	-0x178(%rbp), %rax
   32755: 48 89 d6                     	movq	%rdx, %rsi
   32758: 48 89 c7                     	movq	%rax, %rdi
   3275b: e8 70 30 fd ff               	callq	0x57d0 <PyObject_GetItem@plt>
   32760: 48 89 85 18 ff ff ff         	movq	%rax, -0xe8(%rbp)
   32767: 48 83 bd 18 ff ff ff 00      	cmpq	$0x0, -0xe8(%rbp)
   3276f: 0f 94 c0                     	sete	%al
   32772: 0f b6 c0                     	movzbl	%al, %eax
   32775: 48 85 c0                     	testq	%rax, %rax
   32778: 74 27                        	je	0x327a1 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1792>
   3277a: 48 8b 05 67 cd 21 00         	movq	0x21cd67(%rip), %rax    # 0x24f4e8 <__pyx_f>
   32781: 48 89 05 c0 f3 21 00         	movq	%rax, 0x21f3c0(%rip)    # 0x251b48 <__pyx_filename>
   32788: c7 05 ae f3 21 00 9a 01 00 00	movl	$0x19a, 0x21f3ae(%rip)  # imm = 0x19A
                                                                        # 0x251b40 <__pyx_lineno>
   32792: c7 05 a8 f3 21 00 82 29 00 00	movl	$0x2982, 0x21f3a8(%rip) # imm = 0x2982
                                                                        # 0x251b44 <__pyx_clineno>
   3279c: e9 18 0f 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   327a1: 48 8b 85 e0 fe ff ff         	movq	-0x120(%rbp), %rax
   327a8: 48 89 45 a0                  	movq	%rax, -0x60(%rbp)
   327ac: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   327b3: 48 89 85 e0 fe ff ff         	movq	%rax, -0x120(%rbp)
   327ba: 48 83 7d a0 00               	cmpq	$0x0, -0x60(%rbp)
   327bf: 74 33                        	je	0x327f4 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x17e5>
   327c1: 48 8b 45 a0                  	movq	-0x60(%rbp), %rax
   327c5: 48 8b 00                     	movq	(%rax), %rax
   327c8: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   327cc: 48 8b 45 a0                  	movq	-0x60(%rbp), %rax
   327d0: 48 89 10                     	movq	%rdx, (%rax)
   327d3: 48 8b 45 a0                  	movq	-0x60(%rbp), %rax
   327d7: 48 8b 00                     	movq	(%rax), %rax
   327da: 48 85 c0                     	testq	%rax, %rax
   327dd: 75 15                        	jne	0x327f4 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x17e5>
   327df: 48 8b 45 a0                  	movq	-0x60(%rbp), %rax
   327e3: 48 8b 40 08                  	movq	0x8(%rax), %rax
   327e7: 48 8b 40 30                  	movq	0x30(%rax), %rax
   327eb: 48 8b 55 a0                  	movq	-0x60(%rbp), %rdx
   327ef: 48 89 d7                     	movq	%rdx, %rdi
   327f2: ff d0                        	callq	*%rax
   327f4: 48 c7 85 18 ff ff ff 00 00 00 00     	movq	$0x0, -0xe8(%rbp)
   327ff: 48 8b 95 d0 fe ff ff         	movq	-0x130(%rbp), %rdx
   32806: 48 8b 85 e0 fe ff ff         	movq	-0x120(%rbp), %rax
   3280d: 48 89 d6                     	movq	%rdx, %rsi
   32810: 48 89 c7                     	movq	%rax, %rdi
   32813: e8 58 33 fd ff               	callq	0x5b70 <PyNumber_Xor@plt>
   32818: 48 89 85 18 ff ff ff         	movq	%rax, -0xe8(%rbp)
   3281f: 48 83 bd 18 ff ff ff 00      	cmpq	$0x0, -0xe8(%rbp)
   32827: 0f 94 c0                     	sete	%al
   3282a: 0f b6 c0                     	movzbl	%al, %eax
   3282d: 48 85 c0                     	testq	%rax, %rax
   32830: 74 27                        	je	0x32859 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x184a>
   32832: 48 8b 05 af cc 21 00         	movq	0x21ccaf(%rip), %rax    # 0x24f4e8 <__pyx_f>
   32839: 48 89 05 08 f3 21 00         	movq	%rax, 0x21f308(%rip)    # 0x251b48 <__pyx_filename>
   32840: c7 05 f6 f2 21 00 9b 01 00 00	movl	$0x19b, 0x21f2f6(%rip)  # imm = 0x19B
                                                                        # 0x251b40 <__pyx_lineno>
   3284a: c7 05 f0 f2 21 00 8e 29 00 00	movl	$0x298e, 0x21f2f0(%rip) # imm = 0x298E
                                                                        # 0x251b44 <__pyx_clineno>
   32854: e9 60 0e 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   32859: 48 8b 85 e8 fe ff ff         	movq	-0x118(%rbp), %rax
   32860: 48 89 45 a8                  	movq	%rax, -0x58(%rbp)
   32864: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   3286b: 48 89 85 e8 fe ff ff         	movq	%rax, -0x118(%rbp)
   32872: 48 83 7d a8 00               	cmpq	$0x0, -0x58(%rbp)
   32877: 74 33                        	je	0x328ac <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x189d>
   32879: 48 8b 45 a8                  	movq	-0x58(%rbp), %rax
   3287d: 48 8b 00                     	movq	(%rax), %rax
   32880: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   32884: 48 8b 45 a8                  	movq	-0x58(%rbp), %rax
   32888: 48 89 10                     	movq	%rdx, (%rax)
   3288b: 48 8b 45 a8                  	movq	-0x58(%rbp), %rax
   3288f: 48 8b 00                     	movq	(%rax), %rax
   32892: 48 85 c0                     	testq	%rax, %rax
   32895: 75 15                        	jne	0x328ac <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x189d>
   32897: 48 8b 45 a8                  	movq	-0x58(%rbp), %rax
   3289b: 48 8b 40 08                  	movq	0x8(%rax), %rax
   3289f: 48 8b 40 30                  	movq	0x30(%rax), %rax
   328a3: 48 8b 55 a8                  	movq	-0x58(%rbp), %rdx
   328a7: 48 89 d7                     	movq	%rdx, %rdi
   328aa: ff d0                        	callq	*%rax
   328ac: 48 c7 85 18 ff ff ff 00 00 00 00     	movq	$0x0, -0xe8(%rbp)
   328b7: 48 8b 95 e8 fe ff ff         	movq	-0x118(%rbp), %rdx
   328be: 48 8b 8d d8 fe ff ff         	movq	-0x128(%rbp), %rcx
   328c5: 48 8b 85 88 fe ff ff         	movq	-0x178(%rbp), %rax
   328cc: 48 89 ce                     	movq	%rcx, %rsi
   328cf: 48 89 c7                     	movq	%rax, %rdi
   328d2: e8 49 2d fd ff               	callq	0x5620 <PyObject_SetItem@plt>
   328d7: c1 e8 1f                     	shrl	$0x1f, %eax
   328da: 0f b6 c0                     	movzbl	%al, %eax
   328dd: 48 85 c0                     	testq	%rax, %rax
   328e0: 74 27                        	je	0x32909 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x18fa>
   328e2: 48 8b 05 ff cb 21 00         	movq	0x21cbff(%rip), %rax    # 0x24f4e8 <__pyx_f>
   328e9: 48 89 05 58 f2 21 00         	movq	%rax, 0x21f258(%rip)    # 0x251b48 <__pyx_filename>
   328f0: c7 05 46 f2 21 00 9c 01 00 00	movl	$0x19c, 0x21f246(%rip)  # imm = 0x19C
                                                                        # 0x251b40 <__pyx_lineno>
   328fa: c7 05 40 f2 21 00 9a 29 00 00	movl	$0x299a, 0x21f240(%rip) # imm = 0x299A
                                                                        # 0x251b44 <__pyx_clineno>
   32904: e9 b0 0d 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   32909: 48 8b 15 c0 f5 21 00         	movq	0x21f5c0(%rip), %rdx    # 0x251ed0 <__pyx_n_s_gen_seed32>
   32910: 48 8b 85 90 fe ff ff         	movq	-0x170(%rbp), %rax
   32917: 48 89 d6                     	movq	%rdx, %rsi
   3291a: 48 89 c7                     	movq	%rax, %rdi
   3291d: e8 a8 33 fd ff               	callq	0x5cca <__Pyx_PyObject_GetAttrStr>
   32922: 48 89 85 00 ff ff ff         	movq	%rax, -0x100(%rbp)
   32929: 48 83 bd 00 ff ff ff 00      	cmpq	$0x0, -0x100(%rbp)
   32931: 0f 94 c0                     	sete	%al
   32934: 0f b6 c0                     	movzbl	%al, %eax
   32937: 48 85 c0                     	testq	%rax, %rax
   3293a: 74 27                        	je	0x32963 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1954>
   3293c: 48 8b 05 a5 cb 21 00         	movq	0x21cba5(%rip), %rax    # 0x24f4e8 <__pyx_f>
   32943: 48 89 05 fe f1 21 00         	movq	%rax, 0x21f1fe(%rip)    # 0x251b48 <__pyx_filename>
   3294a: c7 05 ec f1 21 00 9e 01 00 00	movl	$0x19e, 0x21f1ec(%rip)  # imm = 0x19E
                                                                        # 0x251b40 <__pyx_lineno>
   32954: c7 05 e6 f1 21 00 a3 29 00 00	movl	$0x29a3, 0x21f1e6(%rip) # imm = 0x29A3
                                                                        # 0x251b44 <__pyx_clineno>
   3295e: e9 56 0d 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   32963: 48 c7 85 38 ff ff ff 00 00 00 00     	movq	$0x0, -0xc8(%rbp)
   3296e: c7 85 a4 fe ff ff 00 00 00 00	movl	$0x0, -0x15c(%rbp)
   32978: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   3297f: 48 8b 40 08                  	movq	0x8(%rax), %rax
   32983: 48 8b 15 26 c5 21 00         	movq	0x21c526(%rip), %rdx    # 0x24eeb0 <memcmp@@GLIBC_2.2.5+0x24eeb0>
   3298a: 48 39 d0                     	cmpq	%rdx, %rax
   3298d: 0f 94 c0                     	sete	%al
   32990: 0f b6 c0                     	movzbl	%al, %eax
   32993: 48 85 c0                     	testq	%rax, %rax
   32996: 0f 84 b5 00 00 00            	je	0x32a51 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1a42>
   3299c: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   329a3: 48 8b 40 18                  	movq	0x18(%rax), %rax
   329a7: 48 89 85 38 ff ff ff         	movq	%rax, -0xc8(%rbp)
   329ae: 48 83 bd 38 ff ff ff 00      	cmpq	$0x0, -0xc8(%rbp)
   329b6: 0f 95 c0                     	setne	%al
   329b9: 0f b6 c0                     	movzbl	%al, %eax
   329bc: 48 85 c0                     	testq	%rax, %rax
   329bf: 0f 84 8c 00 00 00            	je	0x32a51 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1a42>
   329c5: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   329cc: 48 8b 40 10                  	movq	0x10(%rax), %rax
   329d0: 48 89 45 b0                  	movq	%rax, -0x50(%rbp)
   329d4: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   329db: 48 8b 00                     	movq	(%rax), %rax
   329de: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   329e2: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   329e9: 48 89 10                     	movq	%rdx, (%rax)
   329ec: 48 8b 45 b0                  	movq	-0x50(%rbp), %rax
   329f0: 48 8b 00                     	movq	(%rax), %rax
   329f3: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   329f7: 48 8b 45 b0                  	movq	-0x50(%rbp), %rax
   329fb: 48 89 10                     	movq	%rdx, (%rax)
   329fe: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   32a05: 48 89 45 b8                  	movq	%rax, -0x48(%rbp)
   32a09: 48 8b 45 b0                  	movq	-0x50(%rbp), %rax
   32a0d: 48 89 85 00 ff ff ff         	movq	%rax, -0x100(%rbp)
   32a14: 48 8b 45 b8                  	movq	-0x48(%rbp), %rax
   32a18: 48 8b 00                     	movq	(%rax), %rax
   32a1b: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   32a1f: 48 8b 45 b8                  	movq	-0x48(%rbp), %rax
   32a23: 48 89 10                     	movq	%rdx, (%rax)
   32a26: 48 8b 45 b8                  	movq	-0x48(%rbp), %rax
   32a2a: 48 8b 00                     	movq	(%rax), %rax
   32a2d: 48 85 c0                     	testq	%rax, %rax
   32a30: 75 15                        	jne	0x32a47 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1a38>
   32a32: 48 8b 45 b8                  	movq	-0x48(%rbp), %rax
   32a36: 48 8b 40 08                  	movq	0x8(%rax), %rax
   32a3a: 48 8b 40 30                  	movq	0x30(%rax), %rax
   32a3e: 48 8b 55 b8                  	movq	-0x48(%rbp), %rdx
   32a42: 48 89 d7                     	movq	%rdx, %rdi
   32a45: ff d0                        	callq	*%rax
   32a47: c7 85 a4 fe ff ff 01 00 00 00	movl	$0x1, -0x15c(%rbp)
   32a51: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   32a58: 48 8b 40 08                  	movq	0x8(%rax), %rax
   32a5c: 48 8b 15 0d c5 21 00         	movq	0x21c50d(%rip), %rdx    # 0x24ef70 <memcmp@@GLIBC_2.2.5+0x24ef70>
   32a63: 48 39 d0                     	cmpq	%rdx, %rax
   32a66: 0f 85 fc 00 00 00            	jne	0x32b68 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1b59>
   32a6c: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   32a73: 48 89 45 e0                  	movq	%rax, -0x20(%rbp)
   32a77: 48 8b 85 c8 fe ff ff         	movq	-0x138(%rbp), %rax
   32a7e: 48 89 45 e8                  	movq	%rax, -0x18(%rbp)
   32a82: 48 8b 85 e0 fe ff ff         	movq	-0x120(%rbp), %rax
   32a89: 48 89 45 f0                  	movq	%rax, -0x10(%rbp)
   32a8d: 8b 85 a4 fe ff ff            	movl	-0x15c(%rbp), %eax
   32a93: 8d 50 02                     	leal	0x2(%rax), %edx
   32a96: 8b 85 a4 fe ff ff            	movl	-0x15c(%rbp), %eax
   32a9c: 48 63 c8                     	movslq	%eax, %rcx
   32a9f: b8 00 00 00 00               	movl	$0x0, %eax
   32aa4: 48 29 c8                     	subq	%rcx, %rax
   32aa7: 48 c1 e0 03                  	shlq	$0x3, %rax
   32aab: 48 8d 48 08                  	leaq	0x8(%rax), %rcx
   32aaf: 48 8d 45 e0                  	leaq	-0x20(%rbp), %rax
   32ab3: 48 8d 34 08                  	leaq	(%rax,%rcx), %rsi
   32ab7: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   32abe: b9 00 00 00 00               	movl	$0x0, %ecx
   32ac3: 48 89 c7                     	movq	%rax, %rdi
   32ac6: e8 9e 36 01 00               	callq	0x46169 <__Pyx_PyFunction_FastCallDict>
   32acb: 48 89 85 18 ff ff ff         	movq	%rax, -0xe8(%rbp)
   32ad2: 48 83 bd 18 ff ff ff 00      	cmpq	$0x0, -0xe8(%rbp)
   32ada: 0f 94 c0                     	sete	%al
   32add: 0f b6 c0                     	movzbl	%al, %eax
   32ae0: 48 85 c0                     	testq	%rax, %rax
   32ae3: 74 27                        	je	0x32b0c <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1afd>
   32ae5: 48 8b 05 fc c9 21 00         	movq	0x21c9fc(%rip), %rax    # 0x24f4e8 <__pyx_f>
   32aec: 48 89 05 55 f0 21 00         	movq	%rax, 0x21f055(%rip)    # 0x251b48 <__pyx_filename>
   32af3: c7 05 43 f0 21 00 9e 01 00 00	movl	$0x19e, 0x21f043(%rip)  # imm = 0x19E
                                                                        # 0x251b40 <__pyx_lineno>
   32afd: c7 05 3d f0 21 00 b4 29 00 00	movl	$0x29b4, 0x21f03d(%rip) # imm = 0x29B4
                                                                        # 0x251b44 <__pyx_clineno>
   32b07: e9 ad 0b 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   32b0c: 48 83 bd 38 ff ff ff 00      	cmpq	$0x0, -0xc8(%rbp)
   32b14: 74 42                        	je	0x32b58 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1b49>
   32b16: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   32b1d: 48 8b 00                     	movq	(%rax), %rax
   32b20: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   32b24: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   32b2b: 48 89 10                     	movq	%rdx, (%rax)
   32b2e: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   32b35: 48 8b 00                     	movq	(%rax), %rax
   32b38: 48 85 c0                     	testq	%rax, %rax
   32b3b: 75 1b                        	jne	0x32b58 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1b49>
   32b3d: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   32b44: 48 8b 40 08                  	movq	0x8(%rax), %rax
   32b48: 48 8b 40 30                  	movq	0x30(%rax), %rax
   32b4c: 48 8b 95 38 ff ff ff         	movq	-0xc8(%rbp), %rdx
   32b53: 48 89 d7                     	movq	%rdx, %rdi
   32b56: ff d0                        	callq	*%rax
   32b58: 48 c7 85 38 ff ff ff 00 00 00 00     	movq	$0x0, -0xc8(%rbp)
   32b63: e9 9a 01 00 00               	jmp	0x32d02 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1cf3>
   32b68: 8b 85 a4 fe ff ff            	movl	-0x15c(%rbp), %eax
   32b6e: 83 c0 02                     	addl	$0x2, %eax
   32b71: 48 98                        	cltq
   32b73: 48 89 c7                     	movq	%rax, %rdi
   32b76: e8 d5 2d fd ff               	callq	0x5950 <PyTuple_New@plt>
   32b7b: 48 89 85 40 ff ff ff         	movq	%rax, -0xc0(%rbp)
   32b82: 48 83 bd 40 ff ff ff 00      	cmpq	$0x0, -0xc0(%rbp)
   32b8a: 0f 94 c0                     	sete	%al
   32b8d: 0f b6 c0                     	movzbl	%al, %eax
   32b90: 48 85 c0                     	testq	%rax, %rax
   32b93: 74 27                        	je	0x32bbc <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1bad>
   32b95: 48 8b 05 4c c9 21 00         	movq	0x21c94c(%rip), %rax    # 0x24f4e8 <__pyx_f>
   32b9c: 48 89 05 a5 ef 21 00         	movq	%rax, 0x21efa5(%rip)    # 0x251b48 <__pyx_filename>
   32ba3: c7 05 93 ef 21 00 9e 01 00 00	movl	$0x19e, 0x21ef93(%rip)  # imm = 0x19E
                                                                        # 0x251b40 <__pyx_lineno>
   32bad: c7 05 8d ef 21 00 c2 29 00 00	movl	$0x29c2, 0x21ef8d(%rip) # imm = 0x29C2
                                                                        # 0x251b44 <__pyx_clineno>
   32bb7: e9 fd 0a 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   32bbc: 48 83 bd 38 ff ff ff 00      	cmpq	$0x0, -0xc8(%rbp)
   32bc4: 74 1d                        	je	0x32be3 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1bd4>
   32bc6: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   32bcd: 48 8b 95 38 ff ff ff         	movq	-0xc8(%rbp), %rdx
   32bd4: 48 89 50 18                  	movq	%rdx, 0x18(%rax)
   32bd8: 48 c7 85 38 ff ff ff 00 00 00 00     	movq	$0x0, -0xc8(%rbp)
   32be3: 48 8b 85 c8 fe ff ff         	movq	-0x138(%rbp), %rax
   32bea: 48 8b 00                     	movq	(%rax), %rax
   32bed: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   32bf1: 48 8b 85 c8 fe ff ff         	movq	-0x138(%rbp), %rax
   32bf8: 48 89 10                     	movq	%rdx, (%rax)
   32bfb: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   32c02: 8b 95 a4 fe ff ff            	movl	-0x15c(%rbp), %edx
   32c08: 48 63 d2                     	movslq	%edx, %rdx
   32c0b: 48 8d 4a 02                  	leaq	0x2(%rdx), %rcx
   32c0f: 48 8b 95 c8 fe ff ff         	movq	-0x138(%rbp), %rdx
   32c16: 48 89 54 c8 08               	movq	%rdx, 0x8(%rax,%rcx,8)
   32c1b: 48 8b 85 e0 fe ff ff         	movq	-0x120(%rbp), %rax
   32c22: 48 8b 00                     	movq	(%rax), %rax
   32c25: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   32c29: 48 8b 85 e0 fe ff ff         	movq	-0x120(%rbp), %rax
   32c30: 48 89 10                     	movq	%rdx, (%rax)
   32c33: 8b 85 a4 fe ff ff            	movl	-0x15c(%rbp), %eax
   32c39: 8d 50 01                     	leal	0x1(%rax), %edx
   32c3c: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   32c43: 48 63 d2                     	movslq	%edx, %rdx
   32c46: 48 8d 4a 02                  	leaq	0x2(%rdx), %rcx
   32c4a: 48 8b 95 e0 fe ff ff         	movq	-0x120(%rbp), %rdx
   32c51: 48 89 54 c8 08               	movq	%rdx, 0x8(%rax,%rcx,8)
   32c56: 48 8b 8d 40 ff ff ff         	movq	-0xc0(%rbp), %rcx
   32c5d: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   32c64: ba 00 00 00 00               	movl	$0x0, %edx
   32c69: 48 89 ce                     	movq	%rcx, %rsi
   32c6c: 48 89 c7                     	movq	%rax, %rdi
   32c6f: e8 b2 38 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   32c74: 48 89 85 18 ff ff ff         	movq	%rax, -0xe8(%rbp)
   32c7b: 48 83 bd 18 ff ff ff 00      	cmpq	$0x0, -0xe8(%rbp)
   32c83: 0f 94 c0                     	sete	%al
   32c86: 0f b6 c0                     	movzbl	%al, %eax
   32c89: 48 85 c0                     	testq	%rax, %rax
   32c8c: 74 27                        	je	0x32cb5 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1ca6>
   32c8e: 48 8b 05 53 c8 21 00         	movq	0x21c853(%rip), %rax    # 0x24f4e8 <__pyx_f>
   32c95: 48 89 05 ac ee 21 00         	movq	%rax, 0x21eeac(%rip)    # 0x251b48 <__pyx_filename>
   32c9c: c7 05 9a ee 21 00 9e 01 00 00	movl	$0x19e, 0x21ee9a(%rip)  # imm = 0x19E
                                                                        # 0x251b40 <__pyx_lineno>
   32ca6: c7 05 94 ee 21 00 cd 29 00 00	movl	$0x29cd, 0x21ee94(%rip) # imm = 0x29CD
                                                                        # 0x251b44 <__pyx_clineno>
   32cb0: e9 04 0a 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   32cb5: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   32cbc: 48 8b 00                     	movq	(%rax), %rax
   32cbf: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   32cc3: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   32cca: 48 89 10                     	movq	%rdx, (%rax)
   32ccd: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   32cd4: 48 8b 00                     	movq	(%rax), %rax
   32cd7: 48 85 c0                     	testq	%rax, %rax
   32cda: 75 1b                        	jne	0x32cf7 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1ce8>
   32cdc: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   32ce3: 48 8b 40 08                  	movq	0x8(%rax), %rax
   32ce7: 48 8b 40 30                  	movq	0x30(%rax), %rax
   32ceb: 48 8b 95 40 ff ff ff         	movq	-0xc0(%rbp), %rdx
   32cf2: 48 89 d7                     	movq	%rdx, %rdi
   32cf5: ff d0                        	callq	*%rax
   32cf7: 48 c7 85 40 ff ff ff 00 00 00 00     	movq	$0x0, -0xc0(%rbp)
   32d02: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   32d09: 48 8b 00                     	movq	(%rax), %rax
   32d0c: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   32d10: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   32d17: 48 89 10                     	movq	%rdx, (%rax)
   32d1a: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   32d21: 48 8b 00                     	movq	(%rax), %rax
   32d24: 48 85 c0                     	testq	%rax, %rax
   32d27: 75 1b                        	jne	0x32d44 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1d35>
   32d29: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   32d30: 48 8b 40 08                  	movq	0x8(%rax), %rax
   32d34: 48 8b 40 30                  	movq	0x30(%rax), %rax
   32d38: 48 8b 95 00 ff ff ff         	movq	-0x100(%rbp), %rdx
   32d3f: 48 89 d7                     	movq	%rdx, %rdi
   32d42: ff d0                        	callq	*%rax
   32d44: 48 c7 85 00 ff ff ff 00 00 00 00     	movq	$0x0, -0x100(%rbp)
   32d4f: 48 8b 85 c8 fe ff ff         	movq	-0x138(%rbp), %rax
   32d56: 48 89 45 c0                  	movq	%rax, -0x40(%rbp)
   32d5a: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   32d61: 48 89 85 c8 fe ff ff         	movq	%rax, -0x138(%rbp)
   32d68: 48 8b 45 c0                  	movq	-0x40(%rbp), %rax
   32d6c: 48 8b 00                     	movq	(%rax), %rax
   32d6f: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   32d73: 48 8b 45 c0                  	movq	-0x40(%rbp), %rax
   32d77: 48 89 10                     	movq	%rdx, (%rax)
   32d7a: 48 8b 45 c0                  	movq	-0x40(%rbp), %rax
   32d7e: 48 8b 00                     	movq	(%rax), %rax
   32d81: 48 85 c0                     	testq	%rax, %rax
   32d84: 75 15                        	jne	0x32d9b <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1d8c>
   32d86: 48 8b 45 c0                  	movq	-0x40(%rbp), %rax
   32d8a: 48 8b 40 08                  	movq	0x8(%rax), %rax
   32d8e: 48 8b 40 30                  	movq	0x30(%rax), %rax
   32d92: 48 8b 55 c0                  	movq	-0x40(%rbp), %rdx
   32d96: 48 89 d7                     	movq	%rdx, %rdi
   32d99: ff d0                        	callq	*%rax
   32d9b: 48 c7 85 18 ff ff ff 00 00 00 00     	movq	$0x0, -0xe8(%rbp)
   32da6: 48 8b 15 2b f1 21 00         	movq	0x21f12b(%rip), %rdx    # 0x251ed8 <__pyx_n_s_gen_seed8>
   32dad: 48 8b 85 90 fe ff ff         	movq	-0x170(%rbp), %rax
   32db4: 48 89 d6                     	movq	%rdx, %rsi
   32db7: 48 89 c7                     	movq	%rax, %rdi
   32dba: e8 0b 2f fd ff               	callq	0x5cca <__Pyx_PyObject_GetAttrStr>
   32dbf: 48 89 85 00 ff ff ff         	movq	%rax, -0x100(%rbp)
   32dc6: 48 83 bd 00 ff ff ff 00      	cmpq	$0x0, -0x100(%rbp)
   32dce: 0f 94 c0                     	sete	%al
   32dd1: 0f b6 c0                     	movzbl	%al, %eax
   32dd4: 48 85 c0                     	testq	%rax, %rax
   32dd7: 74 27                        	je	0x32e00 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1df1>
   32dd9: 48 8b 05 08 c7 21 00         	movq	0x21c708(%rip), %rax    # 0x24f4e8 <__pyx_f>
   32de0: 48 89 05 61 ed 21 00         	movq	%rax, 0x21ed61(%rip)    # 0x251b48 <__pyx_filename>
   32de7: c7 05 4f ed 21 00 9f 01 00 00	movl	$0x19f, 0x21ed4f(%rip)  # imm = 0x19F
                                                                        # 0x251b40 <__pyx_lineno>
   32df1: c7 05 49 ed 21 00 dc 29 00 00	movl	$0x29dc, 0x21ed49(%rip) # imm = 0x29DC
                                                                        # 0x251b44 <__pyx_clineno>
   32dfb: e9 b9 08 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   32e00: 48 c7 85 40 ff ff ff 00 00 00 00     	movq	$0x0, -0xc0(%rbp)
   32e0b: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   32e12: 48 8b 40 08                  	movq	0x8(%rax), %rax
   32e16: 48 8b 15 93 c0 21 00         	movq	0x21c093(%rip), %rdx    # 0x24eeb0 <memcmp@@GLIBC_2.2.5+0x24eeb0>
   32e1d: 48 39 d0                     	cmpq	%rdx, %rax
   32e20: 0f 94 c0                     	sete	%al
   32e23: 0f b6 c0                     	movzbl	%al, %eax
   32e26: 48 85 c0                     	testq	%rax, %rax
   32e29: 0f 84 ab 00 00 00            	je	0x32eda <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1ecb>
   32e2f: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   32e36: 48 8b 40 18                  	movq	0x18(%rax), %rax
   32e3a: 48 89 85 40 ff ff ff         	movq	%rax, -0xc0(%rbp)
   32e41: 48 83 bd 40 ff ff ff 00      	cmpq	$0x0, -0xc0(%rbp)
   32e49: 0f 95 c0                     	setne	%al
   32e4c: 0f b6 c0                     	movzbl	%al, %eax
   32e4f: 48 85 c0                     	testq	%rax, %rax
   32e52: 0f 84 82 00 00 00            	je	0x32eda <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1ecb>
   32e58: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   32e5f: 48 8b 40 10                  	movq	0x10(%rax), %rax
   32e63: 48 89 45 c8                  	movq	%rax, -0x38(%rbp)
   32e67: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   32e6e: 48 8b 00                     	movq	(%rax), %rax
   32e71: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   32e75: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   32e7c: 48 89 10                     	movq	%rdx, (%rax)
   32e7f: 48 8b 45 c8                  	movq	-0x38(%rbp), %rax
   32e83: 48 8b 00                     	movq	(%rax), %rax
   32e86: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   32e8a: 48 8b 45 c8                  	movq	-0x38(%rbp), %rax
   32e8e: 48 89 10                     	movq	%rdx, (%rax)
   32e91: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   32e98: 48 89 45 d0                  	movq	%rax, -0x30(%rbp)
   32e9c: 48 8b 45 c8                  	movq	-0x38(%rbp), %rax
   32ea0: 48 89 85 00 ff ff ff         	movq	%rax, -0x100(%rbp)
   32ea7: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
   32eab: 48 8b 00                     	movq	(%rax), %rax
   32eae: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   32eb2: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
   32eb6: 48 89 10                     	movq	%rdx, (%rax)
   32eb9: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
   32ebd: 48 8b 00                     	movq	(%rax), %rax
   32ec0: 48 85 c0                     	testq	%rax, %rax
   32ec3: 75 15                        	jne	0x32eda <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1ecb>
   32ec5: 48 8b 45 d0                  	movq	-0x30(%rbp), %rax
   32ec9: 48 8b 40 08                  	movq	0x8(%rax), %rax
   32ecd: 48 8b 40 30                  	movq	0x30(%rax), %rax
   32ed1: 48 8b 55 d0                  	movq	-0x30(%rbp), %rdx
   32ed5: 48 89 d7                     	movq	%rdx, %rdi
   32ed8: ff d0                        	callq	*%rax
   32eda: 48 83 bd 40 ff ff ff 00      	cmpq	$0x0, -0xc0(%rbp)
   32ee2: 75 5e                        	jne	0x32f42 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1f33>
   32ee4: 48 8b 95 c8 fe ff ff         	movq	-0x138(%rbp), %rdx
   32eeb: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   32ef2: 48 89 d6                     	movq	%rdx, %rsi
   32ef5: 48 89 c7                     	movq	%rax, %rdi
   32ef8: e8 c3 38 01 00               	callq	0x467c0 <__Pyx_PyObject_CallOneArg>
   32efd: 48 89 85 18 ff ff ff         	movq	%rax, -0xe8(%rbp)
   32f04: 48 83 bd 18 ff ff ff 00      	cmpq	$0x0, -0xe8(%rbp)
   32f0c: 0f 94 c0                     	sete	%al
   32f0f: 0f b6 c0                     	movzbl	%al, %eax
   32f12: 48 85 c0                     	testq	%rax, %rax
   32f15: 0f 84 50 02 00 00            	je	0x3316b <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x215c>
   32f1b: 48 8b 05 c6 c5 21 00         	movq	0x21c5c6(%rip), %rax    # 0x24f4e8 <__pyx_f>
   32f22: 48 89 05 1f ec 21 00         	movq	%rax, 0x21ec1f(%rip)    # 0x251b48 <__pyx_filename>
   32f29: c7 05 0d ec 21 00 9f 01 00 00	movl	$0x19f, 0x21ec0d(%rip)  # imm = 0x19F
                                                                        # 0x251b40 <__pyx_lineno>
   32f33: c7 05 07 ec 21 00 e9 29 00 00	movl	$0x29e9, 0x21ec07(%rip) # imm = 0x29E9
                                                                        # 0x251b44 <__pyx_clineno>
   32f3d: e9 77 07 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   32f42: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   32f49: 48 8b 40 08                  	movq	0x8(%rax), %rax
   32f4d: 48 8b 15 1c c0 21 00         	movq	0x21c01c(%rip), %rdx    # 0x24ef70 <memcmp@@GLIBC_2.2.5+0x24ef70>
   32f54: 48 39 d0                     	cmpq	%rdx, %rax
   32f57: 0f 85 d0 00 00 00            	jne	0x3302d <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x201e>
   32f5d: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   32f64: 48 89 45 e0                  	movq	%rax, -0x20(%rbp)
   32f68: 48 8b 85 c8 fe ff ff         	movq	-0x138(%rbp), %rax
   32f6f: 48 89 45 e8                  	movq	%rax, -0x18(%rbp)
   32f73: 48 8d 75 e0                  	leaq	-0x20(%rbp), %rsi
   32f77: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   32f7e: b9 00 00 00 00               	movl	$0x0, %ecx
   32f83: ba 02 00 00 00               	movl	$0x2, %edx
   32f88: 48 89 c7                     	movq	%rax, %rdi
   32f8b: e8 d9 31 01 00               	callq	0x46169 <__Pyx_PyFunction_FastCallDict>
   32f90: 48 89 85 18 ff ff ff         	movq	%rax, -0xe8(%rbp)
   32f97: 48 83 bd 18 ff ff ff 00      	cmpq	$0x0, -0xe8(%rbp)
   32f9f: 0f 94 c0                     	sete	%al
   32fa2: 0f b6 c0                     	movzbl	%al, %eax
   32fa5: 48 85 c0                     	testq	%rax, %rax
   32fa8: 74 27                        	je	0x32fd1 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1fc2>
   32faa: 48 8b 05 37 c5 21 00         	movq	0x21c537(%rip), %rax    # 0x24f4e8 <__pyx_f>
   32fb1: 48 89 05 90 eb 21 00         	movq	%rax, 0x21eb90(%rip)    # 0x251b48 <__pyx_filename>
   32fb8: c7 05 7e eb 21 00 9f 01 00 00	movl	$0x19f, 0x21eb7e(%rip)  # imm = 0x19F
                                                                        # 0x251b40 <__pyx_lineno>
   32fc2: c7 05 78 eb 21 00 ef 29 00 00	movl	$0x29ef, 0x21eb78(%rip) # imm = 0x29EF
                                                                        # 0x251b44 <__pyx_clineno>
   32fcc: e9 e8 06 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   32fd1: 48 83 bd 40 ff ff ff 00      	cmpq	$0x0, -0xc0(%rbp)
   32fd9: 74 42                        	je	0x3301d <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x200e>
   32fdb: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   32fe2: 48 8b 00                     	movq	(%rax), %rax
   32fe5: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   32fe9: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   32ff0: 48 89 10                     	movq	%rdx, (%rax)
   32ff3: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   32ffa: 48 8b 00                     	movq	(%rax), %rax
   32ffd: 48 85 c0                     	testq	%rax, %rax
   33000: 75 1b                        	jne	0x3301d <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x200e>
   33002: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   33009: 48 8b 40 08                  	movq	0x8(%rax), %rax
   3300d: 48 8b 40 30                  	movq	0x30(%rax), %rax
   33011: 48 8b 95 40 ff ff ff         	movq	-0xc0(%rbp), %rdx
   33018: 48 89 d7                     	movq	%rdx, %rdi
   3301b: ff d0                        	callq	*%rax
   3301d: 48 c7 85 40 ff ff ff 00 00 00 00     	movq	$0x0, -0xc0(%rbp)
   33028: e9 3e 01 00 00               	jmp	0x3316b <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x215c>
   3302d: bf 02 00 00 00               	movl	$0x2, %edi
   33032: e8 19 29 fd ff               	callq	0x5950 <PyTuple_New@plt>
   33037: 48 89 85 38 ff ff ff         	movq	%rax, -0xc8(%rbp)
   3303e: 48 83 bd 38 ff ff ff 00      	cmpq	$0x0, -0xc8(%rbp)
   33046: 0f 94 c0                     	sete	%al
   33049: 0f b6 c0                     	movzbl	%al, %eax
   3304c: 48 85 c0                     	testq	%rax, %rax
   3304f: 74 27                        	je	0x33078 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2069>
   33051: 48 8b 05 90 c4 21 00         	movq	0x21c490(%rip), %rax    # 0x24f4e8 <__pyx_f>
   33058: 48 89 05 e9 ea 21 00         	movq	%rax, 0x21eae9(%rip)    # 0x251b48 <__pyx_filename>
   3305f: c7 05 d7 ea 21 00 9f 01 00 00	movl	$0x19f, 0x21ead7(%rip)  # imm = 0x19F
                                                                        # 0x251b40 <__pyx_lineno>
   33069: c7 05 d1 ea 21 00 fd 29 00 00	movl	$0x29fd, 0x21ead1(%rip) # imm = 0x29FD
                                                                        # 0x251b44 <__pyx_clineno>
   33073: e9 41 06 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   33078: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   3307f: 48 8b 95 40 ff ff ff         	movq	-0xc0(%rbp), %rdx
   33086: 48 89 50 18                  	movq	%rdx, 0x18(%rax)
   3308a: 48 c7 85 40 ff ff ff 00 00 00 00     	movq	$0x0, -0xc0(%rbp)
   33095: 48 8b 85 c8 fe ff ff         	movq	-0x138(%rbp), %rax
   3309c: 48 8b 00                     	movq	(%rax), %rax
   3309f: 48 8d 50 01                  	leaq	0x1(%rax), %rdx
   330a3: 48 8b 85 c8 fe ff ff         	movq	-0x138(%rbp), %rax
   330aa: 48 89 10                     	movq	%rdx, (%rax)
   330ad: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   330b4: 48 8b 95 c8 fe ff ff         	movq	-0x138(%rbp), %rdx
   330bb: 48 89 50 20                  	movq	%rdx, 0x20(%rax)
   330bf: 48 8b 8d 38 ff ff ff         	movq	-0xc8(%rbp), %rcx
   330c6: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   330cd: ba 00 00 00 00               	movl	$0x0, %edx
   330d2: 48 89 ce                     	movq	%rcx, %rsi
   330d5: 48 89 c7                     	movq	%rax, %rdi
   330d8: e8 49 34 01 00               	callq	0x46526 <__Pyx_PyObject_Call>
   330dd: 48 89 85 18 ff ff ff         	movq	%rax, -0xe8(%rbp)
   330e4: 48 83 bd 18 ff ff ff 00      	cmpq	$0x0, -0xe8(%rbp)
   330ec: 0f 94 c0                     	sete	%al
   330ef: 0f b6 c0                     	movzbl	%al, %eax
   330f2: 48 85 c0                     	testq	%rax, %rax
   330f5: 74 27                        	je	0x3311e <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x210f>
   330f7: 48 8b 05 ea c3 21 00         	movq	0x21c3ea(%rip), %rax    # 0x24f4e8 <__pyx_f>
   330fe: 48 89 05 43 ea 21 00         	movq	%rax, 0x21ea43(%rip)    # 0x251b48 <__pyx_filename>
   33105: c7 05 31 ea 21 00 9f 01 00 00	movl	$0x19f, 0x21ea31(%rip)  # imm = 0x19F
                                                                        # 0x251b40 <__pyx_lineno>
   3310f: c7 05 2b ea 21 00 03 2a 00 00	movl	$0x2a03, 0x21ea2b(%rip) # imm = 0x2A03
                                                                        # 0x251b44 <__pyx_clineno>
   33119: e9 9b 05 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   3311e: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   33125: 48 8b 00                     	movq	(%rax), %rax
   33128: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   3312c: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   33133: 48 89 10                     	movq	%rdx, (%rax)
   33136: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   3313d: 48 8b 00                     	movq	(%rax), %rax
   33140: 48 85 c0                     	testq	%rax, %rax
   33143: 75 1b                        	jne	0x33160 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2151>
   33145: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   3314c: 48 8b 40 08                  	movq	0x8(%rax), %rax
   33150: 48 8b 40 30                  	movq	0x30(%rax), %rax
   33154: 48 8b 95 38 ff ff ff         	movq	-0xc8(%rbp), %rdx
   3315b: 48 89 d7                     	movq	%rdx, %rdi
   3315e: ff d0                        	callq	*%rax
   33160: 48 c7 85 38 ff ff ff 00 00 00 00     	movq	$0x0, -0xc8(%rbp)
   3316b: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   33172: 48 8b 00                     	movq	(%rax), %rax
   33175: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   33179: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   33180: 48 89 10                     	movq	%rdx, (%rax)
   33183: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   3318a: 48 8b 00                     	movq	(%rax), %rax
   3318d: 48 85 c0                     	testq	%rax, %rax
   33190: 75 1b                        	jne	0x331ad <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x219e>
   33192: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   33199: 48 8b 40 08                  	movq	0x8(%rax), %rax
   3319d: 48 8b 40 30                  	movq	0x30(%rax), %rax
   331a1: 48 8b 95 00 ff ff ff         	movq	-0x100(%rbp), %rdx
   331a8: 48 89 d7                     	movq	%rdx, %rdi
   331ab: ff d0                        	callq	*%rax
   331ad: 48 c7 85 00 ff ff ff 00 00 00 00     	movq	$0x0, -0x100(%rbp)
   331b8: 48 8b 85 d0 fe ff ff         	movq	-0x130(%rbp), %rax
   331bf: 48 89 45 d8                  	movq	%rax, -0x28(%rbp)
   331c3: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   331ca: 48 89 85 d0 fe ff ff         	movq	%rax, -0x130(%rbp)
   331d1: 48 8b 45 d8                  	movq	-0x28(%rbp), %rax
   331d5: 48 8b 00                     	movq	(%rax), %rax
   331d8: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   331dc: 48 8b 45 d8                  	movq	-0x28(%rbp), %rax
   331e0: 48 89 10                     	movq	%rdx, (%rax)
   331e3: 48 8b 45 d8                  	movq	-0x28(%rbp), %rax
   331e7: 48 8b 00                     	movq	(%rax), %rax
   331ea: 48 85 c0                     	testq	%rax, %rax
   331ed: 75 15                        	jne	0x33204 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x21f5>
   331ef: 48 8b 45 d8                  	movq	-0x28(%rbp), %rax
   331f3: 48 8b 40 08                  	movq	0x8(%rax), %rax
   331f7: 48 8b 40 30                  	movq	0x30(%rax), %rax
   331fb: 48 8b 55 d8                  	movq	-0x28(%rbp), %rdx
   331ff: 48 89 d7                     	movq	%rdx, %rdi
   33202: ff d0                        	callq	*%rax
   33204: 48 c7 85 18 ff ff ff 00 00 00 00     	movq	$0x0, -0xe8(%rbp)
   3320f: e9 2e f3 ff ff               	jmp	0x32542 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x1533>
   33214: 90                           	nop
   33215: eb 04                        	jmp	0x3321b <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x220c>
   33217: 90                           	nop
   33218: eb 01                        	jmp	0x3321b <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x220c>
   3321a: 90                           	nop
   3321b: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   33222: 48 8b 00                     	movq	(%rax), %rax
   33225: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   33229: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   33230: 48 89 10                     	movq	%rdx, (%rax)
   33233: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   3323a: 48 8b 00                     	movq	(%rax), %rax
   3323d: 48 85 c0                     	testq	%rax, %rax
   33240: 75 1b                        	jne	0x3325d <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x224e>
   33242: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   33249: 48 8b 40 08                  	movq	0x8(%rax), %rax
   3324d: 48 8b 40 30                  	movq	0x30(%rax), %rax
   33251: 48 8b 95 f8 fe ff ff         	movq	-0x108(%rbp), %rdx
   33258: 48 89 d7                     	movq	%rdx, %rdi
   3325b: ff d0                        	callq	*%rax
   3325d: 48 c7 85 f8 fe ff ff 00 00 00 00     	movq	$0x0, -0x108(%rbp)
   33268: 48 83 bd d8 fe ff ff 00      	cmpq	$0x0, -0x128(%rbp)
   33270: 0f 94 c0                     	sete	%al
   33273: 0f b6 c0                     	movzbl	%al, %eax
   33276: 48 85 c0                     	testq	%rax, %rax
   33279: 74 33                        	je	0x332ae <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x229f>
   3327b: 48 8d 3d 9e 93 01 00         	leaq	0x1939e(%rip), %rdi     # 0x4c620 <__pyx_k_BaseEfuse___dict_string_parse+0x240>
   33282: e8 e7 54 01 00               	callq	0x4876e <__Pyx_RaiseUnboundLocalError>
   33287: 48 8b 05 5a c2 21 00         	movq	0x21c25a(%rip), %rax    # 0x24f4e8 <__pyx_f>
   3328e: 48 89 05 b3 e8 21 00         	movq	%rax, 0x21e8b3(%rip)    # 0x251b48 <__pyx_filename>
   33295: c7 05 a1 e8 21 00 a1 01 00 00	movl	$0x1a1, 0x21e8a1(%rip)  # imm = 0x1A1
                                                                        # 0x251b40 <__pyx_lineno>
   3329f: c7 05 9b e8 21 00 1d 2a 00 00	movl	$0x2a1d, 0x21e89b(%rip) # imm = 0x2A1D
                                                                        # 0x251b44 <__pyx_clineno>
   332a9: e9 0b 04 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   332ae: 48 8b 35 93 ee 21 00         	movq	0x21ee93(%rip), %rsi    # 0x252148 <__pyx_int_1>
   332b5: 48 8b 85 d8 fe ff ff         	movq	-0x128(%rbp), %rax
   332bc: b9 00 00 00 00               	movl	$0x0, %ecx
   332c1: ba 01 00 00 00               	movl	$0x1, %edx
   332c6: 48 89 c7                     	movq	%rax, %rdi
   332c9: e8 c6 3e 01 00               	callq	0x47194 <__Pyx_PyInt_AddObjC>
   332ce: 48 89 85 f8 fe ff ff         	movq	%rax, -0x108(%rbp)
   332d5: 48 83 bd f8 fe ff ff 00      	cmpq	$0x0, -0x108(%rbp)
   332dd: 0f 94 c0                     	sete	%al
   332e0: 0f b6 c0                     	movzbl	%al, %eax
   332e3: 48 85 c0                     	testq	%rax, %rax
   332e6: 74 27                        	je	0x3330f <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2300>
   332e8: 48 8b 05 f9 c1 21 00         	movq	0x21c1f9(%rip), %rax    # 0x24f4e8 <__pyx_f>
   332ef: 48 89 05 52 e8 21 00         	movq	%rax, 0x21e852(%rip)    # 0x251b48 <__pyx_filename>
   332f6: c7 05 40 e8 21 00 a1 01 00 00	movl	$0x1a1, 0x21e840(%rip)  # imm = 0x1A1
                                                                        # 0x251b40 <__pyx_lineno>
   33300: c7 05 3a e8 21 00 1e 2a 00 00	movl	$0x2a1e, 0x21e83a(%rip) # imm = 0x2A1E
                                                                        # 0x251b44 <__pyx_clineno>
   3330a: e9 aa 03 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   3330f: 48 8b 95 f8 fe ff ff         	movq	-0x108(%rbp), %rdx
   33316: 48 8b 85 88 fe ff ff         	movq	-0x178(%rbp), %rax
   3331d: 48 89 d6                     	movq	%rdx, %rsi
   33320: 48 89 c7                     	movq	%rax, %rdi
   33323: e8 a8 24 fd ff               	callq	0x57d0 <PyObject_GetItem@plt>
   33328: 48 89 85 18 ff ff ff         	movq	%rax, -0xe8(%rbp)
   3332f: 48 83 bd 18 ff ff ff 00      	cmpq	$0x0, -0xe8(%rbp)
   33337: 0f 94 c0                     	sete	%al
   3333a: 0f b6 c0                     	movzbl	%al, %eax
   3333d: 48 85 c0                     	testq	%rax, %rax
   33340: 74 27                        	je	0x33369 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x235a>
   33342: 48 8b 05 9f c1 21 00         	movq	0x21c19f(%rip), %rax    # 0x24f4e8 <__pyx_f>
   33349: 48 89 05 f8 e7 21 00         	movq	%rax, 0x21e7f8(%rip)    # 0x251b48 <__pyx_filename>
   33350: c7 05 e6 e7 21 00 a1 01 00 00	movl	$0x1a1, 0x21e7e6(%rip)  # imm = 0x1A1
                                                                        # 0x251b40 <__pyx_lineno>
   3335a: c7 05 e0 e7 21 00 20 2a 00 00	movl	$0x2a20, 0x21e7e0(%rip) # imm = 0x2A20
                                                                        # 0x251b44 <__pyx_clineno>
   33364: e9 50 03 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   33369: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   33370: 48 8b 00                     	movq	(%rax), %rax
   33373: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   33377: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   3337e: 48 89 10                     	movq	%rdx, (%rax)
   33381: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   33388: 48 8b 00                     	movq	(%rax), %rax
   3338b: 48 85 c0                     	testq	%rax, %rax
   3338e: 75 1b                        	jne	0x333ab <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x239c>
   33390: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   33397: 48 8b 40 08                  	movq	0x8(%rax), %rax
   3339b: 48 8b 40 30                  	movq	0x30(%rax), %rax
   3339f: 48 8b 95 f8 fe ff ff         	movq	-0x108(%rbp), %rdx
   333a6: 48 89 d7                     	movq	%rdx, %rdi
   333a9: ff d0                        	callq	*%rax
   333ab: 48 c7 85 f8 fe ff ff 00 00 00 00     	movq	$0x0, -0x108(%rbp)
   333b6: 48 8b 95 d0 fe ff ff         	movq	-0x130(%rbp), %rdx
   333bd: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   333c4: 48 89 d6                     	movq	%rdx, %rsi
   333c7: 48 89 c7                     	movq	%rax, %rdi
   333ca: e8 a1 27 fd ff               	callq	0x5b70 <PyNumber_Xor@plt>
   333cf: 48 89 85 f8 fe ff ff         	movq	%rax, -0x108(%rbp)
   333d6: 48 83 bd f8 fe ff ff 00      	cmpq	$0x0, -0x108(%rbp)
   333de: 0f 94 c0                     	sete	%al
   333e1: 0f b6 c0                     	movzbl	%al, %eax
   333e4: 48 85 c0                     	testq	%rax, %rax
   333e7: 74 27                        	je	0x33410 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2401>
   333e9: 48 8b 05 f8 c0 21 00         	movq	0x21c0f8(%rip), %rax    # 0x24f4e8 <__pyx_f>
   333f0: 48 89 05 51 e7 21 00         	movq	%rax, 0x21e751(%rip)    # 0x251b48 <__pyx_filename>
   333f7: c7 05 3f e7 21 00 a1 01 00 00	movl	$0x1a1, 0x21e73f(%rip)  # imm = 0x1A1
                                                                        # 0x251b40 <__pyx_lineno>
   33401: c7 05 39 e7 21 00 23 2a 00 00	movl	$0x2a23, 0x21e739(%rip) # imm = 0x2A23
                                                                        # 0x251b44 <__pyx_clineno>
   3340b: e9 a9 02 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   33410: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   33417: 48 8b 00                     	movq	(%rax), %rax
   3341a: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   3341e: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   33425: 48 89 10                     	movq	%rdx, (%rax)
   33428: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   3342f: 48 8b 00                     	movq	(%rax), %rax
   33432: 48 85 c0                     	testq	%rax, %rax
   33435: 75 1b                        	jne	0x33452 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2443>
   33437: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   3343e: 48 8b 40 08                  	movq	0x8(%rax), %rax
   33442: 48 8b 40 30                  	movq	0x30(%rax), %rax
   33446: 48 8b 95 18 ff ff ff         	movq	-0xe8(%rbp), %rdx
   3344d: 48 89 d7                     	movq	%rdx, %rdi
   33450: ff d0                        	callq	*%rax
   33452: 48 c7 85 18 ff ff ff 00 00 00 00     	movq	$0x0, -0xe8(%rbp)
   3345d: 48 83 bd d8 fe ff ff 00      	cmpq	$0x0, -0x128(%rbp)
   33465: 0f 94 c0                     	sete	%al
   33468: 0f b6 c0                     	movzbl	%al, %eax
   3346b: 48 85 c0                     	testq	%rax, %rax
   3346e: 74 33                        	je	0x334a3 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2494>
   33470: 48 8d 3d a9 91 01 00         	leaq	0x191a9(%rip), %rdi     # 0x4c620 <__pyx_k_BaseEfuse___dict_string_parse+0x240>
   33477: e8 f2 52 01 00               	callq	0x4876e <__Pyx_RaiseUnboundLocalError>
   3347c: 48 8b 05 65 c0 21 00         	movq	0x21c065(%rip), %rax    # 0x24f4e8 <__pyx_f>
   33483: 48 89 05 be e6 21 00         	movq	%rax, 0x21e6be(%rip)    # 0x251b48 <__pyx_filename>
   3348a: c7 05 ac e6 21 00 a1 01 00 00	movl	$0x1a1, 0x21e6ac(%rip)  # imm = 0x1A1
                                                                        # 0x251b40 <__pyx_lineno>
   33494: c7 05 a6 e6 21 00 26 2a 00 00	movl	$0x2a26, 0x21e6a6(%rip) # imm = 0x2A26
                                                                        # 0x251b44 <__pyx_clineno>
   3349e: e9 16 02 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   334a3: 48 8b 35 9e ec 21 00         	movq	0x21ec9e(%rip), %rsi    # 0x252148 <__pyx_int_1>
   334aa: 48 8b 85 d8 fe ff ff         	movq	-0x128(%rbp), %rax
   334b1: b9 00 00 00 00               	movl	$0x0, %ecx
   334b6: ba 01 00 00 00               	movl	$0x1, %edx
   334bb: 48 89 c7                     	movq	%rax, %rdi
   334be: e8 d1 3c 01 00               	callq	0x47194 <__Pyx_PyInt_AddObjC>
   334c3: 48 89 85 18 ff ff ff         	movq	%rax, -0xe8(%rbp)
   334ca: 48 83 bd 18 ff ff ff 00      	cmpq	$0x0, -0xe8(%rbp)
   334d2: 0f 94 c0                     	sete	%al
   334d5: 0f b6 c0                     	movzbl	%al, %eax
   334d8: 48 85 c0                     	testq	%rax, %rax
   334db: 74 27                        	je	0x33504 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x24f5>
   334dd: 48 8b 05 04 c0 21 00         	movq	0x21c004(%rip), %rax    # 0x24f4e8 <__pyx_f>
   334e4: 48 89 05 5d e6 21 00         	movq	%rax, 0x21e65d(%rip)    # 0x251b48 <__pyx_filename>
   334eb: c7 05 4b e6 21 00 a1 01 00 00	movl	$0x1a1, 0x21e64b(%rip)  # imm = 0x1A1
                                                                        # 0x251b40 <__pyx_lineno>
   334f5: c7 05 45 e6 21 00 27 2a 00 00	movl	$0x2a27, 0x21e645(%rip) # imm = 0x2A27
                                                                        # 0x251b44 <__pyx_clineno>
   334ff: e9 b5 01 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   33504: 48 8b 95 f8 fe ff ff         	movq	-0x108(%rbp), %rdx
   3350b: 48 8b 8d 18 ff ff ff         	movq	-0xe8(%rbp), %rcx
   33512: 48 8b 85 88 fe ff ff         	movq	-0x178(%rbp), %rax
   33519: 48 89 ce                     	movq	%rcx, %rsi
   3351c: 48 89 c7                     	movq	%rax, %rdi
   3351f: e8 fc 20 fd ff               	callq	0x5620 <PyObject_SetItem@plt>
   33524: c1 e8 1f                     	shrl	$0x1f, %eax
   33527: 0f b6 c0                     	movzbl	%al, %eax
   3352a: 48 85 c0                     	testq	%rax, %rax
   3352d: 74 27                        	je	0x33556 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2547>
   3352f: 48 8b 05 b2 bf 21 00         	movq	0x21bfb2(%rip), %rax    # 0x24f4e8 <__pyx_f>
   33536: 48 89 05 0b e6 21 00         	movq	%rax, 0x21e60b(%rip)    # 0x251b48 <__pyx_filename>
   3353d: c7 05 f9 e5 21 00 a1 01 00 00	movl	$0x1a1, 0x21e5f9(%rip)  # imm = 0x1A1
                                                                        # 0x251b40 <__pyx_lineno>
   33547: c7 05 f3 e5 21 00 29 2a 00 00	movl	$0x2a29, 0x21e5f3(%rip) # imm = 0x2A29
                                                                        # 0x251b44 <__pyx_clineno>
   33551: e9 63 01 00 00               	jmp	0x336b9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26aa>
   33556: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   3355d: 48 8b 00                     	movq	(%rax), %rax
   33560: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   33564: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   3356b: 48 89 10                     	movq	%rdx, (%rax)
   3356e: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   33575: 48 8b 00                     	movq	(%rax), %rax
   33578: 48 85 c0                     	testq	%rax, %rax
   3357b: 75 1b                        	jne	0x33598 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2589>
   3357d: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   33584: 48 8b 40 08                  	movq	0x8(%rax), %rax
   33588: 48 8b 40 30                  	movq	0x30(%rax), %rax
   3358c: 48 8b 95 18 ff ff ff         	movq	-0xe8(%rbp), %rdx
   33593: 48 89 d7                     	movq	%rdx, %rdi
   33596: ff d0                        	callq	*%rax
   33598: 48 c7 85 18 ff ff ff 00 00 00 00     	movq	$0x0, -0xe8(%rbp)
   335a3: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   335aa: 48 8b 00                     	movq	(%rax), %rax
   335ad: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   335b1: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   335b8: 48 89 10                     	movq	%rdx, (%rax)
   335bb: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   335c2: 48 8b 00                     	movq	(%rax), %rax
   335c5: 48 85 c0                     	testq	%rax, %rax
   335c8: 75 1b                        	jne	0x335e5 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x25d6>
   335ca: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   335d1: 48 8b 40 08                  	movq	0x8(%rax), %rax
   335d5: 48 8b 40 30                  	movq	0x30(%rax), %rax
   335d9: 48 8b 95 f8 fe ff ff         	movq	-0x108(%rbp), %rdx
   335e0: 48 89 d7                     	movq	%rdx, %rdi
   335e3: ff d0                        	callq	*%rax
   335e5: 48 c7 85 f8 fe ff ff 00 00 00 00     	movq	$0x0, -0x108(%rbp)
   335f0: e9 98 e8 ff ff               	jmp	0x31e8d <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0xe7e>
   335f5: 90                           	nop
   335f6: eb 04                        	jmp	0x335fc <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x25ed>
   335f8: 90                           	nop
   335f9: eb 01                        	jmp	0x335fc <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x25ed>
   335fb: 90                           	nop
   335fc: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   33603: 48 8b 00                     	movq	(%rax), %rax
   33606: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   3360a: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   33611: 48 89 10                     	movq	%rdx, (%rax)
   33614: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   3361b: 48 8b 00                     	movq	(%rax), %rax
   3361e: 48 85 c0                     	testq	%rax, %rax
   33621: 75 1b                        	jne	0x3363e <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x262f>
   33623: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   3362a: 48 8b 40 08                  	movq	0x8(%rax), %rax
   3362e: 48 8b 40 30                  	movq	0x30(%rax), %rax
   33632: 48 8b 95 08 ff ff ff         	movq	-0xf8(%rbp), %rdx
   33639: 48 89 d7                     	movq	%rdx, %rdi
   3363c: ff d0                        	callq	*%rax
   3363e: 48 c7 85 08 ff ff ff 00 00 00 00     	movq	$0x0, -0xf8(%rbp)
   33649: 48 83 bd f0 fe ff ff 00      	cmpq	$0x0, -0x110(%rbp)
   33651: 74 42                        	je	0x33695 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2686>
   33653: 48 8b 85 f0 fe ff ff         	movq	-0x110(%rbp), %rax
   3365a: 48 8b 00                     	movq	(%rax), %rax
   3365d: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   33661: 48 8b 85 f0 fe ff ff         	movq	-0x110(%rbp), %rax
   33668: 48 89 10                     	movq	%rdx, (%rax)
   3366b: 48 8b 85 f0 fe ff ff         	movq	-0x110(%rbp), %rax
   33672: 48 8b 00                     	movq	(%rax), %rax
   33675: 48 85 c0                     	testq	%rax, %rax
   33678: 75 1b                        	jne	0x33695 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2686>
   3367a: 48 8b 85 f0 fe ff ff         	movq	-0x110(%rbp), %rax
   33681: 48 8b 40 08                  	movq	0x8(%rax), %rax
   33685: 48 8b 40 30                  	movq	0x30(%rax), %rax
   33689: 48 8b 95 f0 fe ff ff         	movq	-0x110(%rbp), %rdx
   33690: 48 89 d7                     	movq	%rdx, %rdi
   33693: ff d0                        	callq	*%rax
   33695: 48 8b 05 cc b8 21 00         	movq	0x21b8cc(%rip), %rax    # 0x24ef68 <memcmp@@GLIBC_2.2.5+0x24ef68>
   3369c: 48 8b 10                     	movq	(%rax), %rdx
   3369f: 48 83 c2 01                  	addq	$0x1, %rdx
   336a3: 48 89 10                     	movq	%rdx, (%rax)
   336a6: 48 8b 05 bb b8 21 00         	movq	0x21b8bb(%rip), %rax    # 0x24ef68 <memcmp@@GLIBC_2.2.5+0x24ef68>
   336ad: 48 89 85 f0 fe ff ff         	movq	%rax, -0x110(%rbp)
   336b4: e9 f4 01 00 00               	jmp	0x338ad <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x289e>
   336b9: 48 83 bd f8 fe ff ff 00      	cmpq	$0x0, -0x108(%rbp)
   336c1: 74 42                        	je	0x33705 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26f6>
   336c3: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   336ca: 48 8b 00                     	movq	(%rax), %rax
   336cd: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   336d1: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   336d8: 48 89 10                     	movq	%rdx, (%rax)
   336db: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   336e2: 48 8b 00                     	movq	(%rax), %rax
   336e5: 48 85 c0                     	testq	%rax, %rax
   336e8: 75 1b                        	jne	0x33705 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x26f6>
   336ea: 48 8b 85 f8 fe ff ff         	movq	-0x108(%rbp), %rax
   336f1: 48 8b 40 08                  	movq	0x8(%rax), %rax
   336f5: 48 8b 40 30                  	movq	0x30(%rax), %rax
   336f9: 48 8b 95 f8 fe ff ff         	movq	-0x108(%rbp), %rdx
   33700: 48 89 d7                     	movq	%rdx, %rdi
   33703: ff d0                        	callq	*%rax
   33705: 48 83 bd 00 ff ff ff 00      	cmpq	$0x0, -0x100(%rbp)
   3370d: 74 42                        	je	0x33751 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2742>
   3370f: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   33716: 48 8b 00                     	movq	(%rax), %rax
   33719: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   3371d: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   33724: 48 89 10                     	movq	%rdx, (%rax)
   33727: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   3372e: 48 8b 00                     	movq	(%rax), %rax
   33731: 48 85 c0                     	testq	%rax, %rax
   33734: 75 1b                        	jne	0x33751 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2742>
   33736: 48 8b 85 00 ff ff ff         	movq	-0x100(%rbp), %rax
   3373d: 48 8b 40 08                  	movq	0x8(%rax), %rax
   33741: 48 8b 40 30                  	movq	0x30(%rax), %rax
   33745: 48 8b 95 00 ff ff ff         	movq	-0x100(%rbp), %rdx
   3374c: 48 89 d7                     	movq	%rdx, %rdi
   3374f: ff d0                        	callq	*%rax
   33751: 48 83 bd 08 ff ff ff 00      	cmpq	$0x0, -0xf8(%rbp)
   33759: 74 42                        	je	0x3379d <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x278e>
   3375b: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   33762: 48 8b 00                     	movq	(%rax), %rax
   33765: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   33769: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   33770: 48 89 10                     	movq	%rdx, (%rax)
   33773: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   3377a: 48 8b 00                     	movq	(%rax), %rax
   3377d: 48 85 c0                     	testq	%rax, %rax
   33780: 75 1b                        	jne	0x3379d <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x278e>
   33782: 48 8b 85 08 ff ff ff         	movq	-0xf8(%rbp), %rax
   33789: 48 8b 40 08                  	movq	0x8(%rax), %rax
   3378d: 48 8b 40 30                  	movq	0x30(%rax), %rax
   33791: 48 8b 95 08 ff ff ff         	movq	-0xf8(%rbp), %rdx
   33798: 48 89 d7                     	movq	%rdx, %rdi
   3379b: ff d0                        	callq	*%rax
   3379d: 48 83 bd 18 ff ff ff 00      	cmpq	$0x0, -0xe8(%rbp)
   337a5: 74 42                        	je	0x337e9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x27da>
   337a7: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   337ae: 48 8b 00                     	movq	(%rax), %rax
   337b1: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   337b5: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   337bc: 48 89 10                     	movq	%rdx, (%rax)
   337bf: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   337c6: 48 8b 00                     	movq	(%rax), %rax
   337c9: 48 85 c0                     	testq	%rax, %rax
   337cc: 75 1b                        	jne	0x337e9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x27da>
   337ce: 48 8b 85 18 ff ff ff         	movq	-0xe8(%rbp), %rax
   337d5: 48 8b 40 08                  	movq	0x8(%rax), %rax
   337d9: 48 8b 40 30                  	movq	0x30(%rax), %rax
   337dd: 48 8b 95 18 ff ff ff         	movq	-0xe8(%rbp), %rdx
   337e4: 48 89 d7                     	movq	%rdx, %rdi
   337e7: ff d0                        	callq	*%rax
   337e9: 48 83 bd 38 ff ff ff 00      	cmpq	$0x0, -0xc8(%rbp)
   337f1: 74 42                        	je	0x33835 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2826>
   337f3: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   337fa: 48 8b 00                     	movq	(%rax), %rax
   337fd: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   33801: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   33808: 48 89 10                     	movq	%rdx, (%rax)
   3380b: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   33812: 48 8b 00                     	movq	(%rax), %rax
   33815: 48 85 c0                     	testq	%rax, %rax
   33818: 75 1b                        	jne	0x33835 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2826>
   3381a: 48 8b 85 38 ff ff ff         	movq	-0xc8(%rbp), %rax
   33821: 48 8b 40 08                  	movq	0x8(%rax), %rax
   33825: 48 8b 40 30                  	movq	0x30(%rax), %rax
   33829: 48 8b 95 38 ff ff ff         	movq	-0xc8(%rbp), %rdx
   33830: 48 89 d7                     	movq	%rdx, %rdi
   33833: ff d0                        	callq	*%rax
   33835: 48 83 bd 40 ff ff ff 00      	cmpq	$0x0, -0xc0(%rbp)
   3383d: 74 42                        	je	0x33881 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2872>
   3383f: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   33846: 48 8b 00                     	movq	(%rax), %rax
   33849: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   3384d: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   33854: 48 89 10                     	movq	%rdx, (%rax)
   33857: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   3385e: 48 8b 00                     	movq	(%rax), %rax
   33861: 48 85 c0                     	testq	%rax, %rax
   33864: 75 1b                        	jne	0x33881 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2872>
   33866: 48 8b 85 40 ff ff ff         	movq	-0xc0(%rbp), %rax
   3386d: 48 8b 40 08                  	movq	0x8(%rax), %rax
   33871: 48 8b 40 30                  	movq	0x30(%rax), %rax
   33875: 48 8b 95 40 ff ff ff         	movq	-0xc0(%rbp), %rdx
   3387c: 48 89 d7                     	movq	%rdx, %rdi
   3387f: ff d0                        	callq	*%rax
   33881: 48 8b 0d c0 e2 21 00         	movq	0x21e2c0(%rip), %rcx    # 0x251b48 <__pyx_filename>
   33888: 8b 15 b2 e2 21 00            	movl	0x21e2b2(%rip), %edx    # 0x251b40 <__pyx_lineno>
   3388e: 8b 05 b0 e2 21 00            	movl	0x21e2b0(%rip), %eax    # 0x251b44 <__pyx_clineno>
   33894: 89 c6                        	movl	%eax, %esi
   33896: 48 8d 3d 37 8d 01 00         	leaq	0x18d37(%rip), %rdi     # 0x4c5d4 <__pyx_k_BaseEfuse___dict_string_parse+0x1f4>
   3389d: e8 2c 7a 01 00               	callq	0x4b2ce <__Pyx_AddTraceback>
   338a2: 48 c7 85 f0 fe ff ff 00 00 00 00     	movq	$0x0, -0x110(%rbp)
   338ad: 48 83 bd b0 fe ff ff 00      	cmpq	$0x0, -0x150(%rbp)
   338b5: 74 42                        	je	0x338f9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x28ea>
   338b7: 48 8b 85 b0 fe ff ff         	movq	-0x150(%rbp), %rax
   338be: 48 8b 00                     	movq	(%rax), %rax
   338c1: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   338c5: 48 8b 85 b0 fe ff ff         	movq	-0x150(%rbp), %rax
   338cc: 48 89 10                     	movq	%rdx, (%rax)
   338cf: 48 8b 85 b0 fe ff ff         	movq	-0x150(%rbp), %rax
   338d6: 48 8b 00                     	movq	(%rax), %rax
   338d9: 48 85 c0                     	testq	%rax, %rax
   338dc: 75 1b                        	jne	0x338f9 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x28ea>
   338de: 48 8b 85 b0 fe ff ff         	movq	-0x150(%rbp), %rax
   338e5: 48 8b 40 08                  	movq	0x8(%rax), %rax
   338e9: 48 8b 40 30                  	movq	0x30(%rax), %rax
   338ed: 48 8b 95 b0 fe ff ff         	movq	-0x150(%rbp), %rdx
   338f4: 48 89 d7                     	movq	%rdx, %rdi
   338f7: ff d0                        	callq	*%rax
   338f9: 48 83 bd b8 fe ff ff 00      	cmpq	$0x0, -0x148(%rbp)
   33901: 74 42                        	je	0x33945 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2936>
   33903: 48 8b 85 b8 fe ff ff         	movq	-0x148(%rbp), %rax
   3390a: 48 8b 00                     	movq	(%rax), %rax
   3390d: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   33911: 48 8b 85 b8 fe ff ff         	movq	-0x148(%rbp), %rax
   33918: 48 89 10                     	movq	%rdx, (%rax)
   3391b: 48 8b 85 b8 fe ff ff         	movq	-0x148(%rbp), %rax
   33922: 48 8b 00                     	movq	(%rax), %rax
   33925: 48 85 c0                     	testq	%rax, %rax
   33928: 75 1b                        	jne	0x33945 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2936>
   3392a: 48 8b 85 b8 fe ff ff         	movq	-0x148(%rbp), %rax
   33931: 48 8b 40 08                  	movq	0x8(%rax), %rax
   33935: 48 8b 40 30                  	movq	0x30(%rax), %rax
   33939: 48 8b 95 b8 fe ff ff         	movq	-0x148(%rbp), %rdx
   33940: 48 89 d7                     	movq	%rdx, %rdi
   33943: ff d0                        	callq	*%rax
   33945: 48 83 bd c0 fe ff ff 00      	cmpq	$0x0, -0x140(%rbp)
   3394d: 74 42                        	je	0x33991 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2982>
   3394f: 48 8b 85 c0 fe ff ff         	movq	-0x140(%rbp), %rax
   33956: 48 8b 00                     	movq	(%rax), %rax
   33959: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   3395d: 48 8b 85 c0 fe ff ff         	movq	-0x140(%rbp), %rax
   33964: 48 89 10                     	movq	%rdx, (%rax)
   33967: 48 8b 85 c0 fe ff ff         	movq	-0x140(%rbp), %rax
   3396e: 48 8b 00                     	movq	(%rax), %rax
   33971: 48 85 c0                     	testq	%rax, %rax
   33974: 75 1b                        	jne	0x33991 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2982>
   33976: 48 8b 85 c0 fe ff ff         	movq	-0x140(%rbp), %rax
   3397d: 48 8b 40 08                  	movq	0x8(%rax), %rax
   33981: 48 8b 40 30                  	movq	0x30(%rax), %rax
   33985: 48 8b 95 c0 fe ff ff         	movq	-0x140(%rbp), %rdx
   3398c: 48 89 d7                     	movq	%rdx, %rdi
   3398f: ff d0                        	callq	*%rax
   33991: 48 83 bd c8 fe ff ff 00      	cmpq	$0x0, -0x138(%rbp)
   33999: 74 42                        	je	0x339dd <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x29ce>
   3399b: 48 8b 85 c8 fe ff ff         	movq	-0x138(%rbp), %rax
   339a2: 48 8b 00                     	movq	(%rax), %rax
   339a5: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   339a9: 48 8b 85 c8 fe ff ff         	movq	-0x138(%rbp), %rax
   339b0: 48 89 10                     	movq	%rdx, (%rax)
   339b3: 48 8b 85 c8 fe ff ff         	movq	-0x138(%rbp), %rax
   339ba: 48 8b 00                     	movq	(%rax), %rax
   339bd: 48 85 c0                     	testq	%rax, %rax
   339c0: 75 1b                        	jne	0x339dd <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x29ce>
   339c2: 48 8b 85 c8 fe ff ff         	movq	-0x138(%rbp), %rax
   339c9: 48 8b 40 08                  	movq	0x8(%rax), %rax
   339cd: 48 8b 40 30                  	movq	0x30(%rax), %rax
   339d1: 48 8b 95 c8 fe ff ff         	movq	-0x138(%rbp), %rdx
   339d8: 48 89 d7                     	movq	%rdx, %rdi
   339db: ff d0                        	callq	*%rax
   339dd: 48 83 bd d0 fe ff ff 00      	cmpq	$0x0, -0x130(%rbp)
   339e5: 74 42                        	je	0x33a29 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2a1a>
   339e7: 48 8b 85 d0 fe ff ff         	movq	-0x130(%rbp), %rax
   339ee: 48 8b 00                     	movq	(%rax), %rax
   339f1: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   339f5: 48 8b 85 d0 fe ff ff         	movq	-0x130(%rbp), %rax
   339fc: 48 89 10                     	movq	%rdx, (%rax)
   339ff: 48 8b 85 d0 fe ff ff         	movq	-0x130(%rbp), %rax
   33a06: 48 8b 00                     	movq	(%rax), %rax
   33a09: 48 85 c0                     	testq	%rax, %rax
   33a0c: 75 1b                        	jne	0x33a29 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2a1a>
   33a0e: 48 8b 85 d0 fe ff ff         	movq	-0x130(%rbp), %rax
   33a15: 48 8b 40 08                  	movq	0x8(%rax), %rax
   33a19: 48 8b 40 30                  	movq	0x30(%rax), %rax
   33a1d: 48 8b 95 d0 fe ff ff         	movq	-0x130(%rbp), %rdx
   33a24: 48 89 d7                     	movq	%rdx, %rdi
   33a27: ff d0                        	callq	*%rax
   33a29: 48 83 bd d8 fe ff ff 00      	cmpq	$0x0, -0x128(%rbp)
   33a31: 74 42                        	je	0x33a75 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2a66>
   33a33: 48 8b 85 d8 fe ff ff         	movq	-0x128(%rbp), %rax
   33a3a: 48 8b 00                     	movq	(%rax), %rax
   33a3d: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   33a41: 48 8b 85 d8 fe ff ff         	movq	-0x128(%rbp), %rax
   33a48: 48 89 10                     	movq	%rdx, (%rax)
   33a4b: 48 8b 85 d8 fe ff ff         	movq	-0x128(%rbp), %rax
   33a52: 48 8b 00                     	movq	(%rax), %rax
   33a55: 48 85 c0                     	testq	%rax, %rax
   33a58: 75 1b                        	jne	0x33a75 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2a66>
   33a5a: 48 8b 85 d8 fe ff ff         	movq	-0x128(%rbp), %rax
   33a61: 48 8b 40 08                  	movq	0x8(%rax), %rax
   33a65: 48 8b 40 30                  	movq	0x30(%rax), %rax
   33a69: 48 8b 95 d8 fe ff ff         	movq	-0x128(%rbp), %rdx
   33a70: 48 89 d7                     	movq	%rdx, %rdi
   33a73: ff d0                        	callq	*%rax
   33a75: 48 83 bd e0 fe ff ff 00      	cmpq	$0x0, -0x120(%rbp)
   33a7d: 74 42                        	je	0x33ac1 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2ab2>
   33a7f: 48 8b 85 e0 fe ff ff         	movq	-0x120(%rbp), %rax
   33a86: 48 8b 00                     	movq	(%rax), %rax
   33a89: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   33a8d: 48 8b 85 e0 fe ff ff         	movq	-0x120(%rbp), %rax
   33a94: 48 89 10                     	movq	%rdx, (%rax)
   33a97: 48 8b 85 e0 fe ff ff         	movq	-0x120(%rbp), %rax
   33a9e: 48 8b 00                     	movq	(%rax), %rax
   33aa1: 48 85 c0                     	testq	%rax, %rax
   33aa4: 75 1b                        	jne	0x33ac1 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2ab2>
   33aa6: 48 8b 85 e0 fe ff ff         	movq	-0x120(%rbp), %rax
   33aad: 48 8b 40 08                  	movq	0x8(%rax), %rax
   33ab1: 48 8b 40 30                  	movq	0x30(%rax), %rax
   33ab5: 48 8b 95 e0 fe ff ff         	movq	-0x120(%rbp), %rdx
   33abc: 48 89 d7                     	movq	%rdx, %rdi
   33abf: ff d0                        	callq	*%rax
   33ac1: 48 83 bd e8 fe ff ff 00      	cmpq	$0x0, -0x118(%rbp)
   33ac9: 74 42                        	je	0x33b0d <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2afe>
   33acb: 48 8b 85 e8 fe ff ff         	movq	-0x118(%rbp), %rax
   33ad2: 48 8b 00                     	movq	(%rax), %rax
   33ad5: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   33ad9: 48 8b 85 e8 fe ff ff         	movq	-0x118(%rbp), %rax
   33ae0: 48 89 10                     	movq	%rdx, (%rax)
   33ae3: 48 8b 85 e8 fe ff ff         	movq	-0x118(%rbp), %rax
   33aea: 48 8b 00                     	movq	(%rax), %rax
   33aed: 48 85 c0                     	testq	%rax, %rax
   33af0: 75 1b                        	jne	0x33b0d <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2afe>
   33af2: 48 8b 85 e8 fe ff ff         	movq	-0x118(%rbp), %rax
   33af9: 48 8b 40 08                  	movq	0x8(%rax), %rax
   33afd: 48 8b 40 30                  	movq	0x30(%rax), %rax
   33b01: 48 8b 95 e8 fe ff ff         	movq	-0x118(%rbp), %rdx
   33b08: 48 89 d7                     	movq	%rdx, %rdi
   33b0b: ff d0                        	callq	*%rax
   33b0d: 48 83 bd 68 fe ff ff 00      	cmpq	$0x0, -0x198(%rbp)
   33b15: 74 42                        	je	0x33b59 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2b4a>
   33b17: 48 8b 85 68 fe ff ff         	movq	-0x198(%rbp), %rax
   33b1e: 48 8b 00                     	movq	(%rax), %rax
   33b21: 48 8d 50 ff                  	leaq	-0x1(%rax), %rdx
   33b25: 48 8b 85 68 fe ff ff         	movq	-0x198(%rbp), %rax
   33b2c: 48 89 10                     	movq	%rdx, (%rax)
   33b2f: 48 8b 85 68 fe ff ff         	movq	-0x198(%rbp), %rax
   33b36: 48 8b 00                     	movq	(%rax), %rax
   33b39: 48 85 c0                     	testq	%rax, %rax
   33b3c: 75 1b                        	jne	0x33b59 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2b4a>
   33b3e: 48 8b 85 68 fe ff ff         	movq	-0x198(%rbp), %rax
   33b45: 48 8b 40 08                  	movq	0x8(%rax), %rax
   33b49: 48 8b 40 30                  	movq	0x30(%rax), %rax
   33b4d: 48 8b 95 68 fe ff ff         	movq	-0x198(%rbp), %rdx
   33b54: 48 89 d7                     	movq	%rdx, %rdi
   33b57: ff d0                        	callq	*%rax
   33b59: 48 8b 85 f0 fe ff ff         	movq	-0x110(%rbp), %rax
   33b60: 48 8b 4d f8                  	movq	-0x8(%rbp), %rcx
   33b64: 64 48 33 0c 25 28 00 00 00   	xorq	%fs:0x28, %rcx
   33b6d: 74 05                        	je	0x33b74 <__pyx_pf_5efuse_9BaseEfuse_18encrypt+0x2b65>
   33b6f: e8 0c 1c fd ff               	callq	0x5780 <__stack_chk_fail@plt>
   33b74: c9                           	leave
   33b75: c3                           	retq
